import React, { useState, useMemo, useEffect } from 'react';
import { 
  FileText, 
  Plus, 
  Trash2, 
  Save, 
  Printer, 
  X, 
  Search,
  ChevronRight,
  ChevronLeft,
  BarChart3,
  Hash,
  Calendar,
  ChevronDown,
  Package,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import * as XLSX from 'xlsx';
import { uid } from '../lib/utils';
import { DB, Doc, DocItem, Account, CostCenter, Item, User, PriceType, AccountCategory } from '../types';

interface DocumentFormProps {
  db: DB;
  user: User;
  type: 'issue' | 'purchase' | 'sale';
  onSave: (doc: Partial<Doc>) => void;
  onPrint: (doc: Doc) => void;
  onNavigate?: (direction: 'prev' | 'next' | 'new') => void;
  onDelete?: (id: string) => void;
  initialDoc?: Doc | null;
  onCancel?: () => void;
  showNotification: (msg: string, type?: 'success' | 'error' | 'warning') => void;
  setConfirmModal: (modal: { title: string; message: string; onConfirm: () => void } | null) => void;
}

const CollapsibleSection: React.FC<{
  title: string;
  subtitle?: string;
  icon: React.ReactNode;
  isExpanded: boolean;
  onToggle: () => void;
  children: React.ReactNode;
  badge?: React.ReactNode;
}> = ({ title, subtitle, icon, isExpanded, onToggle, children, badge }) => (
  <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden transition-all duration-300">
    <button 
      onClick={onToggle}
      className="w-full p-6 sm:p-8 flex items-center justify-between bg-slate-50/30 hover:bg-slate-50 transition-colors text-right"
    >
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-2xl bg-white border border-slate-100 shadow-sm flex items-center justify-center text-blue-600">
          {icon}
        </div>
        <div>
          <div className="flex items-center gap-3">
            <h3 className="font-black text-slate-800 text-lg">{title}</h3>
            {badge}
          </div>
          {subtitle && <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">{subtitle}</p>}
        </div>
      </div>
      <motion.div 
        animate={{ rotate: isExpanded ? 0 : 180 }}
        className="w-10 h-10 rounded-xl bg-white border border-slate-100 flex items-center justify-center text-slate-400 shadow-sm"
      >
        <ChevronDown size={20} />
      </motion.div>
    </button>
    
    <AnimatePresence initial={false}>
      {isExpanded && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3, ease: 'easeInOut' }}
        >
          <div className="p-6 sm:p-8 border-t border-slate-50">
            {children}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  </div>
);

export const DocumentForm: React.FC<DocumentFormProps> = ({ 
  db, 
  user,
  type,
  onSave, 
  onPrint, 
  onNavigate,
  onDelete,
  initialDoc,
  onCancel,
  showNotification,
  setConfirmModal
}) => {
  const [date, setDate] = useState(initialDoc?.date || new Date().toISOString().split('T')[0]);
  const [docNum, setDocNum] = useState(initialDoc?.docNum || '');
  const [ref, setRef] = useState(initialDoc?.ref || '');
  const [description, setDescription] = useState(initialDoc?.description || '');
  const [priceType, setPriceType] = useState<PriceType>(initialDoc?.priceType || 'retail');
  
  const typeSettings = useMemo(() => {
    return db.settings?.[type] || { 
      linkingLevel: db.linkingLevel || 'header', 
      mandatoryFields: db.mandatoryFields || ['branchId', 'warehouseId', 'accId'],
      fieldConfig: {}
    };
  }, [db.settings, db.linkingLevel, db.mandatoryFields, type]);

  const isFieldVisible = (fieldId: string) => {
    const config = typeSettings.fieldConfig?.[fieldId];
    if (config) return config.visible;
    return true; // Default to visible
  };

  const relevantFields = useMemo(() => {
    return (db.fieldDefinitions || [])
      .filter(f => !f.allowedDocTypes || f.allowedDocTypes.includes(type))
      .sort((a, b) => a.order - b.order);
  }, [db.fieldDefinitions, type]);

  // Reset state when initialDoc changes (for navigation)
  useEffect(() => {
    if (initialDoc) {
      setDate(initialDoc.date);
      setDocNum(initialDoc.docNum);
      setRef(initialDoc.ref);
      setDescription(initialDoc.description);
      setBranchId(initialDoc.branchId || '');
      setWarehouseId(initialDoc.warehouseId || '');
      setDeptId(initialDoc.deptId || '');
      setCustomValues(initialDoc.customValues || {});
      setItems(initialDoc.items);
      
      const category = initialDoc.accType || 'gl';
      let foundAcc: any = null;
      if (category === 'gl') foundAcc = (db.accounts || []).find(a => a.id === initialDoc.accId);
      else if (category === 'customer-supplier') foundAcc = db.customersSuppliers?.find(a => a.accId === initialDoc.accId);
      else if (category === 'fund') foundAcc = db.funds?.find(a => a.accId === initialDoc.accId);
      else if (category === 'bank') foundAcc = db.banks?.find(a => a.accId === initialDoc.accId);
      else if (category === 'warehouse') foundAcc = db.warehouses?.find(a => a.accId === initialDoc.accId);

      setSelectedAcc(foundAcc || null);
      setAccSearch(foundAcc?.name || '');
      
      setSelectedCC((db.centers || []).find(c => c.id === initialDoc.ccId) || null);
      setCcSearch((db.centers || []).find(c => c.id === initialDoc.ccId)?.name || '');
    }
  }, [initialDoc, db.accounts, db.centers]);
  
  // Filtered lists based on user permissions
  const allowedBranches = useMemo(() => {
    if (user.role === 'admin') return (db.branches || []);
    return (db.branches || []).filter(b => user.allowedBranches?.includes(b.id));
  }, [db.branches, user]);

  const allowedWarehouses = useMemo(() => {
    if (user.role === 'admin') return (db.warehouses || []);
    return (db.warehouses || []).filter(w => user.allowedWarehouses?.includes(w.id));
  }, [db.warehouses, user]);

  const [branchId, setBranchId] = useState(initialDoc?.branchId || (allowedBranches.length === 1 ? allowedBranches[0].id : ''));
  const [warehouseId, setWarehouseId] = useState(initialDoc?.warehouseId || (allowedWarehouses.length === 1 ? allowedWarehouses[0].id : ''));
  const [deptId, setDeptId] = useState(initialDoc?.deptId || '');
  const [accType, setAccType] = useState<AccountCategory>(initialDoc?.accType || (type === 'purchase' ? 'customer-supplier' : type === 'sale' ? 'customer-supplier' : 'gl'));

  // Automatic Document Number Calculation
  const nextDocNum = useMemo(() => {
    if (initialDoc) return initialDoc.docNum;
    if (!branchId || (db.numberingStrategy === 'branch-warehouse' && !warehouseId)) return '';
    
    const year = new Date(date).getFullYear();
    const branchDocs = (db.docs || []).filter(d => {
      const dYear = new Date(d.date).getFullYear();
      if (dYear !== year) return false;
      if (d.branchId !== branchId) return false;
      if (db.numberingStrategy === 'branch-warehouse' && d.warehouseId !== warehouseId) return false;
      return true;
    });

    const maxNum = branchDocs.reduce((max, d) => {
      const num = parseInt(d.docNum.split('-').pop() || '0');
      return num > max ? num : max;
    }, 0);

    const prefix = db.numberingStrategy === 'branch' 
      ? (db.branches || []).find(b => b.id === branchId)?.code || 'B'
      : `${(db.branches || []).find(b => b.id === branchId)?.code || 'B'}-${(db.warehouses || []).find(w => w.id === warehouseId)?.code || 'W'}`;
    
    return `${prefix}-${year}-${(maxNum + 1).toString().padStart(4, '0')}`;
  }, [db.docs, db.numberingStrategy, branchId, warehouseId, date, initialDoc, db.branches, db.warehouses]);

  useEffect(() => {
    if (!initialDoc && nextDocNum && !docNum) {
      setDocNum(nextDocNum);
    }
  }, [nextDocNum, initialDoc, docNum]);

  const [accSearch, setAccSearch] = useState(() => {
    if (!initialDoc?.accId) return '';
    const category = initialDoc.accType || 'gl';
    if (category === 'gl') return (db.accounts || []).find(a => a.id === initialDoc.accId)?.name || '';
    if (category === 'customer-supplier') return (db.customersSuppliers || []).find(a => a.accId === initialDoc.accId)?.name || '';
    if (category === 'fund') return (db.funds || []).find(a => a.accId === initialDoc.accId)?.name || '';
    if (category === 'bank') return (db.banks || []).find(a => a.accId === initialDoc.accId)?.name || '';
    if (category === 'warehouse') return (db.warehouses || []).find(a => a.accId === initialDoc.accId)?.name || '';
    if (category === 'all') {
      return (db.accounts || []).find(a => a.id === initialDoc.accId)?.name || 
             (db.customersSuppliers || []).find(a => a.accId === initialDoc.accId)?.name ||
             (db.funds || []).find(a => a.accId === initialDoc.accId)?.name ||
             (db.banks || []).find(a => a.accId === initialDoc.accId)?.name ||
             (db.warehouses || []).find(a => a.accId === initialDoc.accId)?.name || '';
    }
    return '';
  });
  const [debouncedAccSearch, setDebouncedAccSearch] = useState(accSearch);
  const [selectedAcc, setSelectedAcc] = useState<any | null>(() => {
    if (!initialDoc?.accId) return null;
    const category = initialDoc.accType || 'gl';
    if (category === 'gl') return (db.accounts || []).find(a => a.id === initialDoc.accId) || null;
    if (category === 'customer-supplier') return (db.customersSuppliers || []).find(a => a.accId === initialDoc.accId) || null;
    if (category === 'fund') return (db.funds || []).find(a => a.accId === initialDoc.accId) || null;
    if (category === 'bank') return (db.banks || []).find(a => a.accId === initialDoc.accId) || null;
    if (category === 'warehouse') return (db.warehouses || []).find(a => a.accId === initialDoc.accId) || null;
    if (category === 'all') {
      return (db.accounts || []).find(a => a.id === initialDoc.accId) || 
             (db.customersSuppliers || []).find(a => a.accId === initialDoc.accId) ||
             (db.funds || []).find(a => a.accId === initialDoc.accId) ||
             (db.banks || []).find(a => a.accId === initialDoc.accId) ||
             (db.warehouses || []).find(a => a.accId === initialDoc.accId) || null;
    }
    return null;
  });
  const [ccSearch, setCcSearch] = useState((db.centers || []).find(c => c.id === initialDoc?.ccId)?.name || '');
  const [debouncedCcSearch, setDebouncedCcSearch] = useState(ccSearch);
  const [selectedCC, setSelectedCC] = useState<CostCenter | null>((db.centers || []).find(c => c.id === initialDoc?.ccId) || null);
  
  const [customValues, setCustomValues] = useState<Record<string, any>>(initialDoc?.customValues || {});
  const [expandedSections, setExpandedSections] = useState({
    details: true,
    items: true
  });
  const [importState, setImportState] = useState<{
    show: boolean;
    headers: string[];
    data: any[];
    mapping: Record<string, string>;
  }>({
    show: false,
    headers: [],
    data: [],
    mapping: {}
  });

  const [isSaving, setIsSaving] = useState(false);

  const toggleSection = (section: 'details' | 'items') => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const fetchPrice = (itemId: string, unit: string, docDate: string, pType: PriceType) => {
    if (!itemId || !unit || type !== 'sale') return 0;
    
    // Find the latest pricing doc for this type and date
    const relevantPricingDocs = (db.pricingDocs || [])
      .filter(d => d.type === pType && d.date <= docDate)
      .sort((a, b) => b.date.localeCompare(a.date));
    
    for (const pDoc of relevantPricingDocs) {
      const pItem = (pDoc.items || []).find(i => i.itemId === itemId && i.unit === unit);
      if (pItem) return pItem.price;
    }
    return 0;
  };

  const [items, setItems] = useState<DocItem[]>(() => {
    if (initialDoc?.items) return initialDoc.items;
    return Array.from({ length: 5 }).map(() => ({ 
      id: uid(), 
      itemId: '', 
      unit: '', 
      qty: 0,
      price: 0,
      discount: 0,
      expenses: 0,
      total: 0,
      accId: '',
      ccId: ''
    }));
  });
  const [itemSearchIdx, setItemSearchIdx] = useState<number | null>(null);
  const [itemSearchQuery, setItemSearchQuery] = useState('');
  const [debouncedItemSearch, setDebouncedItemSearch] = useState('');

  const [accSearchIdx, setAccSearchIdx] = useState<number | null>(null);
  const [rowAccSearchQuery, setRowAccSearchQuery] = useState('');
  const [ccSearchIdx, setCcSearchIdx] = useState<number | null>(null);
  const [rowCcSearchQuery, setRowCcSearchQuery] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedAccSearch(accSearch), 50);
    return () => clearTimeout(timer);
  }, [accSearch]);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedCcSearch(ccSearch), 50);
    return () => clearTimeout(timer);
  }, [ccSearch]);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedItemSearch(itemSearchQuery), 50);
    return () => clearTimeout(timer);
  }, [itemSearchQuery]);

  const filteredAccounts = useMemo(() => {
    const q = (accSearchIdx !== null ? rowAccSearchQuery : debouncedAccSearch).toLowerCase();
    const currentAccType = accSearchIdx !== null ? (items[accSearchIdx].accType || 'gl') : accType;

    let source: any[] = [];
    switch (currentAccType) {
      case 'gl': source = (db.accounts || []).filter(a => a.isPostable).map(a => ({ ...a, category: 'gl' })); break;
      case 'customer-supplier': source = (db.customersSuppliers || []).map(a => ({ ...a, category: 'customer-supplier' })); break;
      case 'fund': source = (db.funds || []).map(a => ({ ...a, category: 'fund' })); break;
      case 'bank': source = (db.banks || []).map(a => ({ ...a, category: 'bank' })); break;
      case 'warehouse': source = (db.warehouses || []).map(a => ({ ...a, category: 'warehouse' })); break;
      case 'all': 
        source = [
          ...(db.accounts || []).filter(a => a.isPostable).map(a => ({ ...a, category: 'gl' })),
          ...(db.customersSuppliers || []).map(a => ({ ...a, category: 'customer-supplier' })),
          ...(db.funds || []).map(a => ({ ...a, category: 'fund' })),
          ...(db.banks || []).map(a => ({ ...a, category: 'bank' })),
          ...(db.warehouses || []).map(a => ({ ...a, category: 'warehouse' }))
        ];
        break;
      default: source = (db.accounts || []).filter(a => a.isPostable).map(a => ({ ...a, category: 'gl' }));
    }

    return source.filter(a => 
      (a.name?.toLowerCase().includes(q) || a.code?.toLowerCase().includes(q))
    ).slice(0, 20);
  }, [db, debouncedAccSearch, rowAccSearchQuery, accSearchIdx, items, accType]);

  const filteredCenters = useMemo(() => {
    const q = (ccSearchIdx !== null ? rowCcSearchQuery : debouncedCcSearch).toLowerCase();
    let base = user.role === 'admin' ? (db.centers || []) : (db.centers || []).filter(c => user.allowedCenters?.includes(c.id));
    // Only leaf centers
    base = base.filter(c => c.isLeaf);
    return base.filter(c => c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q));
  }, [db.centers, debouncedCcSearch, rowCcSearchQuery, ccSearchIdx, user]);

  const [startedTyping, setStartedTyping] = useState<Record<string, boolean>>({});

  const filteredItems = useMemo(() => {
    const query = debouncedItemSearch.toLowerCase();
    return (db.items || []).filter(i => 
      i.isLeaf && (
        i.name.toLowerCase().includes(query) || 
        i.code.toLowerCase().includes(query)
      )
    );
  }, [db.items, debouncedItemSearch]);

  const handleSearchChange = (idx: number | string, query: string, type: 'item' | 'acc' | 'cc') => {
    const key = `${type}-${idx}`;
    let finalQuery = query;

    if (!startedTyping[key]) {
      setStartedTyping(prev => ({ ...prev, [key]: true }));
      finalQuery = query.slice(-1);
    }

    if (type === 'item') {
      setItemSearchIdx(idx as number);
      setItemSearchQuery(finalQuery);
      if (items[idx as number].itemId) updateRow(idx as number, 'itemId', '');
    } else if (type === 'acc') {
      if (idx === 'main') {
        setAccSearch(finalQuery);
        if (selectedAcc) setSelectedAcc(null);
      } else {
        setAccSearchIdx(idx as number);
        setRowAccSearchQuery(finalQuery);
        updateRow(idx as number, 'accId', '');
      }
    } else if (type === 'cc') {
      if (idx === 'main') {
        setCcSearch(finalQuery);
        if (selectedCC) setSelectedCC(null);
      } else {
        setCcSearchIdx(idx as number);
        setRowCcSearchQuery(finalQuery);
        updateRow(idx as number, 'ccId', '');
      }
    }
  };

  const addRow = () => {
    setItems([...items, { 
      id: uid(), 
      itemId: '', 
      unit: '', 
      qty: 0,
      price: 0,
      discount: 0,
      expenses: 0,
      total: 0,
      accId: '',
      ccId: ''
    }]);
  };

  const addRowBefore = (idx: number) => {
    const newItems = [...items];
    newItems.splice(idx, 0, { 
      id: uid(), 
      itemId: '', 
      unit: '', 
      qty: 0,
      price: 0,
      discount: 0,
      expenses: 0,
      total: 0,
      accId: '',
      ccId: ''
    });
    setItems(newItems);
    showNotification('تم إضافة سطر قبل السطر المحدد', 'success');
  };

  const removeRow = (idx: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== idx));
    }
  };

  const updateRow = (idx: number, field: keyof DocItem, value: any) => {
    setItems(prev => {
      const newItems = [...prev];
      const row = { ...newItems[idx], [field]: value };
      
      // Auto-fetch price for sales
      if (type === 'sale' && (field === 'itemId' || field === 'unit')) {
        const itemId = field === 'itemId' ? value : row.itemId;
        const unit = field === 'unit' ? value : row.unit;
        if (itemId && unit) {
          row.price = fetchPrice(itemId, unit, date, priceType);
        }
      }

      // Recalculate total if qty, price, discount, or expenses change
      if (['qty', 'price', 'discount', 'expenses'].includes(field as string)) {
        const qty = row.qty || 0;
        const price = row.price || 0;
        const discount = row.discount || 0;
        const expenses = row.expenses || 0;
        row.total = (qty * price) - discount + expenses;
      }

      newItems[idx] = row;
      
      // Auto-add row if filling last qty
      if (field === 'qty' && idx === prev.length - 1 && value > 0) {
        newItems.push({ 
          id: uid(), 
          itemId: '', 
          unit: '', 
          qty: 0,
          price: 0,
          discount: 0,
          expenses: 0,
          total: 0,
          accId: '',
          ccId: ''
        });
      }
      
      return newItems;
    });
  };

  const [isDirty, setIsDirty] = useState(false);

  // Track changes to mark as dirty
  useEffect(() => {
    setIsDirty(true);
  }, [date, docNum, ref, description, items, customValues, selectedAcc, selectedCC, branchId, warehouseId, deptId, priceType]);

  // Reset dirty state when initialDoc changes (loading a doc)
  useEffect(() => {
    setIsDirty(false);
  }, [initialDoc]);

  // Warn before closing if dirty
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isDirty]);

  const importFromExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result as string;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(ws) as any[];

        if (jsonData.length === 0) {
          showNotification('الملف فارغ أو غير صالح', 'error');
          return;
        }

        const headers = Object.keys(jsonData[0]);
        const initialMapping: Record<string, string> = {};
        const fieldOptions = [
          { key: 'itemCode', aliases: ['itemCode', 'itemId', 'code', 'الكود', 'كود_الصنف', 'رقم_الصنف'] },
          { key: 'unit', aliases: ['unit', 'الوحدة', 'وحدة'] },
          { key: 'qty', aliases: ['qty', 'quantity', 'الكمية', 'كمية'] },
          { key: 'price', aliases: ['price', 'السعر', 'سعر'] },
          { key: 'discount', aliases: ['discount', 'الخصم', 'خصم'] },
          { key: 'expenses', aliases: ['expenses', 'المصاريف', 'مصاريف'] },
          { key: 'accCode', aliases: ['accCode', 'accId', 'حساب', 'كود_الحساب'] },
          { key: 'ccCode', aliases: ['ccCode', 'ccId', 'مركز', 'كود_المركز'] },
        ];

        fieldOptions.forEach(field => {
          const match = headers.find(h => field.aliases.some(alias => h.toLowerCase().includes(alias.toLowerCase())));
          if (match) initialMapping[field.key] = match;
        });

        setImportState({ show: true, headers, data: jsonData, mapping: initialMapping });
      } catch (err) {
        showNotification('❌ فشل قراءة الملف.', 'error');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  const executeImport = () => {
    const { data, mapping } = importState;
    const importedItems: DocItem[] = [];

    data.forEach(row => {
      const code = String(row[mapping.itemCode] || '');
      if (!code) return;

      const item = (db.items || []).find(i => i.code === code || i.id === code);
      if (!item) return;

      const unitName = String(row[mapping.unit] || (item.units && item.units.length > 0 ? item.units[0].name : 'حبة'));
      const qty = parseFloat(row[mapping.qty]) || 0;
      const price = parseFloat(row[mapping.price]) || (type === 'sale' ? fetchPrice(item.id, unitName, date, priceType) : 0);
      const discount = parseFloat(row[mapping.discount]) || 0;
      const expenses = parseFloat(row[mapping.expenses]) || 0;

      const accCode = String(row[mapping.accCode] || '');
      const acc = (db.accounts || []).find(a => a.code === accCode || a.id === accCode);

      const ccCode = String(row[mapping.ccCode] || '');
      const cc = (db.centers || []).find(c => c.code === ccCode || c.id === ccCode);

      importedItems.push({
        id: uid(),
        itemId: item.id,
        unit: unitName,
        qty,
        price,
        discount,
        expenses,
        total: (qty * price) - discount + expenses,
        accId: acc?.id || '',
        ccId: cc?.id || ''
      });
    });

    if (importedItems.length > 0) {
      setItems(prev => {
        const filtered = prev.filter(i => i.itemId);
        return [...filtered, ...importedItems];
      });
      showNotification(`✅ تم استيراد ${importedItems.length} صنف بنجاح`, 'success');
    }
    setImportState({ show: false, headers: [], data: [], mapping: {} });
  };

  const downloadTemplate = () => {
    const headers = [['كود_الصنف', 'الوحدة', 'الكمية', 'السعر', 'الخصم', 'المصاريف', 'كود_الحساب', 'كود_المركز']];
    const sample = [['101', 'حبة', '10', '50', '0', '0', '', '']];
    const ws = XLSX.utils.aoa_to_sheet([...headers, ...sample]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Items");
    XLSX.writeFile(wb, "items_import_template.xlsx");
  };

  const handleSave = async () => {
    // Permission checks
    if (user.role !== 'admin') {
      if (!initialDoc) {
        if (type === 'purchase' && !user.canCreatePurchase) { showNotification('ليس لديك صلاحية إنشاء مشتريات', 'error'); return; }
        if (type === 'sale' && !user.canCreateSale) { showNotification('ليس لديك صلاحية إنشاء مبيعات', 'error'); return; }
        if (type === 'issue' && !user.canCreateIssue) { showNotification('ليس لديك صلاحية إنشاء صرف', 'error'); return; }
      } else {
        if (type === 'purchase' && !user.canEditPurchase) { showNotification('ليس لديك صلاحية تعديل مشتريات', 'error'); return; }
        if (type === 'sale' && !user.canEditSale) { showNotification('ليس لديك صلاحية تعديل مبيعات', 'error'); return; }
        if (type === 'issue' && !user.canEditIssue) { showNotification('ليس لديك صلاحية تعديل صرف', 'error'); return; }
      }
    }

    // Check mandatory fields from settings
    const mandatory = typeSettings.mandatoryFields;
    const fieldMap: Record<string, { val: any, label: string }> = {
      branchId: { val: branchId, label: 'الفرع' },
      warehouseId: { val: warehouseId, label: 'المخزن' },
      accId: { val: typeSettings.linkingLevel === 'line' ? true : selectedAcc, label: 'الحساب' },
      ccId: { val: typeSettings.linkingLevel === 'line' ? true : selectedCC, label: 'مركز التكلفة' },
      deptId: { val: deptId, label: 'القسم' },
      ref: { val: ref, label: 'المرجع' }
    };

    const missingMandatory = mandatory.filter(f => !fieldMap[f]?.val);
    if (missingMandatory.length > 0) {
      showNotification(`يرجى إكمال الحقول الإجبارية: ${missingMandatory.map(f => fieldMap[f].label).join(', ')}`, 'warning');
      return;
    }

    if (!ref) {
      showNotification('يرجى إدخال رقم المرجع', 'warning');
      return;
    }

    const zeroQtyItems = items.filter(i => i.itemId && i.qty <= 0);
    if (zeroQtyItems.length > 0) {
      showNotification('⚠️ تنبيه: يوجد أصناف بكمية صفر، لن يتم حفظها!', 'warning');
    }

    const validItems = items.filter(i => i.itemId && i.qty > 0);
    if (validItems.length === 0) {
      showNotification('يرجى إضافة صنف واحد على الأقل بكمية صحيحة', 'warning');
      return;
    }

    if (typeSettings.linkingLevel === 'line') {
      const missingLineAcc = validItems.some(i => !i.accId);
      const missingLineCC = validItems.some(i => !i.ccId);
      if (missingLineAcc || missingLineCC) {
        showNotification('يرجى تحديد الحساب ومركز التكلفة لكل صنف', 'warning');
        return;
      }
    }

    // Prevent duplicate items
    const itemIds = validItems.map(i => i.itemId);
    if (new Set(itemIds).size !== itemIds.length) {
      showNotification('⚠️ تنبيه: يوجد أصناف مكررة في السند!', 'warning');
      return;
    }

    // Negative Stock Prevention
    if (!db.allowNegativeStock && type === 'issue') {
      for (const it of validItems) {
        const itemObj = (db.items || []).find(i => i.id === it.itemId);
        if (!itemObj) continue;

        // Calculate current stock
        let stock = 0;
        (db.docs || []).forEach(d => {
          if (d.id === initialDoc?.id) return; // Skip current doc if editing
          (d.items || []).forEach(di => {
            if (di.itemId === it.itemId) {
              const unit = (itemObj.units || []).find(u => u.name === di.unit);
              const factor = unit?.factor || 1;
              if (d.type === 'purchase') stock += di.qty * factor;
              else if (d.type === 'sale' || d.type === 'issue') stock -= di.qty * factor;
            }
          });
        });

        const currentUnit = (itemObj.units || []).find(u => u.name === it.unit);
        const currentFactor = currentUnit?.factor || 1;
        if (stock < (it.qty * currentFactor)) {
          showNotification(`⚠️ عذراً: الرصيد غير كافٍ للصنف (${itemObj.name}). الرصيد المتوفر: ${stock}`, 'error');
          return;
        }
      }
    }

    // Validate required custom fields
    const missingFields = relevantFields.filter(f => f.required && !customValues[f.id]);
    if (missingFields?.length) {
      showNotification(`يرجى إكمال الحقول المطلوبة: ${missingFields.map(f => f.name).join(', ')}`, 'warning');
      return;
    }

    // Ensure totals are correct
    const itemsWithTotals = validItems.map(it => {
      const price = it.price || 0;
      const qty = it.qty || 0;
      const discount = it.discount || 0;
      const expenses = it.expenses || 0;
      return {
        ...it,
        total: (qty * price) - discount + expenses
      };
    });

    setIsSaving(true);
    try {
      await onSave({
        id: initialDoc?.id,
        type,
        date,
        docNum,
        ref,
        description,
        priceType,
        accId: typeSettings.linkingLevel === 'line' ? (itemsWithTotals[0]?.accId || '') : (selectedAcc?.id || ''),
        accType: typeSettings.linkingLevel === 'line' ? (itemsWithTotals[0]?.accType || 'gl') : accType,
        ccId: typeSettings.linkingLevel === 'line' ? (itemsWithTotals[0]?.ccId || '') : (selectedCC?.id || ''),
        branchId,
        warehouseId,
        deptId,
        items: itemsWithTotals,
        customValues
      });
      setIsDirty(false);
    } catch (error) {
      console.error('Save error:', error);
      showNotification('حدث خطأ أثناء الحفظ، يرجى المحاولة مرة أخرى', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        handleSave();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        handleSave();
      }
      if (e.key === 'Insert' || ((e.ctrlKey || e.metaKey) && e.key === '+')) {
        e.preventDefault();
        addRow();
        showNotification('تم إضافة سطر جديد', 'success');
      }
      if (e.key === 'Escape' && onCancel) {
        onCancel();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleSave, addRow, onCancel]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-xl shadow-blue-200">
            <FileText size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">
              {initialDoc ? 'تعديل' : 'إنشاء'} {type === 'purchase' ? 'فاتورة مشتريات' : type === 'sale' ? 'فاتورة مبيعات' : 'سند صرف'}
            </h1>
            <p className="text-slate-500 font-medium mt-0.5">
              {type === 'purchase' ? 'إدخال بيانات فاتورة الشراء وتفاصيل الأصناف' : type === 'sale' ? 'إدخال بيانات فاتورة المبيعات وتفاصيل الأصناف المباعة' : 'إدخال بيانات السند وتفاصيل الأصناف المصروفة'}
            </p>
          </div>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          {initialDoc && (
            <>
              <div className="flex items-center bg-white rounded-2xl border border-slate-200 p-1 shadow-sm">
                <button 
                  onClick={() => onNavigate?.('prev')}
                  className="p-2.5 hover:bg-slate-50 text-slate-600 rounded-xl transition-all"
                  title="السابق"
                >
                  <ChevronRight size={20} />
                </button>
                <div className="px-4 text-xs font-black text-slate-400 border-x border-slate-100 uppercase tracking-widest">
                  {docNum}
                </div>
                <button 
                  onClick={() => onNavigate?.('next')}
                  className="p-2.5 hover:bg-slate-50 text-slate-600 rounded-xl transition-all"
                  title="التالي"
                >
                  <ChevronLeft size={20} />
                </button>
              </div>
              <button 
                onClick={() => onPrint(initialDoc)}
                className="flex items-center gap-2 px-6 py-3 bg-white text-slate-700 rounded-2xl font-black text-xs uppercase tracking-widest border border-slate-200 hover:bg-slate-50 transition-all shadow-sm active:scale-95"
              >
                <Printer size={18} />
                <span className="hidden sm:inline">طباعة</span>
              </button>
              <button 
                onClick={() => {
                  setConfirmModal({
                    title: 'تأكيد الحذف',
                    message: `هل أنت متأكد من حذف ${type === 'purchase' ? 'الفاتورة' : 'السند'} رقم ${docNum}؟`,
                    onConfirm: () => {
                      onDelete?.(initialDoc.id);
                      setConfirmModal(null);
                    }
                  });
                }}
                className="p-3 bg-white text-red-500 rounded-2xl font-black border border-red-100 hover:bg-red-50 transition-all shadow-sm active:scale-95"
                title="حذف"
              >
                <Trash2 size={20} />
              </button>
            </>
          )}
          <div className="flex gap-3">
            <button 
              onClick={() => onNavigate?.('new')}
              className="flex items-center gap-2 px-6 py-3 bg-white text-blue-600 rounded-2xl font-black text-xs uppercase tracking-widest border border-blue-100 hover:bg-blue-50 transition-all shadow-sm active:scale-95"
            >
              <Plus size={18} />
              <span className="hidden sm:inline">جديد</span>
            </button>
            {onCancel && (
              <button 
                onClick={onCancel}
                className="px-6 py-3 rounded-2xl font-black text-slate-400 hover:bg-slate-100 transition-all text-xs uppercase tracking-widest"
              >
                إلغاء
              </button>
            )}
            <button 
              onClick={handleSave}
              className="bg-slate-900 hover:bg-slate-800 text-white px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-slate-200 transition-all flex items-center justify-center gap-2 active:scale-95"
            >
              <Save size={18} />
              حفظ السند
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4 sm:space-y-6">
          <CollapsibleSection
            title="تفاصيل السند"
            subtitle="المعلومات الأساسية والحسابات"
            icon={<Info size={24} />}
            isExpanded={expandedSections.details}
            onToggle={() => toggleSection('details')}
          >
            <div className="space-y-6 sm:space-y-8">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-2">
                <FileText size={12} className="text-blue-500" />
                بيان السند
              </label>
              <textarea 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="اكتب وصفاً مختصراً للسند هنا..."
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all resize-none h-20 bg-slate-50/30 focus:bg-white font-medium"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-2">الفرع *</label>
                <select 
                  value={branchId}
                  onChange={(e) => setBranchId(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all bg-white font-bold"
                >
                  <option value="">اختر الفرع...</option>
                  {allowedBranches.filter(b => b.isLeaf).map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-2">المخزن *</label>
                <select 
                  value={warehouseId}
                  onChange={(e) => setWarehouseId(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all bg-white font-bold"
                >
                  <option value="">اختر المخزن...</option>
                  {allowedWarehouses.filter(w => w.isLeaf && (!branchId || w.branchId === branchId)).map(w => (
                    <option key={w.id} value={w.id}>{w.name}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-2">القسم</label>
                <select 
                  value={deptId}
                  onChange={(e) => setDeptId(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all bg-white font-bold"
                >
                  <option value="">اختر القسم...</option>
                  {db.departments?.filter(d => d.isLeaf).map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-2">رقم السند (آلي)</label>
                <input 
                  type="text" 
                  value={docNum}
                  readOnly
                  className="w-full px-4 py-3 rounded-xl border border-slate-100 bg-slate-50 text-slate-500 font-bold outline-none cursor-not-allowed"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-2">تاريخ السند *</label>
                <input 
                  type="date" 
                  value={date}
                  onChange={(e) => {
                    setDate(e.target.value);
                    if (type === 'sale') {
                      setItems(prev => prev.map(it => ({
                        ...it,
                        price: it.itemId && it.unit ? fetchPrice(it.itemId, it.unit, e.target.value, priceType) : it.price
                      })));
                    }
                  }}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all bg-slate-50/30 focus:bg-white font-bold"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-2">رقم المرجع (يدوي) *</label>
                <input 
                  type="text" 
                  value={ref}
                  onChange={(e) => setRef(e.target.value)}
                  placeholder="رقم السند الدفتري"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all bg-slate-50/30 focus:bg-white font-bold"
                />
              </div>

              {type === 'sale' && (
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider">نوع التسعيرة</label>
                  <select 
                    value={priceType}
                    onChange={(e) => {
                      const newPType = e.target.value as PriceType;
                      setPriceType(newPType);
                      // Update prices
                      setItems(prev => prev.map(it => ({
                        ...it,
                        price: it.itemId && it.unit ? fetchPrice(it.itemId, it.unit, date, newPType) : it.price
                      })));
                    }}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all bg-white font-bold"
                  >
                    <option value="retail">تجزئة</option>
                    <option value="wholesale">جملة</option>
                    <option value="internal">فروع داخلية</option>
                    <option value="external">فروع خارجية</option>
                  </select>
                </div>
              )}

              {/* Custom Fields */}
              {relevantFields.map(field => (
                <div key={field.id} className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
                    {field.name} {field.required && '*'}
                  </label>
                  {field.type === 'select' ? (
                    <select
                      value={customValues[field.id] || ''}
                      onChange={(e) => setCustomValues({ ...customValues, [field.id]: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all bg-white font-bold"
                    >
                      <option value="">اختر...</option>
                      {field.options?.map(opt => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  ) : (
                    <input 
                      type={field.type} 
                      value={customValues[field.id] || ''}
                      onChange={(e) => setCustomValues({ ...customValues, [field.id]: e.target.value })}
                      placeholder={field.name}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all bg-slate-50/30 focus:bg-white font-bold"
                    />
                  )}
                </div>
              ))}
            </div>

            {typeSettings.linkingLevel !== 'line' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-slate-50">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider">نوع الحساب</label>
                  <select
                    value={accType}
                    onChange={(e) => {
                      setAccType(e.target.value as AccountCategory);
                      setSelectedAcc(null);
                      setAccSearch('');
                    }}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all bg-white font-bold"
                  >
                    <option value="gl">استاذ عام حسابات</option>
                    <option value="customer-supplier">عملاء وموردين</option>
                    <option value="fund">صناديق</option>
                    <option value="bank">دليل بنوك</option>
                    <option value="warehouse">مخازن</option>
                    <option value="all">بحث في الكل</option>
                  </select>
                </div>

                <div className="space-y-2 relative">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
                  {type === 'purchase' ? 'المورد / الحساب *' : 'الحساب *'}
                </label>
                  <div className="relative">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <input 
                      type="text" 
                      value={selectedAcc?.name || accSearch}
                      onFocus={(e) => {
                        e.target.select();
                        setStartedTyping(prev => ({ ...prev, 'acc-main': false }));
                      }}
                      onChange={(e) => handleSearchChange('main', e.target.value, 'acc')}
                      placeholder="ابحث عن حساب..."
                      className="w-full pr-10 pl-10 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all text-base font-bold bg-slate-50/30 focus:bg-white"
                    />
                    {accSearch && (
                      <button 
                        onClick={() => { setAccSearch(''); setSelectedAcc(null); }}
                        className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        <X size={16} />
                      </button>
                    )}
                  </div>
                  <AnimatePresence>
                    {accSearch && !selectedAcc && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute z-50 w-full bottom-full mb-1 bg-white border border-slate-200 rounded-xl shadow-xl max-h-48 overflow-y-auto"
                      >
                        {filteredAccounts.length > 0 ? (
                          filteredAccounts.map(a => (
                            <button 
                              key={a.id}
                              onClick={() => {
                                setSelectedAcc(a);
                                setAccSearch(a.name);
                              }}
                              className="w-full text-right px-4 py-3 hover:bg-slate-50 border-b border-slate-50 last:border-0 transition-colors flex items-center justify-between"
                            >
                              <span className="font-medium">{a.name}</span>
                              <span className="text-[10px] bg-slate-100 px-2 py-1 rounded text-slate-500">{a.code}</span>
                            </button>
                          ))
                        ) : (
                          <div className="p-4 text-center text-slate-400 text-sm">
                            لا يوجد نتائج لهذا البحث
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="space-y-2 relative">
                  <label className="text-sm font-bold text-slate-700">مركز التكلفة *</label>
                  <div className="relative">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="text" 
                      value={selectedCC?.name || ccSearch}
                      onFocus={(e) => {
                        e.target.select();
                        setStartedTyping(prev => ({ ...prev, 'cc-main': false }));
                      }}
                      onChange={(e) => handleSearchChange('main', e.target.value, 'cc')}
                      placeholder="ابحث عن مركز تكلفة..."
                      className="w-full pr-10 pl-10 py-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all text-lg font-bold"
                    />
                    {ccSearch && (
                      <button 
                        onClick={() => { setCcSearch(''); setSelectedCC(null); }}
                        className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        <X size={18} />
                      </button>
                    )}
                  </div>
                  <AnimatePresence>
                    {ccSearch && !selectedCC && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute z-50 w-full bottom-full mb-1 bg-white border border-slate-200 rounded-xl shadow-xl max-h-48 overflow-y-auto"
                      >
                        {filteredCenters.length > 0 ? (
                          filteredCenters.map(c => (
                            <button 
                              key={c.id}
                              onClick={() => {
                                setSelectedCC(c);
                                setCcSearch(c.name);
                              }}
                              className="w-full text-right px-4 py-3 hover:bg-slate-50 border-b border-slate-50 last:border-0 transition-colors flex items-center justify-between"
                            >
                              <span className="font-medium">{c.name}</span>
                              <span className="text-[10px] bg-slate-100 px-2 py-1 rounded text-slate-500">{c.code}</span>
                            </button>
                          ))
                        ) : (
                          <div className="p-4 text-center text-slate-400 text-sm">
                            لا يوجد نتائج لهذا البحث
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            )}
            </div>
          </CollapsibleSection>

          <CollapsibleSection
            title="الأصناف والكميات"
            subtitle="تفاصيل المواد والأسعار"
            icon={<Package size={24} />}
            isExpanded={expandedSections.items}
            onToggle={() => toggleSection('items')}
            badge={
              <div className="bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                {items.filter(i => i.itemId).length} صنف
              </div>
            }
          >
            <div className="space-y-4">
              <div className="flex justify-between items-center bg-white p-3 rounded-2xl border border-slate-100 shadow-sm">
                <div className="flex items-center gap-3">
                  <button onClick={downloadTemplate} className="text-[10px] font-black text-slate-400 hover:text-blue-600 transition-colors uppercase tracking-widest bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">نموذج الإكسل</button>
                  <label className="text-[10px] font-black text-slate-400 hover:text-blue-600 transition-colors uppercase tracking-widest bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100 cursor-pointer">
                    استيراد إكسل
                    <input type="file" className="hidden" accept=".xlsx,.xls" onChange={importFromExcel} />
                  </label>
                </div>
                <button 
                  onClick={addRow}
                  className="bg-blue-600 text-white px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 active:scale-95"
                >
                  <Plus size={14} />
                  إضافة سطر جديد
                </button>
              </div>
              
              <div className="border border-slate-100 rounded-2xl overflow-visible bg-slate-50/30">
                {/* Desktop Table View */}
                <div className="hidden md:block">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-slate-50/80 border-b border-slate-100">
                        <th className="p-3 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-12">#</th>
                        <th className="p-3 text-right text-[10px] font-black text-slate-400 uppercase tracking-widest">بيان الصنف</th>
                        {typeSettings.linkingLevel === 'line' && (
                          <>
                            <th className="p-3 text-right text-[10px] font-black text-slate-400 uppercase tracking-widest w-32">نوع الحساب</th>
                            <th className="p-3 text-right text-[10px] font-black text-slate-400 uppercase tracking-widest">الحساب</th>
                            <th className="p-3 text-right text-[10px] font-black text-slate-400 uppercase tracking-widest">مركز التكلفة</th>
                          </>
                        )}
                        {isFieldVisible('unit') && <th className="p-3 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-32">الوحدة</th>}
                        {isFieldVisible('qty') && <th className="p-3 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-20">الكمية</th>}
                        {type === 'purchase' && (
                          <>
                            {isFieldVisible('price') && <th className="p-3 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-20">السعر</th>}
                            {isFieldVisible('discount') && <th className="p-3 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-20">الخصم</th>}
                            {isFieldVisible('expenses') && <th className="p-3 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-20">المصروفات</th>}
                            {isFieldVisible('total') && <th className="p-3 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-24">الإجمالي</th>}
                          </>
                        )}
                        <th className="p-3 w-10"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {items.map((row, idx) => {
                        const item = (db.items || []).find(i => i.id === row.itemId);
                        const fieldConfig = typeSettings.fieldConfig || {};
                        
                        // Long press logic for serial number
                        let pressTimer: any;
                        const handlePressStart = () => {
                          pressTimer = setTimeout(() => addRowBefore(idx), 800);
                        };
                        const handlePressEnd = () => {
                          clearTimeout(pressTimer);
                        };

                        return (
                          <tr key={row.id} className="group hover:bg-blue-50/30 transition-colors">
                            <td 
                              className="p-3 text-center text-[10px] font-black text-slate-300 group-hover:text-blue-400 transition-colors border-l border-slate-100 w-10 cursor-pointer select-none"
                              onMouseDown={handlePressStart}
                              onMouseUp={handlePressEnd}
                              onMouseLeave={handlePressEnd}
                              onTouchStart={handlePressStart}
                              onTouchEnd={handlePressEnd}
                              title="اضغط مطولاً لإضافة سطر قبل هذا السطر"
                            >
                              {(idx + 1).toString().padStart(2, '0')}
                            </td>
                            <td className="p-3 relative">
                              <div className="relative">
                                <input 
                                  type="text" 
                                  id={`item-input-${idx}`}
                                  value={item?.name || (itemSearchIdx === idx ? itemSearchQuery : '')}
                                  onFocus={(e) => {
                                    e.target.select();
                                    setStartedTyping(prev => ({ ...prev, [`item-${idx}`]: false }));
                                  }}
                                  onChange={(e) => handleSearchChange(idx, e.target.value, 'item')}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter' && row.itemId) {
                                      e.preventDefault();
                                      document.getElementById(`qty-input-${idx}`)?.focus();
                                    }
                                  }}
                                  placeholder="ابحث عن صنف..."
                                  className="w-full px-3 py-2.5 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none text-sm font-bold transition-all bg-slate-50/30 focus:bg-white"
                                />
                                {(item?.name || (itemSearchIdx === idx && itemSearchQuery)) && (
                                  <button 
                                    onClick={() => {
                                      updateRow(idx, 'itemId', '');
                                      setItemSearchIdx(null);
                                      setItemSearchQuery('');
                                    }}
                                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500"
                                  >
                                    <X size={14} />
                                  </button>
                                )}
                              </div>
                              <AnimatePresence>
                                {itemSearchIdx === idx && itemSearchQuery && !row.itemId && (
                                  <motion.div 
                                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                                    animate={{ opacity: 1, scale: 1, y: 0 }}
                                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                                    className="absolute z-50 w-full min-w-[300px] bottom-full mb-1 bg-white border border-slate-200 rounded-xl shadow-2xl max-h-64 overflow-y-auto"
                                  >
                                    {filteredItems.length > 0 ? (
                                      filteredItems.map(i => (
                                        <button 
                                          key={i.id}
                                          onClick={() => {
                                            if (items.some(row => row.itemId === i.id)) {
                                              showNotification('هذا صنف موجود مسبقاً في السند', 'warning');
                                              return;
                                            }
                                            updateRow(idx, 'itemId', i.id);
                                            const defaultUnit = type === 'purchase' ? i.defaultPurchaseUnit : 
                                                              type === 'sale' ? i.defaultSaleUnit : 
                                                              type === 'issue' ? i.defaultIssueUnit : 
                                                              i.units[0]?.name;
                                            updateRow(idx, 'unit', defaultUnit || i.units[0]?.name || '');
                                            
                                            // Auto-price for sales
                                            if (type === 'sale') {
                                              const unitName = defaultUnit || i.units[0]?.name || '';
                                              const priceObj = i.prices?.find(p => p.unitName === unitName);
                                              if (priceObj) {
                                                updateRow(idx, 'price', priceObj.price);
                                              }
                                            }

                                            setItemSearchIdx(null);
                                            setItemSearchQuery('');
                                            // Focus quantity input
                                            setTimeout(() => {
                                              const qtyInput = document.getElementById(`qty-input-${idx}`);
                                              if (qtyInput) qtyInput.focus();
                                            }, 50);
                                          }}
                                          className="w-full text-right px-4 py-4 hover:bg-blue-50 border-b border-slate-50 last:border-0 transition-colors flex items-center justify-between"
                                        >
                                          <div className="flex flex-col">
                                            <span className="font-bold text-slate-800">{i.name}</span>
                                            <span className="text-[10px] text-slate-400">{i.code}</span>
                                          </div>
                                          <ChevronLeft size={16} className="text-blue-400" />
                                        </button>
                                      ))
                                    ) : (
                                      <div className="p-4 text-center text-slate-400 text-sm">
                                        لا يوجد نتائج لهذا البحث
                                      </div>
                                    )}
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </td>
                            {typeSettings.linkingLevel === 'line' && (
                              <>
                                <td className="p-3 w-32">
                                  <select
                                    value={row.accType || 'gl'}
                                    onChange={(e) => {
                                      updateRow(idx, 'accType', e.target.value as AccountCategory);
                                      updateRow(idx, 'accId', '');
                                    }}
                                    className="w-full px-2 py-2.5 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none text-xs font-bold bg-white cursor-pointer transition-all"
                                  >
                                    <option value="gl">استاذ عام حسابات</option>
                                    <option value="customer-supplier">عملاء وموردين</option>
                                    <option value="fund">صناديق</option>
                                    <option value="bank">دليل بنوك</option>
                                    <option value="warehouse">مخازن</option>
                                    <option value="all">بحث في الكل</option>
                                  </select>
                                </td>
                                <td className="p-3 relative">
                                  <div className="relative">
                                    <input 
                                      type="text" 
                                      value={(() => {
                                        if (accSearchIdx === idx) return rowAccSearchQuery;
                                        const category = row.accType || 'gl';
                                        if (category === 'gl') return (db.accounts || []).find(a => a.id === row.accId)?.name || '';
                                        if (category === 'customer-supplier') return db.customersSuppliers?.find(a => a.accId === row.accId)?.name || '';
                                        if (category === 'fund') return db.funds?.find(a => a.accId === row.accId)?.name || '';
                                        if (category === 'bank') return db.banks?.find(a => a.accId === row.accId)?.name || '';
                                        if (category === 'warehouse') return db.warehouses?.find(a => a.accId === row.accId)?.name || '';
                                        if (category === 'all') {
                                          return (db.accounts || []).find(a => a.id === row.accId)?.name || 
                                                 db.customersSuppliers?.find(a => a.accId === row.accId)?.name ||
                                                 db.funds?.find(a => a.accId === row.accId)?.name ||
                                                 db.banks?.find(a => a.accId === row.accId)?.name ||
                                                 db.warehouses?.find(a => a.accId === row.accId)?.name || '';
                                        }
                                        return '';
                                      })()}
                                      onFocus={(e) => {
                                        e.target.select();
                                        setStartedTyping(prev => ({ ...prev, [`acc-${idx}`]: false }));
                                      }}
                                      onChange={(e) => handleSearchChange(idx, e.target.value, 'acc')}
                                      placeholder="الحساب..."
                                      className="w-full px-3 py-2.5 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none text-xs font-bold transition-all bg-slate-50/30 focus:bg-white"
                                    />
                                  </div>
                                  <AnimatePresence>
                                    {accSearchIdx === idx && rowAccSearchQuery && !row.accId && (
                                      <motion.div className="absolute z-50 w-full min-w-[200px] bottom-full mb-1 bg-white border border-slate-200 rounded-xl shadow-2xl max-h-48 overflow-y-auto">
                                        {filteredAccounts.map(a => (
                                          <button 
                                            key={a.id}
                                            onClick={() => {
                                              updateRow(idx, 'accId', a.id);
                                              setAccSearchIdx(null);
                                              setRowAccSearchQuery('');
                                            }}
                                            className="w-full text-right px-3 py-2 hover:bg-slate-50 text-sm flex justify-between items-center"
                                          >
                                            <span>{a.name}</span>
                                            <span className="text-[10px] text-slate-400">{a.code}</span>
                                          </button>
                                        ))}
                                      </motion.div>
                                    )}
                                  </AnimatePresence>
                                </td>
                                <td className="p-3 relative">
                                  <div className="relative">
                                    <input 
                                      type="text" 
                                      value={(db.centers || []).find(c => c.id === row.ccId)?.name || (ccSearchIdx === idx ? rowCcSearchQuery : '')}
                                      onFocus={(e) => {
                                        e.target.select();
                                        setStartedTyping(prev => ({ ...prev, [`cc-${idx}`]: false }));
                                      }}
                                      onChange={(e) => handleSearchChange(idx, e.target.value, 'cc')}
                                      placeholder="المركز..."
                                      className="w-full px-3 py-2.5 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none text-xs font-bold transition-all bg-slate-50/30 focus:bg-white"
                                    />
                                  </div>
                                  <AnimatePresence>
                                    {ccSearchIdx === idx && rowCcSearchQuery && !row.ccId && (
                                      <motion.div className="absolute z-50 w-full min-w-[200px] bottom-full mb-1 bg-white border border-slate-200 rounded-xl shadow-2xl max-h-48 overflow-y-auto">
                                        {filteredCenters.map(c => (
                                          <button 
                                            key={c.id}
                                            onClick={() => {
                                              updateRow(idx, 'ccId', c.id);
                                              setCcSearchIdx(null);
                                              setRowCcSearchQuery('');
                                            }}
                                            className="w-full text-right px-3 py-2 hover:bg-slate-50 text-sm flex justify-between items-center"
                                          >
                                            <span>{c.name}</span>
                                            <span className="text-[10px] text-slate-400">{c.code}</span>
                                          </button>
                                        ))}
                                      </motion.div>
                                    )}
                                  </AnimatePresence>
                                </td>
                              </>
                            )}
                            {isFieldVisible('unit') && (
                              <td className="p-3 w-32">
                                <select 
                                  value={row.unit}
                                  onChange={(e) => updateRow(idx, 'unit', e.target.value)}
                                  className="w-full px-2 py-2.5 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none text-xs font-bold bg-white cursor-pointer transition-all"
                                >
                                  {item?.units?.map(u => (
                                    <option key={u.name} value={u.name}>{u.name}</option>
                                  ))}
                                  {!item && <option value="">-</option>}
                                </select>
                              </td>
                            )}
                            {isFieldVisible('qty') && (
                              <td className="p-3">
                                <input 
                                  type="number" 
                                  id={`qty-input-${idx}`}
                                  value={row.qty ?? 0}
                                  onChange={(e) => updateRow(idx, 'qty', parseFloat(e.target.value) || 0)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      if (idx === items.length - 1) {
                                        addRow();
                                      }
                                      setTimeout(() => {
                                        const nextItemInput = document.getElementById(`item-input-${idx + 1}`);
                                        if (nextItemInput) {
                                          nextItemInput.focus();
                                          nextItemInput.scrollIntoView({ block: 'center', behavior: 'smooth' });
                                        }
                                      }, 100);
                                    }
                                  }}
                                  className="w-full px-2 py-2.5 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none text-center text-sm font-black transition-all bg-slate-50/30 focus:bg-white"
                                />
                              </td>
                            )}
                            {type === 'purchase' && (
                              <>
                                {isFieldVisible('price') && (
                                  <td className="p-3">
                                    <input 
                                      type="number" 
                                      value={row.price ?? 0}
                                      onChange={(e) => updateRow(idx, 'price', parseFloat(e.target.value) || 0)}
                                      className="w-full px-2 py-2.5 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none text-center text-sm font-black transition-all bg-slate-50/30 focus:bg-white"
                                    />
                                  </td>
                                )}
                                {isFieldVisible('discount') && (
                                  <td className="p-3">
                                    <input 
                                      type="number" 
                                      value={row.discount ?? 0}
                                      onChange={(e) => updateRow(idx, 'discount', parseFloat(e.target.value) || 0)}
                                      className="w-full px-2 py-2.5 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none text-center text-sm font-black transition-all bg-rose-50/30 focus:bg-white text-rose-600"
                                    />
                                  </td>
                                )}
                                {isFieldVisible('expenses') && (
                                  <td className="p-3">
                                    <input 
                                      type="number" 
                                      value={row.expenses ?? 0}
                                      onChange={(e) => updateRow(idx, 'expenses', parseFloat(e.target.value) || 0)}
                                      className="w-full px-2 py-2.5 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none text-center text-sm font-black transition-all bg-blue-50/30 focus:bg-white text-blue-600"
                                    />
                                  </td>
                                )}
                                {isFieldVisible('total') && (
                                  <td className="p-3">
                                    <div className="w-full px-2 py-2.5 rounded-lg bg-slate-100 text-center text-sm font-black text-slate-700">
                                      {(row.total || 0).toLocaleString()}
                                    </div>
                                  </td>
                                )}
                              </>
                            )}
                            <td className="p-3">
                              <button 
                                onClick={() => removeRow(idx)}
                                className="text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                              >
                                <Trash2 size={18} />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                    <tfoot>
                      <tr className="bg-slate-50/50 font-bold">
                        <td colSpan={typeSettings.linkingLevel === 'line' ? 3 : 2} className="p-3 text-left text-slate-500 text-xs">إجمالي الكمية</td>
                        <td className="p-3 text-center text-blue-600 border-t border-slate-100">
                          {items.reduce((sum, i) => sum + (i.qty || 0), 0)}
                        </td>
                        <td></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                {/* Mobile Card View */}
                <div className="md:hidden divide-y divide-slate-100">
                  {items.map((row, idx) => {
                    const item = db.items.find(i => i.id === row.itemId);
                    return (
                      <div key={row.id} className="p-4 space-y-4 bg-white">
                        {/* Mobile Card Header */}
                        <div className="flex items-center justify-between bg-slate-50 -mx-4 -mt-4 p-3 border-b border-slate-100">
                          <div className="flex items-center gap-3">
                            <span 
                              className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-xs font-bold text-white shadow-sm cursor-pointer select-none"
                              onMouseDown={() => {
                                const timer = setTimeout(() => addRowBefore(idx), 800);
                                (window as any)._mobileTimer = timer;
                              }}
                              onMouseUp={() => clearTimeout((window as any)._mobileTimer)}
                              onMouseLeave={() => clearTimeout((window as any)._mobileTimer)}
                              onTouchStart={() => {
                                const timer = setTimeout(() => addRowBefore(idx), 800);
                                (window as any)._mobileTimer = timer;
                              }}
                              onTouchEnd={() => clearTimeout((window as any)._mobileTimer)}
                            >
                              {idx + 1}
                            </span>
                            <div className="flex flex-col">
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">كود الصنف</span>
                              <span className="text-xs font-bold text-slate-700">
                                {item?.code || '---'}
                              </span>
                            </div>
                          </div>
                          <button 
                            onClick={() => removeRow(idx)}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-xl transition-colors bg-white shadow-sm border border-red-100"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                        
                        {/* Item Search */}
                        <div className="relative">
                          <label className="text-[10px] font-bold text-slate-500 mb-1 block">بيان الصنف المختار *</label>
                          <div className="relative">
                            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                            <input 
                              type="text" 
                              value={item?.name || (itemSearchIdx === idx ? itemSearchQuery : '')}
                              onFocus={(e) => e.target.select()}
                              onChange={(e) => handleSearchChange(idx, e.target.value, 'item')}
                              placeholder="ابحث عن صنف بالاسم أو الكود..."
                              className="w-full pr-10 pl-4 py-3.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-base font-bold bg-slate-50/50"
                            />
                          </div>
                          <AnimatePresence>
                            {itemSearchIdx === idx && itemSearchQuery && !row.itemId && filteredItems.length > 0 && (
                              <motion.div 
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: 10 }}
                                className="absolute z-50 w-full bottom-full mb-2 bg-white border border-slate-200 rounded-2xl shadow-2xl max-h-60 overflow-y-auto"
                              >
                                {filteredItems.map(i => (
                                  <button 
                                    key={i.id}
                                    onClick={() => {
                                      if (items.some(row => row.itemId === i.id)) {
                                        showNotification('هذا صنف موجود مسبقاً في السند', 'warning');
                                        return;
                                      }
                                      updateRow(idx, 'itemId', i.id);
                                      const defaultUnit = type === 'purchase' ? i.defaultPurchaseUnit : 
                                                        type === 'sale' ? i.defaultSaleUnit : 
                                                        type === 'issue' ? i.defaultIssueUnit : 
                                                        i.units[0]?.name;
                                      updateRow(idx, 'unit', defaultUnit || i.units[0]?.name || '');
                                      setItemSearchIdx(null);
                                      setItemSearchQuery('');
                                      // Focus quantity input
                                      setTimeout(() => {
                                        const qtyInput = document.getElementById(`qty-input-mobile-${idx}`);
                                        if (qtyInput) qtyInput.focus();
                                      }, 50);
                                    }}
                                    className="w-full text-right px-4 py-4 hover:bg-blue-50 border-b border-slate-50 last:border-0 flex items-center justify-between"
                                  >
                                    <div className="flex flex-col">
                                      <span className="font-bold text-slate-800">{i.name}</span>
                                      <span className="text-[10px] text-slate-400">{i.code}</span>
                                    </div>
                                    <ChevronLeft size={16} className="text-blue-400" />
                                  </button>
                                ))}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>

                        {/* Linking Level Fields (Mobile) */}
                        {typeSettings.linkingLevel === 'line' && (
                          <div className="space-y-3">
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold text-slate-500">نوع الحساب</label>
                              <select
                                value={row.accType || 'gl'}
                                onChange={(e) => {
                                  updateRow(idx, 'accType', e.target.value as AccountCategory);
                                  updateRow(idx, 'accId', '');
                                }}
                                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none text-xs font-bold bg-white"
                              >
                                <option value="gl">استاذ عام حسابات</option>
                                <option value="customer-supplier">عملاء وموردين</option>
                                <option value="fund">صناديق</option>
                                <option value="bank">دليل بنوك</option>
                                <option value="warehouse">مخازن</option>
                                <option value="all">بحث في الكل</option>
                              </select>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div className="space-y-1 relative">
                                <label className="text-[10px] font-bold text-slate-500">الحساب</label>
                              <input 
                                type="text" 
                                value={(() => {
                                  if (accSearchIdx === idx) return rowAccSearchQuery;
                                  const category = row.accType || 'gl';
                                  if (category === 'gl') return (db.accounts || []).find(a => a.id === row.accId)?.name || '';
                                  if (category === 'customer-supplier') return db.customersSuppliers?.find(a => a.accId === row.accId)?.name || '';
                                  if (category === 'fund') return db.funds?.find(a => a.accId === row.accId)?.name || '';
                                  if (category === 'bank') return db.banks?.find(a => a.accId === row.accId)?.name || '';
                                  if (category === 'warehouse') return db.warehouses?.find(a => a.accId === row.accId)?.name || '';
                                  if (category === 'all') {
                                    return (db.accounts || []).find(a => a.id === row.accId)?.name || 
                                           db.customersSuppliers?.find(a => a.accId === row.accId)?.name ||
                                           db.funds?.find(a => a.accId === row.accId)?.name ||
                                           db.banks?.find(a => a.accId === row.accId)?.name ||
                                           db.warehouses?.find(a => a.accId === row.accId)?.name || '';
                                  }
                                  return '';
                                })()}
                                onFocus={(e) => e.target.select()}
                                onChange={(e) => handleSearchChange(idx, e.target.value, 'acc')}
                                placeholder="الحساب..."
                                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none text-xs font-bold"
                              />
                              <AnimatePresence>
                                {accSearchIdx === idx && rowAccSearchQuery && !row.accId && (
                                  <motion.div className="absolute z-50 w-full min-w-[200px] bottom-full mb-1 bg-white border border-slate-200 rounded-xl shadow-2xl max-h-48 overflow-y-auto">
                                    {filteredAccounts.map(a => (
                                      <button 
                                        key={a.id}
                                        onClick={() => {
                                          updateRow(idx, 'accId', a.id);
                                          setAccSearchIdx(null);
                                          setRowAccSearchQuery('');
                                        }}
                                        className="w-full text-right px-3 py-2 hover:bg-slate-50 text-xs flex justify-between items-center"
                                      >
                                        <span>{a.name}</span>
                                        <span className="text-[10px] text-slate-400">{a.code}</span>
                                      </button>
                                    ))}
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </div>
                            <div className="space-y-1 relative">
                              <label className="text-[10px] font-bold text-slate-500">مركز التكلفة</label>
                              <input 
                                type="text" 
                                value={(db.centers || []).find(c => c.id === row.ccId)?.name || (ccSearchIdx === idx ? rowCcSearchQuery : '')}
                                onFocus={(e) => e.target.select()}
                                onChange={(e) => handleSearchChange(idx, e.target.value, 'cc')}
                                placeholder="المركز..."
                                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none text-xs font-bold"
                              />
                              <AnimatePresence>
                                {ccSearchIdx === idx && rowCcSearchQuery && !row.ccId && (
                                  <motion.div className="absolute z-50 w-full min-w-[200px] bottom-full mb-1 bg-white border border-slate-200 rounded-xl shadow-2xl max-h-48 overflow-y-auto">
                                    {filteredCenters.map(c => (
                                      <button 
                                        key={c.id}
                                        onClick={() => {
                                          updateRow(idx, 'ccId', c.id);
                                          setCcSearchIdx(null);
                                          setRowCcSearchQuery('');
                                        }}
                                        className="w-full text-right px-3 py-2 hover:bg-slate-50 text-xs flex justify-between items-center"
                                      >
                                        <span>{c.name}</span>
                                        <span className="text-[10px] text-slate-400">{c.code}</span>
                                      </button>
                                    ))}
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </div>
                          </div>
                        </div>
                        )}

                        {/* Unit and Qty (Mobile) */}
                        <div className="grid grid-cols-2 gap-3">
                          {isFieldVisible('unit') && (
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold text-slate-500">الوحدة</label>
                              <select 
                                value={row.unit}
                                onChange={(e) => updateRow(idx, 'unit', e.target.value)}
                                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none text-xs bg-white font-bold"
                              >
                                {item?.units?.map(u => (
                                  <option key={u.name} value={u.name}>{u.name}</option>
                                ))}
                                {!item && <option value="">-</option>}
                              </select>
                            </div>
                          )}
                          {isFieldVisible('qty') && (
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold text-slate-500">الكمية</label>
                              <input 
                                type="number" 
                                id={`qty-input-mobile-${idx}`}
                                value={row.qty ?? 0}
                                onChange={(e) => updateRow(idx, 'qty', parseFloat(e.target.value) || 0)}
                                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none text-center font-bold text-blue-600"
                              />
                            </div>
                          )}
                        </div>

                        {/* Pricing Fields (Mobile) */}
                        {(type === 'purchase' || type === 'sale') && (
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100">
                            {isFieldVisible('price') && (
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-slate-500">السعر</label>
                                <input 
                                  type="number" 
                                  value={row.price ?? 0}
                                  onChange={(e) => updateRow(idx, 'price', parseFloat(e.target.value) || 0)}
                                  className="w-full px-2 py-2 rounded-lg border border-slate-200 outline-none text-center font-bold text-sm bg-white"
                                />
                              </div>
                            )}
                            {isFieldVisible('discount') && (
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-slate-500">الخصم</label>
                                <input 
                                  type="number" 
                                  value={row.discount ?? 0}
                                  onChange={(e) => updateRow(idx, 'discount', parseFloat(e.target.value) || 0)}
                                  className="w-full px-2 py-2 rounded-lg border border-slate-200 outline-none text-center font-bold text-sm text-red-600 bg-white"
                                />
                              </div>
                            )}
                            {isFieldVisible('expenses') && (
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-slate-500">المصروفات</label>
                                <input 
                                  type="number" 
                                  value={row.expenses ?? 0}
                                  onChange={(e) => updateRow(idx, 'expenses', parseFloat(e.target.value) || 0)}
                                  className="w-full px-2 py-2 rounded-lg border border-slate-200 outline-none text-center font-bold text-sm text-blue-600 bg-white"
                                />
                              </div>
                            )}
                            {isFieldVisible('total') && (
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-slate-500">الإجمالي</label>
                                <div className="w-full px-2 py-2 rounded-lg border border-transparent text-center font-bold text-sm text-slate-900">
                                  {(row.total || 0).toLocaleString()}
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </CollapsibleSection>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6 sticky top-24">
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-white border border-slate-100 flex items-center justify-center text-blue-600 shadow-sm">
                <FileText size={24} />
              </div>
              <div>
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">نوع السند</h4>
                <div className="text-lg font-black text-slate-800">{typeSettings.name}</div>
              </div>
            </div>

            <h3 className="font-black text-slate-800 flex items-center gap-2 text-xs uppercase tracking-widest pt-4 border-t border-slate-50">
              <BarChart3 size={14} className="text-blue-500" />
              ملخص السند
            </h3>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center p-5 bg-slate-50 rounded-2xl border border-slate-100 group hover:bg-blue-50 hover:border-blue-100 transition-all">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider group-hover:text-blue-600">إجمالي الأصناف</span>
                <span className="text-2xl font-black text-slate-700 group-hover:text-blue-700 font-mono tracking-tighter">
                  {items.filter(i => i.itemId).length.toString().padStart(2, '0')}
                </span>
              </div>
              <div className="flex justify-between items-center p-5 bg-slate-50 rounded-2xl border border-slate-100 group hover:bg-indigo-50 hover:border-indigo-100 transition-all">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider group-hover:text-indigo-600">إجمالي الكميات</span>
                <span className="text-2xl font-black text-slate-700 group-hover:text-indigo-700 font-mono tracking-tighter">
                  {items.reduce((sum, i) => sum + (i.qty || 0), 0)}
                </span>
              </div>
              
              {/* Summary Totals */}
              {(type === 'purchase' || type === 'sale') && (
                <div className="p-6 rounded-2xl bg-emerald-600 border border-emerald-500 shadow-sm flex flex-col items-center gap-3 transition-all">
                  <div className="flex items-center gap-2">
                    <div className="bg-white/20 p-1 rounded-full">
                      <Save size={12} className="text-white" />
                    </div>
                    <span className="text-xs font-black text-white uppercase tracking-widest">إجمالي السند</span>
                  </div>
                  <div className="text-center">
                    <span className="text-3xl font-black text-white font-mono tracking-tighter">
                      {items.reduce((sum, i) => sum + (i.total || 0), 0).toLocaleString()}
                    </span>
                  </div>
                </div>
              )}

              <div className="pt-6 border-t border-slate-50 space-y-4">
                <div className="space-y-1">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">الحساب المختار</div>
                  <div className="text-sm font-bold text-blue-600 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                    {typeSettings.linkingLevel === 'line' ? 'حسابات متعددة (حسب السطر)' : (selectedAcc?.name || 'لم يتم الاختيار')}
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">مركز التكلفة</div>
                  <div className="text-sm font-bold text-purple-600 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                    {typeSettings.linkingLevel === 'line' ? 'مراكز متعددة (حسب السطر)' : (selectedCC?.name || 'لم يتم الاختيار')}
                  </div>
                </div>
              </div>

              {initialDoc && (
                <div className="mt-6 pt-6 border-t border-slate-100 space-y-4">
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">سجل التدقيق</h4>
                  <div className="text-[10px] text-slate-500 grid grid-cols-2 gap-y-3">
                    <div className="font-medium">تاريخ الحفظ:</div>
                    <div className="text-left font-black text-slate-700">{new Date(initialDoc.createdAt).toLocaleString('ar-YE')}</div>
                    <div className="font-medium">المستخدم:</div>
                    <div className="text-left font-black text-slate-700">{db.users.find(u => u.id === initialDoc.createdBy)?.name || initialDoc.createdBy}</div>
                    <div className="font-medium">مرات الطباعة:</div>
                    <div className="text-left font-black text-slate-700">{initialDoc.printCount || 0}</div>
                    <div className="font-medium">مرات التعديل:</div>
                    <div className="text-left font-black text-slate-700">{initialDoc.editCount || 0}</div>
                  </div>
                </div>
              )}
            </div>
            <div className="pt-4">
              <button 
                onClick={handleSave}
                disabled={isSaving}
                className={`w-full ${isSaving ? 'bg-slate-400 cursor-not-allowed' : 'bg-slate-900 hover:bg-black'} text-white py-4 rounded-2xl font-black shadow-xl shadow-slate-200 transition-all active:scale-95 flex items-center justify-center gap-2 text-xs uppercase tracking-widest`}
              >
                {isSaving ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Save size={16} />
                )}
                {isSaving ? 'جاري الحفظ...' : 'حفظ السند'}
              </button>
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {importState.show && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4" dir="rtl">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setImportState({ ...importState, show: false })}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-xl rounded-3xl shadow-2xl p-8"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h3 className="text-2xl font-black text-slate-900">ربط أعمدة الإكسل</h3>
                  <p className="text-slate-500 text-sm mt-1">طابق حقول المستند مع أعمدة ملف الإكسل</p>
                </div>
                <button onClick={() => setImportState({ ...importState, show: false })} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X size={24} className="text-slate-400" />
                </button>
              </div>

              <div className="space-y-4 mb-10 min-h-[300px]">
                {[
                  { key: 'itemCode', label: 'كود الصنف / ID', required: true },
                  { key: 'unit', label: 'الوحدة', required: false },
                  { key: 'qty', label: 'الكمية', required: true },
                  { key: 'price', label: 'السعر', required: false },
                  { key: 'discount', label: 'الخصم', required: false },
                  { key: 'expenses', label: 'المصاريف', required: false },
                  { key: 'accCode', label: 'كود الحساب (ربط سطور)', required: false },
                  { key: 'ccCode', label: 'كود مركز التكلفة', required: false },
                ].map(field => (
                  <div key={field.key} className="flex items-center justify-between gap-6">
                    <label className="text-sm font-black text-slate-700 min-w-[140px] flex items-center gap-2">
                       <div className="w-1.5 h-6 bg-blue-100 rounded-full" />
                      {field.label}
                      {field.required && <span className="text-red-500 mr-1">*</span>}
                    </label>
                    <select 
                      value={importState.mapping[field.key] || ''}
                      onChange={e => setImportState({
                        ...importState,
                        mapping: { ...importState.mapping, [field.key]: e.target.value }
                      })}
                      className="flex-1 px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all text-sm font-bold bg-slate-50/30"
                    >
                      <option value="">-- اختر العمود --</option>
                      {importState.headers.map(h => (
                        <option key={h} value={h}>{h}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => setImportState({ ...importState, show: false })}
                  className="flex-1 px-6 py-4 rounded-2xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-all text-lg"
                >
                  إلغاء
                </button>
                <button 
                  onClick={executeImport}
                  disabled={!importState.mapping.itemCode || !importState.mapping.qty}
                  className="flex-1 px-6 py-4 rounded-2xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 text-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  بدء الاستيراد
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
