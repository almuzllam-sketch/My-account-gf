import React, { useState, useMemo, useEffect } from 'react';
import { 
  Save, 
  X, 
  Plus, 
  Trash2, 
  Printer, 
  ChevronRight, 
  ChevronLeft,
  Search,
  AlertCircle,
  FileText,
  Calendar,
  Hash,
  ArrowRight,
  BarChart3
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import * as XLSX from 'xlsx';
import { uid } from '../lib/utils';
import { DB, User, JournalEntry, JournalEntryItem, Account, CostCenter } from '../types';

interface JournalFormProps {
  db: DB;
  user: User;
  onSave: (entry: JournalEntry) => void;
  onPrint: (entry: JournalEntry) => void;
  onNavigate?: (dir: 'prev' | 'next' | 'new') => void;
  onDelete?: (id: string) => void;
  initialDoc?: JournalEntry | null;
  onCancel?: () => void;
  showNotification: (msg: string, type?: 'success' | 'error' | 'warning') => void;
  setConfirmModal: (modal: { title: string; message: string; onConfirm: () => void } | null) => void;
}

export const JournalForm: React.FC<JournalFormProps> = ({ 
  db, 
  user,
  onSave, 
  onPrint, 
  onNavigate,
  onDelete,
  initialDoc,
  onCancel,
  showNotification,
  setConfirmModal
}) => {
  const [date, setDate] = useState(initialDoc?.date || new Date().toISOString().split('T')[0]);
  const [docNum, setDocNum] = useState(initialDoc?.docNum || '');
  const [ref, setRef] = useState(initialDoc?.ref || '');
  const [description, setDescription] = useState(initialDoc?.description || '');
  const [items, setItems] = useState<JournalEntryItem[]>(initialDoc?.items || [
    { id: '1', accId: '', accType: 'gl', debit: 0, credit: 0, description: '' },
    { id: '2', accId: '', accType: 'gl', debit: 0, credit: 0, description: '' }
  ]);
  const [importState, setImportState] = useState<{
    show: boolean;
    headers: string[];
    data: any[];
    mapping: Record<string, string>;
  }>({
    show: false,
    headers: [],
    data: [],
    mapping: {}
  });

  const [accSearchIdx, setAccSearchIdx] = useState<number | null>(null);
  const [accSearchQuery, setAccSearchQuery] = useState('');
  const [ccSearchIdx, setCcSearchIdx] = useState<number | null>(null);
  const [ccSearchQuery, setCcSearchQuery] = useState('');

  // Totals
  const totalDebit = useMemo(() => items.reduce((sum, item) => sum + (item.debit || 0), 0), [items]);
  const totalCredit = useMemo(() => items.reduce((sum, item) => sum + (item.credit || 0), 0), [items]);
  const difference = useMemo(() => Math.abs(totalDebit - totalCredit), [totalDebit, totalCredit]);
  const isBalanced = useMemo(() => difference < 0.01 && totalDebit > 0, [difference, totalDebit]);

  useEffect(() => {
    if (initialDoc) {
      setDate(initialDoc.date);
      setDocNum(initialDoc.docNum);
      setRef(initialDoc.ref);
      setDescription(initialDoc.description);
      setItems(initialDoc.items);
    } else {
      // Generate next doc num
      const lastDoc = (db.journalEntries || []).sort((a, b) => (b.docNum || '').localeCompare(a.docNum || ''))[0];
      const nextNum = lastDoc ? (parseInt(lastDoc.docNum) + 1).toString() : '1';
      setDocNum(nextNum);
      setRef(`JV-${nextNum}`);
    }
  }, [initialDoc, db.journalEntries]);

  const addRow = () => {
    const lastItem = items[items.length - 1];
    setItems([...items, { 
      id: uid(), 
      accId: '', 
      accType: 'gl',
      debit: 0, 
      credit: 0, 
      description: lastItem?.description || '',
      currencyId: db.currencies?.find(c => c.isDefault)?.id || '',
      exchangeRate: 1
    }]);
  };

  const removeRow = (idx: number) => {
    if (items.length <= 2) return;
    setItems(items.filter((_, i) => i !== idx));
  };

  const updateRow = (idx: number, field: keyof JournalEntryItem, value: any) => {
    setItems(prev => {
      const newItems = [...prev];
      newItems[idx] = { ...newItems[idx], [field]: value };
      
      // If debit is set, clear credit and vice versa (usually)
      if (field === 'debit' && value > 0) newItems[idx].credit = 0;
      if (field === 'credit' && value > 0) newItems[idx].debit = 0;
      
      return newItems;
    });
  };

  const batchUpdateRow = (idx: number, updates: Partial<JournalEntryItem>) => {
    setItems(prev => {
      const newItems = [...prev];
      newItems[idx] = { ...newItems[idx], ...updates };
      return newItems;
    });
  };

  const handleSave = () => {
    if (!isBalanced) {
      showNotification('القيد غير متوازن! يجب أن يتساوى إجمالي المدين مع إجمالي الدائن', 'error');
      return;
    }
    if (items.some(item => !item.accId)) {
      showNotification('يرجى اختيار الحساب لكافة الأسطر', 'error');
      return;
    }

    const entry: JournalEntry = {
      id: initialDoc?.id || uid(),
      companyId: user.companyId,
      date,
      docNum,
      ref,
      description,
      items,
      createdAt: initialDoc?.createdAt || new Date().toISOString(),
      createdBy: initialDoc?.createdBy || user.id,
      updatedAt: initialDoc ? new Date().toISOString() : undefined,
      updatedBy: initialDoc ? user.id : undefined
    };

    onSave(entry);
  };

  const importFromExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result as string;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(ws) as any[];

        if (jsonData.length === 0) {
          showNotification('الملف فارغ أو غير صالح', 'error');
          return;
        }

        const headers = Object.keys(jsonData[0]);
        const initialMapping: Record<string, string> = {};
        const fieldOptions = [
          { key: 'accCode', aliases: ['accCode', 'accId', 'code', 'الكود', 'رقم_الحساب', 'كود_الحساب', 'حساب'] },
          { key: 'accType', aliases: ['accType', 'type', 'النوع', 'تصنيف', 'نوع_الحساب'] },
          { key: 'debit', aliases: ['debit', 'مدين', 'المدين'] },
          { key: 'credit', aliases: ['credit', 'دائن', 'الدائن'] },
          { key: 'description', aliases: ['description', 'desc', 'البيان', 'شرح', 'ملاحظات'] },
          { key: 'ccCode', aliases: ['ccCode', 'ccId', 'المركز', 'مركز_التكلفة', 'كود_المركز'] },
        ];

        fieldOptions.forEach(field => {
          const match = headers.find(h => field.aliases.some(alias => h.toLowerCase().includes(alias.toLowerCase())));
          if (match) initialMapping[field.key] = match;
        });

        setImportState({ show: true, headers, data: jsonData, mapping: initialMapping });
      } catch (err) {
        showNotification('❌ فشل قراءة الملف.', 'error');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  const executeImport = () => {
    const { data, mapping } = importState;
    const importedItems: JournalEntryItem[] = [];

    data.forEach(row => {
      const accCode = String(row[mapping.accCode] || '');
      if (!accCode) return;

      const accTypeVal = String(row[mapping.accType] || '');
      let accType: any = 'gl';
      if (accTypeVal.includes('عميل') || accTypeVal.includes('customer') || accTypeVal.includes('supplier') || accTypeVal.includes('مورد')) accType = 'customer-supplier';
      else if (accTypeVal.includes('صندوق') || accTypeVal.includes('fund')) accType = 'fund';
      else if (accTypeVal.includes('بنك') || accTypeVal.includes('bank')) accType = 'bank';

      let accId = '';
      if (accType === 'gl') {
        accId = (db.accounts || []).find(a => a.code === accCode || a.id === accCode)?.id || '';
      } else if (accType === 'customer-supplier') {
        accId = (db.customersSuppliers || []).find(c => c.code === accCode || c.id === accCode || c.accId === accCode)?.accId || '';
      } else if (accType === 'fund') {
        accId = (db.funds || []).find(f => f.code === accCode || f.id === accCode || f.accId === accCode)?.accId || '';
      } else if (accType === 'bank') {
        accId = (db.banks || []).find(b => b.code === accCode || b.id === accCode || b.accId === accCode)?.accId || '';
      }

      if (!accId) {
        // Fallback to "all" search if type-specific failed
        const found = (db.accounts || []).find(a => a.code === accCode || a.id === accCode) ||
                     (db.customersSuppliers || []).find(c => c.code === accCode || c.id === accCode || c.accId === accCode) ||
                     (db.funds || []).find(f => f.code === accCode || f.id === accCode || f.accId === accCode) ||
                     (db.banks || []).find(b => b.code === accCode || b.id === accCode || b.accId === accCode);
        if (found) {
          accId = (found as any).accId || found.id;
          if ((found as any).accId) {
             if ((db.customersSuppliers || []).find(c => c.id === found.id)) accType = 'customer-supplier';
             else if ((db.funds || []).find(f => f.id === found.id)) accType = 'fund';
             else if ((db.banks || []).find(b => b.id === found.id)) accType = 'bank';
          } else {
             accType = 'gl';
          }
        }
      }

      if (!accId) return;

      const debit = parseFloat(row[mapping.debit]) || 0;
      const credit = parseFloat(row[mapping.credit]) || 0;
      const desc = String(row[mapping.description] || '');
      const ccCode = String(row[mapping.ccQuery] || row[mapping.ccCode] || '');
      const ccId = (db.centers || []).find(c => c.code === ccCode || c.id === ccCode)?.id || '';

      importedItems.push({
        id: uid(),
        accId,
        accType,
        debit,
        credit,
        description: desc,
        ccId,
        currencyId: db.currencies?.find(c => c.isDefault)?.id || '',
        exchangeRate: 1
      });
    });

    if (importedItems.length > 0) {
      setItems(prev => {
        const filtered = prev.filter(i => i.accId || i.debit > 0 || i.credit > 0);
        return [...filtered, ...importedItems];
      });
      showNotification(`✅ تم استيراد ${importedItems.length} سطر بنجاح`, 'success');
    }
    setImportState({ show: false, headers: [], data: [], mapping: {} });
  };

  const downloadTemplate = () => {
    const headers = [['كود_الحساب', 'نوع_الحساب', 'مدين', 'دائن', 'البيان', 'كود_المركز']];
    const sample = [['1001', 'gl', '1000', '0', 'قيد افتتاحي', '']];
    const ws = XLSX.utils.aoa_to_sheet([...headers, ...sample]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Journal");
    XLSX.writeFile(wb, "journal_import_template.xlsx");
  };

  const filteredAccounts = useMemo(() => {
    if (accSearchIdx === null) return [];
    const query = accSearchQuery.toLowerCase();
    const type = items[accSearchIdx]?.accType || 'gl';

    let source: any[] = [];
    switch (type) {
      case 'gl': source = (db.accounts || []).filter(a => a.isPostable).map(a => ({ ...a, category: 'gl' })); break;
      case 'customer-supplier': source = (db.customersSuppliers || []).map(a => ({ ...a, category: 'customer-supplier' })); break;
      case 'fund': source = (db.funds || []).map(a => ({ ...a, category: 'fund' })); break;
      case 'bank': source = (db.banks || []).map(a => ({ ...a, category: 'bank' })); break;
      case 'all': 
        source = [
          ...(db.accounts || []).filter(a => a.isPostable).map(a => ({ ...a, category: 'gl' })),
          ...(db.customersSuppliers || []).map(a => ({ ...a, category: 'customer-supplier' })),
          ...(db.funds || []).map(a => ({ ...a, category: 'fund' })),
          ...(db.banks || []).map(a => ({ ...a, category: 'bank' }))
        ];
        break;
      default: source = (db.accounts || []).filter(a => a.isPostable).map(a => ({ ...a, category: 'gl' }));
    }

    return source.filter(a => 
      a.name.toLowerCase().includes(query) || 
      a.code.toLowerCase().includes(query)
    ).slice(0, 50);
  }, [db, accSearchQuery, accSearchIdx, items]);

  const filteredCenters = useMemo(() => {
    if (!ccSearchQuery) return [];
    const query = ccSearchQuery.toLowerCase();
    return (db.centers || []).filter(c => 
      c.isLeaf && 
      (c.name.toLowerCase().includes(query) || c.code.toLowerCase().includes(query))
    ).slice(0, 10);
  }, [db.centers, ccSearchQuery]);

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-xl shadow-blue-200">
            <FileText size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">
              {initialDoc ? `تعديل قيد يومية: ${ref}` : 'قيد يومية جديد'}
            </h1>
            <div className="flex items-center gap-2 mt-1">
              <p className="text-slate-500 font-medium">تسجيل الحركات المالية المباشرة</p>
              <div className="h-1 w-1 rounded-full bg-slate-300" />
              <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full ${isBalanced ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                {isBalanced ? 'متوازن' : 'غير متوازن'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
          <button 
            onClick={() => onNavigate?.('new')}
            className="flex items-center gap-2 px-6 py-3 bg-white text-blue-600 rounded-2xl font-black text-xs uppercase tracking-widest border border-blue-100 hover:bg-blue-50 transition-all shadow-sm active:scale-95"
          >
            <Plus size={18} />
            جديد
          </button>
          <div className="h-8 w-px bg-slate-100 mx-1" />
          <div className="flex items-center bg-white rounded-2xl border border-slate-200 p-1 shadow-sm">
            <button 
              onClick={() => onNavigate?.('prev')}
              className="p-2.5 hover:bg-slate-50 text-slate-600 rounded-xl transition-all"
              title="السابق"
            >
              <ChevronRight size={20} />
            </button>
            <button 
              onClick={() => onNavigate?.('next')}
              className="p-2.5 hover:bg-slate-50 text-slate-600 rounded-xl transition-all"
              title="التالي"
            >
              <ChevronLeft size={20} />
            </button>
          </div>
          <div className="h-8 w-px bg-slate-100 mx-1" />
          {initialDoc && (
            <button 
              onClick={() => {
                setConfirmModal({
                  title: 'تأكيد الحذف',
                  message: 'هل أنت متأكد من حذف هذا القيد؟ لا يمكن التراجع عن هذه العملية.',
                  onConfirm: () => onDelete?.(initialDoc.id)
                });
              }}
              className="p-3 bg-white text-red-500 rounded-2xl font-black border border-red-100 hover:bg-red-50 transition-all shadow-sm active:scale-95"
              title="حذف"
            >
              <Trash2 size={20} />
            </button>
          )}
          <button 
            onClick={() => onPrint(initialDoc as any)}
            disabled={!initialDoc}
            className="p-3 bg-white text-slate-700 rounded-2xl font-black border border-slate-200 hover:bg-slate-50 transition-all shadow-sm active:scale-95 disabled:opacity-50"
            title="طباعة"
          >
            <Printer size={20} />
          </button>
          <button 
            onClick={handleSave}
            className="flex items-center gap-2 px-8 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-slate-200 transition-all active:scale-95"
          >
            <Save size={18} />
            حفظ القيد
          </button>
          {onCancel && (
            <button 
              onClick={onCancel}
              className="p-3 hover:bg-slate-100 text-slate-400 rounded-2xl transition-all"
            >
              <X size={24} />
            </button>
          )}
        </div>
      </div>

      {/* Main Info */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-2">
                  <Calendar size={12} className="text-blue-500" />
                  تاريخ القيد
                </label>
                <input 
                  type="date" 
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none font-bold text-slate-700 transition-all bg-slate-50/30 focus:bg-white"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-2">
                  <Hash size={12} className="text-blue-500" />
                  رقم المرجع
                </label>
                <input 
                  type="text" 
                  value={ref}
                  onChange={(e) => setRef(e.target.value)}
                  placeholder="مثال: JV-1001"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none font-bold text-slate-700 transition-all bg-slate-50/30 focus:bg-white"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-2">
                <FileText size={12} className="text-blue-500" />
                وصف القيد العام
              </label>
              <textarea 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="اكتب وصفاً مختصراً للقيد..."
                rows={2}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 outline-none font-medium text-slate-700 resize-none transition-all bg-slate-50/30 focus:bg-white"
              />
            </div>
          </div>

          {/* Items Table */}
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <h3 className="font-bold text-slate-800">تفاصيل القيد</h3>
                <div className="h-4 w-px bg-slate-200" />
                <button onClick={downloadTemplate} className="text-[10px] font-bold text-slate-400 hover:text-blue-600 transition-colors uppercase tracking-widest">تحميل نموذج</button>
                <label className="text-[10px] font-bold text-slate-400 hover:text-blue-600 transition-colors uppercase tracking-widest cursor-pointer">
                  استيراد إكسل
                  <input type="file" className="hidden" accept=".xlsx,.xls" onChange={importFromExcel} />
                </label>
              </div>
              <button 
                onClick={addRow}
                className="text-blue-600 text-sm font-bold flex items-center gap-1 hover:underline"
              >
                <Plus size={16} />
                إضافة سطر
              </button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-100">
                    <th className="p-4 text-right text-[10px] font-black text-slate-400 uppercase tracking-widest w-12">#</th>
                    <th className="p-4 text-right text-[10px] font-black text-slate-400 uppercase tracking-widest w-32">نوع الحساب</th>
                    <th className="p-4 text-right text-[10px] font-black text-slate-400 uppercase tracking-widest">الحساب</th>
                    <th className="p-4 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-28">العملة</th>
                    <th className="p-4 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-24">سعر الصرف</th>
                    <th className="p-4 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-28">المبلغ (عملة)</th>
                    <th className="p-4 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-28">مدين</th>
                    <th className="p-4 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest w-28">دائن</th>
                    <th className="p-4 text-right text-[10px] font-black text-slate-400 uppercase tracking-widest">البيان</th>
                    <th className="p-4 w-12"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {items.map((item, idx) => (
                    <tr key={item.id} className="group hover:bg-blue-50/30 transition-colors">
                      <td className="p-4 text-[10px] font-black text-slate-300 group-hover:text-blue-400 transition-colors">
                        {(idx + 1).toString().padStart(2, '0')}
                      </td>
                      <td className="p-4 w-32">
                        <select
                          value={item.accType || 'gl'}
                          onChange={(e) => {
                            updateRow(idx, 'accType', e.target.value);
                            updateRow(idx, 'accId', ''); // Clear account when type changes
                          }}
                          className="w-full px-2 py-2 rounded-lg border border-slate-200 outline-none text-[11px] font-black uppercase tracking-widest bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all cursor-pointer"
                        >
                          <option value="gl">أستاذ عام</option>
                          <option value="customer-supplier">عملاء وموردين</option>
                          <option value="fund">صناديق</option>
                          <option value="bank">بنوك</option>
                          <option value="all">بحث في الكل</option>
                        </select>
                      </td>
                      <td className="p-4 relative min-w-[300px]">
                        <div className="relative">
                          <input 
                            type="text" 
                            id={`acc-input-${idx}`}
                            value={(() => {
                              if (accSearchIdx === idx) return accSearchQuery;
                              const category = item.accType || 'gl';
                              if (category === 'gl') return (db.accounts || []).find(a => a.id === item.accId)?.name || '';
                              if (category === 'customer-supplier') return db.customersSuppliers?.find(a => a.accId === item.accId)?.name || '';
                              if (category === 'fund') return db.funds?.find(a => a.accId === item.accId)?.name || '';
                              if (category === 'bank') return db.banks?.find(a => a.accId === item.accId)?.name || '';
                              if (category === 'all') {
                                return (db.accounts || []).find(a => a.id === item.accId)?.name || 
                                       db.customersSuppliers?.find(a => a.accId === item.accId)?.name ||
                                       db.funds?.find(a => a.accId === item.accId)?.name ||
                                       db.banks?.find(a => a.accId === item.accId)?.name || '';
                              }
                              return '';
                            })()}
                            onFocus={(e) => {
                              e.target.select();
                              setAccSearchIdx(idx);
                              setAccSearchQuery('');
                            }}
                            onChange={(e) => setAccSearchQuery(e.target.value)}
                            placeholder="بحث عن حساب..."
                            className={`w-full px-4 py-2.5 rounded-xl border font-bold text-sm transition-all outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 ${item.accId ? 'border-slate-100 bg-slate-50 text-slate-700' : 'border-red-100 bg-red-50 text-red-400'}`}
                          />
                          
                          <AnimatePresence>
                            {accSearchIdx === idx && (
                              <>
                                <div className="fixed inset-0 z-40" onClick={() => setAccSearchIdx(null)} />
                                <motion.div 
                                  initial={{ opacity: 0, y: 5 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  exit={{ opacity: 0, y: 5 }}
                                  className="absolute z-[100] right-0 top-full mt-1 bg-white border border-slate-200 rounded-2xl shadow-2xl min-w-[320px] w-full p-4 overflow-hidden"
                                >
                                  <div className="flex items-center justify-between mb-3 border-b border-slate-50 pb-2">
                                    <h4 className="font-black text-slate-800 text-[10px] uppercase tracking-widest">
                                      {item.accType === 'gl' ? 'دليل الحسابات' : 
                                       item.accType === 'customer-supplier' ? 'دليل العملاء والموردين' :
                                       item.accType === 'fund' ? 'دليل الصناديق' :
                                       item.accType === 'bank' ? 'دليل البنوك' : 'البحث في كافة الدلائل'}
                                    </h4>
                                    <button onClick={() => setAccSearchIdx(null)} className="p-1 text-slate-300 hover:text-slate-500 transition-colors"><X size={16} /></button>
                                  </div>
                                  <div className="max-h-60 overflow-y-auto space-y-1 no-scrollbar overflow-x-hidden">
                                    {filteredAccounts.length > 0 ? filteredAccounts.map(a => (
                                      <button 
                                        key={`${a.category}-${a.id}`}
                                        onClick={() => {
                                          const category = a.category || item.accType || 'gl';
                                          batchUpdateRow(idx, { 
                                            accType: category, 
                                            accId: a.accId || a.id 
                                          });
                                          setAccSearchIdx(null);
                                          setAccSearchQuery('');
                                          setTimeout(() => document.getElementById(`debit-input-${idx}`)?.focus(), 50);
                                        }}
                                        className="w-full text-right px-4 py-3 hover:bg-blue-50 rounded-xl border-b border-slate-50 last:border-0 transition-all flex flex-col"
                                      >
                                        <div className="flex items-center justify-between gap-4">
                                          <span className="font-bold text-slate-800 text-sm">{a.name}</span>
                                          <span className="text-[10px] text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded font-mono font-bold">{a.code}</span>
                                        </div>
                                        {item.accType === 'all' && (
                                          <span className="text-[9px] text-slate-400 capitalize mt-1">
                                            {a.category === 'gl' ? 'أستاذ عام' : 
                                             a.category === 'customer-supplier' ? 'عميل/مورد' :
                                             a.category === 'fund' ? 'صندوق' : 'بنك'}
                                          </span>
                                        )}
                                      </button>
                                    )) : (
                                      <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                                        <div className="text-slate-400 font-bold text-xs underline underline-offset-4 decoration-slate-200">لا توجد نتائج مطابقة</div>
                                      </div>
                                    )}
                                  </div>
                                </motion.div>
                              </>
                            )}
                          </AnimatePresence>
                        </div>
                      </td>
                      <td className="p-4">
                        <select
                          value={item.currencyId || db.currencies?.find(c => c.isDefault)?.id || ''}
                          onChange={(e) => {
                            const cId = e.target.value;
                            const rate = db.currencies?.find(c => c.id === cId)?.exchangeRate || 1;
                            updateRow(idx, 'currencyId', cId);
                            updateRow(idx, 'exchangeRate', rate);
                          }}
                          className="w-full px-2 py-2 rounded-lg border border-slate-200 outline-none text-xs font-bold bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all"
                        >
                          {db.currencies?.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </td>
                      <td className="p-4">
                        <input 
                          type="number" 
                          step="0.000001"
                          value={item.exchangeRate || 1}
                          onChange={(e) => {
                            const rate = parseFloat(e.target.value) || 1;
                            updateRow(idx, 'exchangeRate', rate);
                            if (item.foreignAmount) {
                              const local = item.foreignAmount * rate;
                              if (item.debit > 0) updateRow(idx, 'debit', local);
                              else if (item.credit > 0) updateRow(idx, 'credit', local);
                            }
                          }}
                          className="w-full px-2 py-2 rounded-lg border border-slate-200 outline-none text-center font-bold text-slate-500 text-xs focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all bg-slate-50/30 focus:bg-white"
                        />
                      </td>
                      <td className="p-4">
                        <input 
                          type="number" 
                          value={item.foreignAmount || ''}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            updateRow(idx, 'foreignAmount', val);
                            const rate = item.exchangeRate || 1;
                            const local = val * rate;
                            if (item.debit > 0 || (!item.debit && !item.credit)) updateRow(idx, 'debit', local);
                            else if (item.credit > 0) updateRow(idx, 'credit', local);
                          }}
                          placeholder="0.00"
                          className="w-full px-2 py-2 rounded-lg border border-slate-200 outline-none text-center font-bold text-blue-600 bg-blue-50/30 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all"
                        />
                      </td>
                      <td className="p-4">
                        <input 
                          type="number" 
                          id={`debit-input-${idx}`}
                          value={item.debit || ''}
                          onChange={(e) => updateRow(idx, 'debit', parseFloat(e.target.value) || 0)}
                          onFocus={(e) => e.target.select()}
                          className="w-full px-2 py-2 rounded-lg border border-slate-200 outline-none text-center font-bold text-emerald-600 bg-emerald-50/30 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition-all"
                        />
                      </td>
                      <td className="p-4">
                        <input 
                          type="number" 
                          id={`credit-input-${idx}`}
                          value={item.credit || ''}
                          onChange={(e) => updateRow(idx, 'credit', parseFloat(e.target.value) || 0)}
                          onFocus={(e) => e.target.select()}
                          className="w-full px-2 py-2 rounded-lg border border-slate-200 outline-none text-center font-bold text-rose-600 bg-rose-50/30 focus:border-rose-500 focus:ring-4 focus:ring-rose-500/10 transition-all"
                        />
                      </td>
                      <td className="p-4">
                        <input 
                          type="text" 
                          value={item.description}
                          onChange={(e) => updateRow(idx, 'description', e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              if (idx === items.length - 1) addRow();
                              setTimeout(() => document.getElementById(`acc-input-${idx + 1}`)?.focus(), 50);
                            }
                          }}
                          placeholder="وصف السطر..."
                          className="w-full px-3 py-2 rounded-lg border border-slate-200 outline-none text-sm focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all"
                        />
                      </td>
                      <td className="p-4">
                        <button 
                          onClick={() => removeRow(idx)}
                          className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-slate-50 border-t border-slate-100 font-black">
                  <tr>
                    <td colSpan={4} className="p-4 text-left text-[10px] text-slate-400 uppercase tracking-wider">الإجماليات:</td>
                    <td className="p-4 text-center text-emerald-600 text-lg">{totalDebit.toLocaleString()}</td>
                    <td className="p-4 text-center text-rose-600 text-lg">{totalCredit.toLocaleString()}</td>
                    <td colSpan={2}></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>

        {/* Summary Sidebar */}
        <div className="space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6 sticky top-6">
            <h3 className="font-black text-slate-800 flex items-center gap-2 text-xs uppercase tracking-widest">
              <BarChart3 size={14} className="text-blue-500" />
              ملخص القيد
            </h3>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center p-5 bg-slate-50 rounded-2xl border border-slate-100 group hover:bg-emerald-50 hover:border-emerald-100 transition-all">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider group-hover:text-emerald-600">إجمالي المدين</span>
                <span className="text-2xl font-black text-slate-700 group-hover:text-emerald-700 font-mono tracking-tighter">{totalDebit.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center p-5 bg-slate-50 rounded-2xl border border-slate-100 group hover:bg-rose-50 hover:border-rose-100 transition-all">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider group-hover:text-rose-600">إجمالي الدائن</span>
                <span className="text-2xl font-black text-slate-700 group-hover:text-rose-700 font-mono tracking-tighter">{totalCredit.toLocaleString()}</span>
              </div>
              
              <div className={`p-6 rounded-2xl border flex flex-col items-center gap-3 transition-all shadow-sm ${isBalanced ? 'bg-emerald-600 border-emerald-500 shadow-emerald-100' : 'bg-amber-50 border-amber-100 shadow-amber-50'}`}>
                <div className="flex items-center gap-2">
                  {isBalanced ? (
                    <div className="bg-white/20 p-1 rounded-full">
                      <Save size={12} className="text-white" />
                    </div>
                  ) : (
                    <AlertCircle size={18} className="text-amber-500" />
                  )}
                  <span className={`text-xs font-black uppercase tracking-widest ${isBalanced ? 'text-white' : 'text-amber-700'}`}>
                    {isBalanced ? 'القيد متوازن' : 'القيد غير متوازن'}
                  </span>
                </div>
                {!isBalanced ? (
                  <div className="text-center">
                    <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest block mb-1">الفرق المتبقي</span>
                    <span className="text-3xl font-black text-amber-700 font-mono tracking-tighter">
                      {difference.toLocaleString()}
                    </span>
                  </div>
                ) : (
                  <span className="text-[10px] font-bold text-emerald-100 text-center leading-tight">
                    تم التحقق من توازن القيد بنجاح. يمكنك الآن حفظ الحركة.
                  </span>
                )}
              </div>
            </div>

            <div className="pt-6 border-t border-slate-50">
              <p className="text-[10px] text-slate-400 text-center leading-relaxed font-medium">
                يجب أن يتساوى إجمالي المدين مع إجمالي الدائن ليتمكن النظام من ترحيل القيد إلى الحسابات.
              </p>
            </div>
          </div>

          <div className="bg-blue-600 p-8 rounded-3xl text-white shadow-xl shadow-blue-200 relative overflow-hidden group">
            <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/10 rounded-full blur-2xl group-hover:scale-150 transition-transform" />
            <h4 className="font-bold mb-2 flex items-center gap-2">
              <AlertCircle size={18} />
              نصيحة محاسبية
            </h4>
            <p className="text-sm text-blue-100 leading-relaxed">
              استخدم قيود اليومية فقط للحركات التي لا تتوفر لها نماذج متخصصة، مثل التسويات الجردية أو إثبات المصروفات المستحقة.
            </p>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {importState.show && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4" dir="rtl">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setImportState({ ...importState, show: false })}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-xl rounded-3xl shadow-2xl p-8"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h3 className="text-2xl font-black text-slate-900">ربط أعمدة الإكسل</h3>
                  <p className="text-slate-500 text-sm mt-1">طابق حقول القيد مع أعمدة ملف الإكسل</p>
                </div>
                <button onClick={() => setImportState({ ...importState, show: false })} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X size={24} className="text-slate-400" />
                </button>
              </div>

              <div className="space-y-4 mb-10 min-h-[300px]">
                {[
                  { key: 'accCode', label: 'كود الحساب', required: true },
                  { key: 'accType', label: 'نوع الحساب (gl, fund, bank, sub)', required: false },
                  { key: 'debit', label: 'المدين', required: false },
                  { key: 'credit', label: 'الدائن', required: false },
                  { key: 'description', label: 'البيان', required: false },
                  { key: 'ccCode', label: 'كود المركز', required: false },
                ].map(field => (
                  <div key={field.key} className="flex items-center justify-between gap-6">
                    <label className="text-sm font-black text-slate-700 min-w-[140px] flex items-center gap-2">
                       <div className="w-1.5 h-6 bg-blue-100 rounded-full" />
                      {field.label}
                      {field.required && <span className="text-red-500 mr-1">*</span>}
                    </label>
                    <select 
                      value={importState.mapping[field.key] || ''}
                      onChange={e => setImportState({
                        ...importState,
                        mapping: { ...importState.mapping, [field.key]: e.target.value }
                      })}
                      className="flex-1 px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all text-sm font-bold bg-slate-50/30"
                    >
                      <option value="">-- اختر العمود --</option>
                      {importState.headers.map(h => (
                        <option key={h} value={h}>{h}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => setImportState({ ...importState, show: false })}
                  className="flex-1 px-6 py-4 rounded-2xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-all text-lg"
                >
                  إلغاء
                </button>
                <button 
                  onClick={executeImport}
                  disabled={!importState.mapping.accCode || (!importState.mapping.debit && !importState.mapping.credit)}
                  className="flex-1 px-6 py-4 rounded-2xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 text-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  بدء الاستيراد
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
