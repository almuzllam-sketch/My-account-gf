import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  Search, 
  Plus, 
  Trash2, 
  Calendar,
  Tag,
  ChevronRight,
  ChevronLeft,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DB, PricingDoc, User, PriceType } from '../types';

interface PricingHistoryProps {
  db: DB;
  user: User;
  onUpdateDB: (newDb: DB, collectionName?: string, docId?: string, data?: any, isDelete?: boolean) => void;
  showNotification: (msg: string, type?: 'success' | 'error' | 'warning') => void;
}

export const PricingHistory: React.FC<PricingHistoryProps> = ({ db, user, onUpdateDB, showNotification }) => {
  const [search, setSearch] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState<PriceType | 'all'>('all');

  const filteredDocs = useMemo(() => {
    return (db.pricingDocs || []).filter(doc => {
      const matchesSearch = !search || (doc.items || []).some(it => {
        const item = (db.items || []).find(i => i.id === it.itemId);
        return item?.name.includes(search) || item?.code.includes(search);
      });
      const matchesDate = !dateFilter || doc.date === dateFilter;
      const matchesType = typeFilter === 'all' || doc.type === typeFilter;
      return matchesSearch && matchesDate && matchesType;
    }).sort((a, b) => b.date.localeCompare(a.date));
  }, [db.pricingDocs, db.items, search, dateFilter, typeFilter]);

  const deleteDoc = (id: string) => {
    if (user.role !== 'admin') {
      showNotification('ليس لديك صلاحية حذف مستندات التسعير', 'error');
      return;
    }
    const updated = (db.pricingDocs || []).filter(d => d.id !== id);
    const itemToDelete = (db.pricingDocs || []).find(d => d.id === id);
    onUpdateDB({ ...db, pricingDocs: updated }, 'pricingDocs', id, itemToDelete, true);
    showNotification('تم حذف مستند التسعير بنجاح', 'success');
  };

  const getPriceTypeLabel = (type: PriceType) => {
    const labels: Record<PriceType, string> = {
      retail: 'تجزئة',
      wholesale: 'جملة',
      internal: 'فروع داخلية',
      external: 'فروع خارجية'
    };
    return labels[type];
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="bg-blue-600 p-3 rounded-2xl shadow-lg shadow-blue-100">
            <TrendingUp className="text-white" size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">سجل تسعيرات الأصناف</h1>
            <p className="text-slate-500 mt-1">مراجعة وإدارة مستندات التسعير التاريخية</p>
          </div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex flex-wrap gap-4 items-center">
        <div className="flex-1 min-w-[240px] relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="بحث باسم الصنف أو الكود..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-10 pl-10 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          />
        </div>
        <div className="flex items-center gap-2">
          <select 
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value as any)}
            className="px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm bg-white"
          >
            <option value="all">كل الأنواع</option>
            <option value="retail">تجزئة</option>
            <option value="wholesale">جملة</option>
            <option value="internal">فروع داخلية</option>
            <option value="external">فروع خارجية</option>
          </select>
          <input 
            type="date" 
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredDocs.map(doc => (
          <div key={doc.id} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:border-blue-200 transition-all group">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 text-slate-600">
                  <Calendar size={16} />
                  <span className="font-bold">{doc.date}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Tag size={16} className="text-blue-500" />
                  <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                    doc.type === 'retail' ? 'bg-blue-50 text-blue-600' :
                    doc.type === 'wholesale' ? 'bg-purple-50 text-purple-600' :
                    'bg-amber-50 text-amber-600'
                  }`}>
                    {getPriceTypeLabel(doc.type)}
                  </span>
                </div>
              </div>
              <button 
                onClick={() => deleteDoc(doc.id)}
                className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
              >
                <Trash2 size={20} />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-slate-400 border-b border-slate-50">
                    <th className="p-2 text-right font-bold">الصنف</th>
                    <th className="p-2 text-center font-bold">الوحدة</th>
                    <th className="p-2 text-center font-bold">السعر</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {(doc.items || []).map((it, idx) => {
                    const item = (db.items || []).find(i => i.id === it.itemId);
                    return (
                      <tr key={idx}>
                        <td className="p-2">
                          <div className="font-medium text-slate-800">{item?.name || 'صنف محذوف'}</div>
                          <div className="text-[10px] text-slate-400">{item?.code}</div>
                        </td>
                        <td className="p-2 text-center text-slate-600">{it.unit}</td>
                        <td className="p-2 text-center font-bold text-blue-600">{it.price.toLocaleString()}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ))}

        {filteredDocs.length === 0 && (
          <div className="text-center py-20 bg-white rounded-2xl border border-slate-100 border-dashed">
            <TrendingUp size={48} className="mx-auto mb-4 text-slate-200" />
            <p className="text-slate-400">لا توجد مستندات تسعير مطابقة للبحث</p>
          </div>
        )}
      </div>
    </div>
  );
};
