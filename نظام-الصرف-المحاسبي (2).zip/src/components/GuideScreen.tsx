import React from 'react';
import { 
  Users, 
  Package, 
  Building, 
  Database, 
  LayoutGrid,
  ChevronLeft,
  ArrowRight
} from 'lucide-react';
import { motion } from 'motion/react';
import { ViewType, User } from '../types';

interface GuideScreenProps {
  user: User;
  onSelect: (view: ViewType) => void;
}

export const GuideScreen: React.FC<GuideScreenProps> = ({ user, onSelect }) => {
  const guides = [
    { id: 'accounts', label: 'دليل الحسابات', icon: Users, color: 'bg-blue-500', description: 'إدارة العملاء والموردين والحسابات المالية', permission: 'canManageAccounts' },
    { id: 'items', label: 'دليل الأصناف', icon: Package, color: 'bg-emerald-500', description: 'إدارة المخزون والخدمات والوحدات', permission: 'canManageItems' },
    { id: 'centers', label: 'مراكز التكلفة', icon: LayoutGrid, color: 'bg-purple-500', description: 'توزيع التكاليف على المشاريع والأقسام', permission: 'canManageCenters' },
    { id: 'funds', label: 'دليل الصناديق', icon: Database, color: 'bg-orange-500', description: 'إدارة الصناديق النقدية وربطها بالحسابات', permission: 'canManageFunds' },
    { id: 'banks', label: 'دليل البنوك', icon: Building, color: 'bg-indigo-500', description: 'إدارة الحسابات البنكية والصرافين', permission: 'canManageBanks' },
    { id: 'customers-suppliers', label: 'العملاء والموردين', icon: Users, color: 'bg-rose-500', description: 'إدارة شجرة العملاء والموردين', permission: 'canManageCustomersSuppliers' },
    { id: 'branches', label: 'الفروع', icon: Building, color: 'bg-amber-500', description: 'إدارة فروع الشركة ومواقعها', permission: 'canManageBranches' },
    { id: 'warehouses', label: 'المخازن', icon: Database, color: 'bg-indigo-500', description: 'إدارة مستودعات التخزين وتوزيعها', permission: 'canManageWarehouses' },
    { id: 'departments', label: 'الأقسام', icon: Building, color: 'bg-rose-500', description: 'إدارة الأقسام الإدارية والتشغيلية', permission: 'canManageDepartments' },
  ];

  const filteredGuides = guides.filter(g => {
    if (user.role === 'admin') return true;
    return !!(user as any)[g.permission];
  });

  return (
    <div className="space-y-8 p-6">
      <div className="flex items-center gap-4">
        <div className="bg-blue-600 p-3 rounded-2xl shadow-lg shadow-blue-100">
          <LayoutGrid className="text-white" size={24} />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-slate-900">الأدلة الرئيسية</h1>
          <p className="text-slate-500 mt-1">اختر الدليل الذي ترغب في إدارته</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGuides.map((guide) => (
          <motion.button
            key={guide.id}
            whileHover={{ y: -5, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelect(guide.id as ViewType)}
            className="group relative bg-white p-8 rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl hover:border-blue-200 transition-all text-right flex flex-col items-start gap-4"
          >
            <div className={`${guide.color} p-4 rounded-2xl text-white shadow-lg group-hover:scale-110 transition-transform`}>
              <guide.icon size={28} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">{guide.label}</h3>
              <p className="text-sm text-slate-500 leading-relaxed">{guide.description}</p>
            </div>
            <div className="mt-4 flex items-center gap-2 text-blue-600 font-bold text-sm">
              <span>فتح الدليل</span>
              <ArrowRight size={16} className="group-hover:translate-x-[-4px] transition-transform" />
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
};
