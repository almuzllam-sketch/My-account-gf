import React, { useState, useMemo, useEffect } from 'react';
import { 
  Save, 
  X, 
  Plus, 
  Trash2, 
  Printer, 
  ChevronRight, 
  ChevronLeft,
  Search,
  AlertCircle,
  ArrowRight,
  CreditCard,
  Banknote,
  Repeat,
  Calendar,
  Hash,
  FileText,
  Building2,
  Wallet,
  Coins,
  ArrowUpRight,
  Info,
  Users
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import * as XLSX from 'xlsx';
import { uid } from '../lib/utils';
import { DB, User, CashBankDoc, CashBankDocType, CashBankDocItem, Fund, Bank, Account, CostCenter, Currency, AccountCategory } from '../types';

interface CashBankFormProps {
  db: DB;
  user: User;
  onSave: (doc: CashBankDoc) => Promise<void>;
  onPrint?: (doc: CashBankDoc) => void;
  onCancel: () => void;
  initialDoc?: CashBankDoc | null;
  onNavigate?: (dir: 'prev' | 'next' | 'new') => void;
  onDelete?: (id: string) => Promise<void>;
  getNextDocNum: (type: CashBankDocType) => string;
}

const CashBankForm: React.FC<CashBankFormProps> = ({ 
  db, 
  user, 
  onSave, 
  onPrint, 
  onCancel, 
  initialDoc,
  onNavigate,
  onDelete,
  getNextDocNum
}) => {
  const [docType, setDocType] = useState<CashBankDocType>(initialDoc?.type || 'cash-payment');
  const [date, setDate] = useState(initialDoc?.date || new Date().toISOString().split('T')[0]);
  const [docNum, setDocNum] = useState(initialDoc?.docNum || '');
  const [ref, setRef] = useState(initialDoc?.ref || '');
  const [description, setDescription] = useState(initialDoc?.description || '');
  
  const [fundId, setFundId] = useState(initialDoc?.fundId || '');
  const [bankId, setBankId] = useState(initialDoc?.bankId || '');
  const [branchId, setBranchId] = useState(initialDoc?.branchId || '');
  const [collector, setCollector] = useState(initialDoc?.collector || '');
  const [maturityDate, setMaturityDate] = useState(initialDoc?.maturityDate || '');
  
  const [currencyId, setCurrencyId] = useState(initialDoc?.currencyId || db.currencies?.find(c => c.isDefault)?.id || '');
  const [exchangeRate, setExchangeRate] = useState(initialDoc?.exchangeRate || 1);

  const [items, setItems] = useState<CashBankDocItem[]>(initialDoc?.items || [
    { id: uid(), accId: '', accType: 'gl', amount: 0, description: '' }
  ]);
  
  const [focusedItemId, setFocusedItemId] = useState<string | null>(null);
  
  const [checkNum, setCheckNum] = useState(initialDoc?.checkNum || '');
  const [checkDate, setCheckDate] = useState(initialDoc?.checkDate || '');
  const [transferRef, setTransferRef] = useState(initialDoc?.transferRef || '');

  const [accSearchQuery, setAccSearchQuery] = useState('');
  const [showAccSearch, setShowAccSearch] = useState<{idx: number} | null>(null);

  const [importState, setImportState] = useState<{
    show: boolean;
    headers: string[];
    data: any[];
    mapping: Record<string, string>;
  }>({
    show: false,
    headers: [],
    data: [],
    mapping: {}
  });

  useEffect(() => {
    if (initialDoc) {
      setDocType(initialDoc.type);
      if (initialDoc.date) setDate(initialDoc.date);
      if (initialDoc.docNum) setDocNum(initialDoc.docNum);
      if (initialDoc.ref) setRef(initialDoc.ref);
      if (initialDoc.description) setDescription(initialDoc.description);
      if (initialDoc.fundId) setFundId(initialDoc.fundId);
      if (initialDoc.bankId) setBankId(initialDoc.bankId);
      if (initialDoc.branchId) setBranchId(initialDoc.branchId);
      if (initialDoc.collector) setCollector(initialDoc.collector);
      if (initialDoc.maturityDate) setMaturityDate(initialDoc.maturityDate);
      if (initialDoc.currencyId) setCurrencyId(initialDoc.currencyId);
      if (initialDoc.exchangeRate) setExchangeRate(initialDoc.exchangeRate);
      if (initialDoc.items) setItems(initialDoc.items);
      if (initialDoc.checkNum) setCheckNum(initialDoc.checkNum);
      if (initialDoc.checkDate) setCheckDate(initialDoc.checkDate);
      if (initialDoc.transferRef) setTransferRef(initialDoc.transferRef);
    }
  }, [initialDoc]);

  useEffect(() => {
    if (!initialDoc?.id) {
      setDocNum(getNextDocNum(docType));
    }
  }, [docType, initialDoc?.id, getNextDocNum]);

  useEffect(() => {
    const curr = db.currencies?.find(c => c.id === currencyId);
    if (curr && !initialDoc) {
      setExchangeRate(curr.exchangeRate);
    }
  }, [currencyId, db.currencies, initialDoc]);

  const totalAmount = useMemo(() => items.reduce((sum, item) => sum + item.amount, 0), [items]);

  const filteredAccounts = useMemo(() => {
    if (showAccSearch === null) return [];
    const item = items[showAccSearch.idx];
    const category = item.accType || 'gl';
    
    let source: any[] = [];
    switch (category) {
      case 'gl': source = (db.accounts || []).filter(a => a.isPostable).map(a => ({ ...a, category: 'gl' })); break;
      case 'customer-supplier': source = (db.customersSuppliers || []).map(a => ({ ...a, category: 'customer-supplier' })); break;
      case 'fund': source = (db.funds || []).map(a => ({ ...a, category: 'fund' })); break;
      case 'bank': source = (db.banks || []).map(a => ({ ...a, category: 'bank' })); break;
      case 'all': 
        source = [
          ...(db.accounts || []).filter(a => a.isPostable).map(a => ({ ...a, category: 'gl' })),
          ...(db.customersSuppliers || []).map(a => ({ ...a, category: 'customer-supplier' })),
          ...(db.funds || []).map(a => ({ ...a, category: 'fund' })),
          ...(db.banks || []).map(a => ({ ...a, category: 'bank' }))
        ];
        break;
      default: source = (db.accounts || []).filter(a => a.isPostable).map(a => ({ ...a, category: 'gl' }));
    }

    if (!accSearchQuery) return source;
    return source.filter(a => 
      (a.name?.toLowerCase().includes(accSearchQuery.toLowerCase()) || 
       a.code?.toLowerCase().includes(accSearchQuery.toLowerCase()))
    );
  }, [db, accSearchQuery, showAccSearch, items]);

  const addItem = (idx?: number) => {
    const prevItem = idx !== undefined ? items[idx] : items[items.length - 1];
    const newItem: CashBankDocItem = { 
      id: uid(), 
      accId: '', 
      accType: 'gl',
      amount: 0, 
      description: prevItem?.description || '',
      currencyId: currencyId,
      exchangeRate: exchangeRate
    };
    
    if (idx !== undefined) {
      const newItems = [...items];
      newItems.splice(idx + 1, 0, newItem);
      setItems(newItems);
    } else {
      setItems([...items, newItem]);
    }
    setFocusedItemId(newItem.id);
  };

  const removeItem = (id: string) => {
    if (items.length === 1) return;
    setItems(items.filter(i => i.id !== id));
  };

  const importFromExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result as string;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(ws) as any[];

        if (jsonData.length === 0) {
          alert('الملف فارغ أو غير صالح');
          return;
        }

        const headers = Object.keys(jsonData[0]);
        const initialMapping: Record<string, string> = {};
        const fieldOptions = [
          { key: 'accCode', aliases: ['accCode', 'accId', 'code', 'الكود', 'رقم_الحساب', 'كود_الحساب', 'حساب'] },
          { key: 'accType', aliases: ['accType', 'type', 'النوع', 'تصنيف', 'نوع_الحساب'] },
          { key: 'amount', aliases: ['amount', 'المبلغ', 'مبلغ', 'القيمة'] },
          { key: 'description', aliases: ['description', 'desc', 'البيان', 'شرح', 'ملاحظات'] },
          { key: 'ccCode', aliases: ['ccCode', 'ccId', 'المركز', 'مركز_التكلفة', 'كود_المركز'] },
        ];

        fieldOptions.forEach(field => {
          const match = headers.find(h => field.aliases.some(alias => h.toLowerCase().includes(alias.toLowerCase())));
          if (match) initialMapping[field.key] = match;
        });

        setImportState({ show: true, headers, data: jsonData, mapping: initialMapping });
      } catch (err) {
        alert('❌ فشل قراءة الملف.');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  const executeImport = () => {
    const { data, mapping } = importState;
    const importedItems: CashBankDocItem[] = [];

    data.forEach(row => {
      const accCode = String(row[mapping.accCode] || '');
      if (!accCode) return;

      const accTypeVal = String(row[mapping.accType] || '');
      let accType: any = 'gl';
      if (accTypeVal.includes('عميل') || accTypeVal.includes('customer') || accTypeVal.includes('supplier') || accTypeVal.includes('مورد')) accType = 'customer-supplier';
      else if (accTypeVal.includes('صندوق') || accTypeVal.includes('fund')) accType = 'fund';
      else if (accTypeVal.includes('بنك') || accTypeVal.includes('bank')) accType = 'bank';

      let accId = '';
      let subId: string | undefined = undefined;

      // Find account
      const found = (db.accounts || []).find(a => a.code === accCode || a.id === accCode) ||
                   (db.customersSuppliers || []).find(c => c.code === accCode || c.id === accCode) ||
                   (db.funds || []).find(f => f.code === accCode || f.id === accCode) ||
                   (db.banks || []).find(b => b.code === accCode || b.id === accCode);

      if (found) {
        if ((found as any).accId) {
          accId = (found as any).accId;
          subId = found.id;
          if ((db.customersSuppliers || []).find(c => c.id === found.id)) accType = 'customer-supplier';
          else if ((db.funds || []).find(f => f.id === found.id)) accType = 'fund';
          else if ((db.banks || []).find(b => b.id === found.id)) accType = 'bank';
        } else {
          accId = found.id;
          accType = 'gl';
        }
      }

      if (!accId) return;

      const amount = parseFloat(row[mapping.amount]) || 0;
      const desc = String(row[mapping.description] || '');
      const ccCode = String(row[mapping.ccCode] || '');
      const ccId = (db.centers || []).find(c => c.code === ccCode || c.id === ccCode)?.id || '';

      importedItems.push({
        id: uid(),
        accId,
        subId,
        accType,
        amount,
        description: desc,
        ccId,
        currencyId,
        exchangeRate
      });
    });

    if (importedItems.length > 0) {
      setItems(prev => {
        const filtered = prev.filter(i => i.accId || i.amount > 0);
        return [...filtered, ...importedItems];
      });
    }
    setImportState({ show: false, headers: [], data: [], mapping: {} });
  };

  const downloadTemplate = () => {
    const headers = [['كود_الحساب', 'نوع_الحساب', 'المبلغ', 'البيان', 'كود_المركز']];
    const sample = [['1001', 'gl', '1000', 'دفعة من حساب', '']];
    const ws = XLSX.utils.aoa_to_sheet([...headers, ...sample]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Journal");
    XLSX.writeFile(wb, "cashbatch_import_template.xlsx");
  };

  const updateItem = (id: string, field: keyof CashBankDocItem, value: any) => {
    setItems(prev => prev.map(item => item.id === id ? { ...item, [field]: value } : item));
  };

  const batchUpdateItem = (id: string, updates: Partial<CashBankDocItem>) => {
    setItems(prev => prev.map(item => item.id === id ? { ...item, ...updates } : item));
  };

  const handleSave = async () => {
    if (items.some(i => !i.accId || i.amount <= 0)) {
      alert('يرجى اختيار الحساب وإدخال المبلغ لجميع الأسطر');
      return;
    }

    if (docType.startsWith('cash') && !fundId) {
      alert('يرجى اختيار الصندوق');
      return;
    }

    if (!docType.startsWith('cash') && !bankId) {
      alert('يرجى اختيار البنك');
      return;
    }

    // Exchange rate validation
    if (currencyId) {
      const currency = db.currencies?.find(c => c.id === currencyId);
      if (currency) {
        if (currency.minRate && exchangeRate < currency.minRate) {
          alert(`سعر الصرف أقل من الحد الأدنى المسموح به (${currency.minRate})`);
          return;
        }
        if (currency.maxRate && exchangeRate > currency.maxRate) {
          alert(`سعر الصرف أعلى من الحد الأعلى المسموح به (${currency.maxRate})`);
          return;
        }
      }
    }

    const doc: CashBankDoc = {
      id: initialDoc?.id || uid(),
      companyId: user.companyId,
      type: docType,
      date,
      docNum,
      ref,
      description,
      amount: totalAmount,
      items,
      fundId: docType.startsWith('cash') ? fundId : undefined,
      bankId: !docType.startsWith('cash') ? bankId : undefined,
      branchId,
      collector,
      maturityDate,
      currencyId,
      exchangeRate,
      checkNum: docType.includes('check') ? checkNum : undefined,
      checkDate: docType.includes('check') ? checkDate : undefined,
      transferRef: docType.includes('transfer') ? transferRef : undefined,
      createdAt: initialDoc?.createdAt || new Date().toISOString(),
      createdBy: initialDoc?.createdBy || user.id
    };

    await onSave(doc);
  };

  const docTypes: { value: CashBankDocType; label: string; icon: any }[] = ([
    { value: 'cash-payment', label: 'صرف نقدي', icon: Banknote },
    { value: 'cash-receipt', label: 'قبض نقدي', icon: Banknote },
    { value: 'check-payment', label: 'صرف شيك', icon: CreditCard },
    { value: 'check-receipt', label: 'قبض شيك', icon: CreditCard },
    { value: 'transfer-payment', label: 'صرف حوالة', icon: Repeat },
    { value: 'transfer-receipt', label: 'قبض حوالة', icon: Repeat },
  ] as const).filter(t => {
    if (initialDoc?.type.startsWith('cash')) return t.value.startsWith('cash');
    if (initialDoc?.type.includes('check') || initialDoc?.type.includes('transfer')) return !t.value.startsWith('cash');
    return true;
  }) as any;

  const isCash = docType.startsWith('cash');
  const title = isCash ? 'سند نقدي' : 'سند بنكي';

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 no-print">
        <div className="flex items-center gap-4">
          <div className={`p-3 ${isCash ? 'bg-emerald-600 shadow-emerald-100' : 'bg-blue-600 shadow-blue-100'} rounded-2xl shadow-lg`}>
            {isCash ? <Banknote className="text-white" size={24} /> : <CreditCard className="text-white" size={24} />}
          </div>
          <div>
            <h1 className="text-2xl font-black text-slate-800">{title}</h1>
            <p className="text-slate-500 font-medium">{isCash ? 'تسجيل سندات القبض والصرف النقدي' : 'تسجيل الشيكات والحوالات البنكية'}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onNavigate && (
            <div className="flex items-center bg-white rounded-xl border border-slate-200 p-1">
              <button onClick={() => onNavigate('prev')} className="p-2 hover:bg-slate-50 rounded-lg text-slate-600 transition-colors"><ChevronRight size={20} /></button>
              <div className="w-px h-4 bg-slate-200 mx-1" />
              <button onClick={() => onNavigate('new')} className="p-2 hover:bg-slate-50 rounded-lg text-blue-600 transition-colors"><Plus size={20} /></button>
              <div className="w-px h-4 bg-slate-200 mx-1" />
              <button onClick={() => onNavigate('next')} className="p-2 hover:bg-slate-50 rounded-lg text-slate-600 transition-colors"><ChevronLeft size={20} /></button>
            </div>
          )}
          {initialDoc && onDelete && (
            <button 
              onClick={() => onDelete(initialDoc.id)}
              className="p-3 text-red-600 hover:bg-red-50 rounded-xl transition-colors border border-transparent hover:border-red-100"
            >
              <Trash2 size={20} />
            </button>
          )}
          <button onClick={onCancel} className="p-3 text-slate-400 hover:bg-slate-50 rounded-xl transition-colors">
            <X size={24} />
          </button>
        </div>
      </div>

      <div className="space-y-6">
        {/* Main Form */}
        <div className="space-y-6">
          {/* Header Grid - Reorganized for better flow */}
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm grid grid-cols-1 md:grid-cols-3 gap-6 relative z-20">
            {/* Column 1 (Right): Basic Info */}
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                  <Building2 size={12} />
                  الفرع
                </label>
                <select
                  value={branchId}
                  onChange={(e) => setBranchId(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm transition-all"
                >
                  <option value="">المركز الرئيسي</option>
                  {db.branches?.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                  <Hash size={12} />
                  رقم المستند
                </label>
                <input 
                  type="text"
                  value={docNum}
                  readOnly
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-100 font-mono font-bold text-sm text-slate-500 cursor-not-allowed"
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                  <Calendar size={12} />
                  التاريخ
                </label>
                <input 
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm transition-all"
                />
              </div>
            </div>

            {/* Column 2 (Middle): Financial Context */}
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                  <Wallet size={12} />
                  {isCash ? 'الصندوق' : 'البنك'}
                </label>
                {isCash ? (
                  <select
                    value={fundId}
                    onChange={(e) => setFundId(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm transition-all"
                  >
                    <option value="">اختر الصندوق...</option>
                    {db.funds?.map(f => (
                      <option key={f.id} value={f.id}>{f.name}</option>
                    ))}
                  </select>
                ) : (
                  <select
                    value={bankId}
                    onChange={(e) => setBankId(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm transition-all"
                  >
                    <option value="">اختر البنك...</option>
                    {db.banks?.map(b => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </select>
                )}
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                  <Coins size={12} />
                  العملة
                </label>
                <select
                  value={currencyId}
                  onChange={(e) => {
                    const newCId = e.target.value;
                    const rate = db.currencies?.find(c => c.id === newCId)?.exchangeRate || 1;
                    setCurrencyId(newCId);
                    setExchangeRate(rate);
                  }}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm transition-all"
                >
                  <option value="">اختر العملة...</option>
                  {db.currencies?.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                  <ArrowUpRight size={12} />
                  سعر الصرف
                </label>
                <input 
                  type="number"
                  step="0.000001"
                  value={exchangeRate}
                  onChange={(e) => setExchangeRate(parseFloat(e.target.value) || 1)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-mono font-bold text-sm text-center transition-all"
                />
              </div>
            </div>

            {/* Column 3 (Left): Additional Details */}
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                  <FileText size={12} />
                  المرجع
                </label>
                <input 
                  type="text"
                  value={ref}
                  onChange={(e) => setRef(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm transition-all"
                  placeholder="رقم المرجع..."
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                  <Calendar size={12} />
                  تاريخ الاستحقاق
                </label>
                <input 
                  type="date"
                  value={maturityDate}
                  onChange={(e) => setMaturityDate(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm transition-all"
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-2">
                  <Users size={12} />
                  المحصل
                </label>
                <input 
                  type="text"
                  value={collector}
                  onChange={(e) => setCollector(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm transition-all"
                  placeholder="اسم المحصل..."
                />
              </div>
            </div>
          </div>

          {/* Type Selection Tabs */}
          <div className="bg-white p-2 rounded-2xl border border-slate-100 shadow-sm flex gap-2 overflow-x-auto no-scrollbar">
            {docTypes.map((t) => (
              <button
                key={t.value}
                onClick={() => setDocType(t.value)}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl transition-all whitespace-nowrap font-bold text-sm ${
                  docType === t.value 
                    ? (isCash ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' : 'bg-blue-600 text-white shadow-lg shadow-blue-100')
                    : 'text-slate-500 hover:bg-slate-50'
                }`}
              >
                <t.icon size={18} />
                {t.label}
              </button>
            ))}
          </div>

          {/* Multi-payment Table */}
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden relative z-10">
            <div className="p-4 sm:p-6 border-b border-slate-50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="bg-blue-50 p-2 rounded-xl">
                  <Info className="text-blue-600" size={20} />
                </div>
                <h3 className="text-lg font-black text-slate-800">تفاصيل السند (الصرف المتعدد)</h3>
                <div className="h-4 w-px bg-slate-200 mx-2" />
                <button onClick={downloadTemplate} className="text-[10px] font-bold text-slate-400 hover:text-blue-600 transition-colors uppercase tracking-widest">نموذج</button>
                <label className="text-[10px] font-bold text-slate-400 hover:text-blue-600 transition-colors uppercase tracking-widest cursor-pointer">
                  إكسل
                  <input type="file" className="hidden" accept=".xlsx,.xls" onChange={importFromExcel} />
                </label>
              </div>
              <button 
                onClick={() => addItem()}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl font-black text-sm hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 active:scale-95"
              >
                <Plus size={18} />
                إضافة سطر جديد
              </button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-right min-w-[1000px] lg:min-w-full">
                <thead className="bg-slate-50/50">
                    <tr>
                      <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest w-10">#</th>
                      <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest w-32">نوع الحساب</th>
                      <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">الحساب (كود / اسم)</th>
                      <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest w-28 text-center">العملة</th>
                      <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest w-24 text-center">سعر الصرف</th>
                      <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest w-32 text-center">المبلغ</th>
                      <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest w-36 text-center">مركز التكلفة</th>
                      <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">البيان</th>
                      <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest w-10"></th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {items.map((item, idx) => {
                    const getAccountName = () => {
                      const category = item.accType || 'gl';
                      if (item.subId) {
                        switch (category) {
                          case 'customer-supplier': return db.customersSuppliers?.find(a => a.id === item.subId)?.name || '-';
                          case 'fund': return db.funds?.find(a => a.id === item.subId)?.name || '-';
                          case 'bank': return db.banks?.find(a => a.id === item.subId)?.name || '-';
                          case 'warehouse': return db.warehouses?.find(a => a.id === item.subId)?.name || '-';
                        }
                      }
                      return (db.accounts || []).find(a => a.id === item.accId)?.name || '-';
                    };

                    const getAccountCode = () => {
                      const category = item.accType || 'gl';
                      if (item.subId) {
                        switch (category) {
                          case 'customer-supplier': return (db.customersSuppliers || []).find(a => a.id === item.subId)?.code || 'اختر...';
                          case 'fund': return (db.funds || []).find(a => a.id === item.subId)?.code || 'اختر...';
                          case 'bank': return (db.banks || []).find(a => a.id === item.subId)?.code || 'اختر...';
                          case 'warehouse': return (db.warehouses || []).find(a => a.id === item.subId)?.code || 'اختر...';
                        }
                      }
                      return (db.accounts || []).find(a => a.id === item.accId)?.code || 'اختر...';
                    };

                    const isLast = idx === items.length - 1;

                    const handleKeyDown = (e: React.KeyboardEvent, field: string) => {
                      if (e.key === 'Enter') {
                        if (field === 'description' && isLast && item.amount > 0 && item.accId) {
                          addItem();
                        } else if (field === 'amount' && isLast && item.amount > 0 && item.accId && !item.description) {
                          addItem();
                        }
                      }
                      if (e.key === 'Delete' && e.ctrlKey) {
                        removeItem(item.id);
                      }
                    };

                    return (
                      <tr key={item.id} className="hover:bg-blue-50/30 transition-colors text-sm group">
                        <td className="px-4 py-3 text-center text-slate-300 font-mono text-xs">{(idx + 1).toString().padStart(2, '0')}</td>
                        <td className="px-4 py-3">
                          <select
                            value={item.accType || 'gl'}
                            onChange={e => {
                              updateItem(item.id, 'accType', e.target.value as AccountCategory);
                              updateItem(item.id, 'accId', ''); 
                              updateItem(item.id, 'subId', undefined);
                            }}
                            className="w-full px-2 py-2 rounded-lg border border-slate-200 outline-none text-xs font-bold bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all"
                          >
                            <option value="gl">أستاذ عام</option>
                            <option value="customer-supplier">عملاء وموردين</option>
                            <option value="fund">صناديق</option>
                            <option value="bank">بنوك</option>
                            <option value="all">بحث في الكل</option>
                          </select>
                        </td>
                        <td className="px-4 py-3 relative min-w-[250px]">
                          <div className="relative">
                            <input 
                              type="text"
                              autoFocus={focusedItemId === item.id}
                              value={showAccSearch?.idx === idx ? accSearchQuery : (item.id && (item.subId || item.accId) ? getAccountName() : '')}
                              onFocus={(e) => {
                                e.target.select();
                                setAccSearchQuery('');
                                setShowAccSearch({ idx });
                              }}
                              onChange={e => {
                                setAccSearchQuery(e.target.value);
                                if (showAccSearch?.idx !== idx) setShowAccSearch({ idx });
                              }}
                              placeholder="ابحث عن حساب..."
                              className={`w-full px-3 py-2.5 rounded-xl border text-right font-bold text-sm transition-all outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 ${item.accId ? 'border-slate-100 bg-slate-50 text-slate-700' : 'border-red-100 bg-red-50 text-red-400'}`}
                            />
                            
                            <AnimatePresence>
                              {showAccSearch?.idx === idx && (
                                <>
                                  <div className="fixed inset-0 z-40" onClick={() => setShowAccSearch(null)} />
                                  <motion.div
                                    initial={{ opacity: 0, y: 5 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: 5 }}
                                    className="absolute z-[100] right-0 top-full mt-1 bg-white rounded-2xl border border-slate-200 shadow-2xl p-4 min-w-[320px] w-full"
                                  >
                                    <div className="flex items-center justify-between mb-3 border-b border-slate-50 pb-2">
                                      <h4 className="font-black text-slate-800 text-[10px] uppercase tracking-widest">
                                        {item.accType === 'gl' ? 'دليل الحسابات' : 
                                         item.accType === 'customer-supplier' ? 'دليل العملاء والموردين' :
                                         item.accType === 'fund' ? 'دليل الصناديق' :
                                         item.accType === 'bank' ? 'دليل البنوك' : 'البحث في كافة الدلائل'}
                                      </h4>
                                      <button onClick={() => setShowAccSearch(null)} className="p-1 text-slate-300 hover:text-slate-500 transition-colors"><X size={16} /></button>
                                    </div>
                                    <div className="max-h-60 overflow-y-auto space-y-1 no-scrollbar overflow-x-hidden">
                                      {filteredAccounts.length > 0 ? filteredAccounts.map(acc => (
                                        <button
                                          key={`${acc.category}-${acc.id}`}
                                          onClick={() => {
                                            const category = acc.category || item.accType || 'gl';
                                            const updates: Partial<CashBankDocItem> = { accType: category };
                                            if (category === 'gl') {
                                              updates.accId = acc.id;
                                              updates.subId = undefined;
                                            } else {
                                              updates.accId = acc.accId || '';
                                              updates.subId = acc.id;
                                            }
                                            batchUpdateItem(item.id, updates);
                                            setShowAccSearch(null);
                                            setAccSearchQuery('');
                                          }}
                                          className="w-full text-right px-4 py-3 hover:bg-blue-50 rounded-xl transition-all flex flex-col border-b border-slate-50 last:border-0"
                                        >
                                          <div className="flex items-center justify-between gap-4">
                                            <span className="font-bold text-slate-800 text-sm">{acc.name}</span>
                                            <span className="text-[10px] text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded font-mono font-bold">{acc.code}</span>
                                          </div>
                                          {item.accType === 'all' && (
                                            <span className="text-[9px] text-slate-400 capitalize mt-1">
                                              {acc.category === 'gl' ? 'أستاذ عام' : 
                                               acc.category === 'customer-supplier' ? 'عميل/مورد' :
                                               acc.category === 'fund' ? 'صندوق' : 'بنك'}
                                            </span>
                                          )}
                                        </button>
                                      )) : (
                                        <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                                          <div className="text-slate-400 font-bold text-xs">لا توجد نتائج مطابقة</div>
                                        </div>
                                      )}
                                    </div>
                                  </motion.div>
                                </>
                              )}
                            </AnimatePresence>
                          </div>
                        </td>
                      <td className="px-4 py-3 w-32">
                        <select
                          value={item.currencyId || currencyId}
                          onChange={e => {
                            const cId = e.target.value;
                            const rate = db.currencies?.find(c => c.id === cId)?.exchangeRate || 1;
                            updateItem(item.id, 'currencyId', cId);
                            updateItem(item.id, 'exchangeRate', rate);
                          }}
                          className="w-full px-3 py-2 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-bold text-xs transition-all"
                        >
                          {db.currencies?.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-4 py-3 w-24">
                        <input 
                          type="number"
                          step="0.000001"
                          value={item.exchangeRate ?? exchangeRate}
                          onChange={e => updateItem(item.id, 'exchangeRate', parseFloat(e.target.value) || 1)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-mono font-bold text-slate-500 text-center text-xs transition-all"
                        />
                      </td>
                      <td className="px-4 py-3 w-32">
                        <input 
                          type="number"
                          value={item.amount || ''}
                          onChange={e => updateItem(item.id, 'amount', parseFloat(e.target.value) || 0)}
                          onKeyDown={e => handleKeyDown(e, 'amount')}
                          className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-black text-blue-600 text-center transition-all"
                          placeholder="0.00"
                        />
                      </td>
                      <td className="px-4 py-3 w-32">
                        <select
                          value={item.ccId || ''}
                          onChange={e => updateItem(item.id, 'ccId', e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-bold text-xs transition-all"
                        >
                          <option value="">بدون مركز</option>
                          {(db.centers || []).filter(c => c.isLeaf).map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-4 py-3">
                        <input 
                          type="text"
                          value={item.description}
                          onChange={e => updateItem(item.id, 'description', e.target.value)}
                          onKeyDown={e => handleKeyDown(e, 'description')}
                          className="w-full px-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none font-medium text-slate-600 text-xs transition-all"
                          placeholder="البيان..."
                        />
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => addItem(idx)}
                            className="p-2 text-slate-300 hover:text-blue-500 transition-colors"
                            title="إضافة سطر بعد هذا السطر"
                          >
                            <Plus size={16} />
                          </button>
                          <button 
                            onClick={() => removeItem(item.id)}
                            className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                            title="حذف السطر"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                </tbody>
                <tfoot className="bg-slate-50/50">
                  <tr>
                    <td colSpan={6} className="px-6 py-6 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">إجمالي السطور:</td>
                    <td className="px-4 py-6 text-center">
                      <div className="inline-block px-6 py-2 bg-blue-600 text-white rounded-2xl font-black text-lg shadow-xl shadow-blue-100">
                        {totalAmount.toLocaleString()}
                      </div>
                    </td>
                    <td colSpan={3}></td>
                  </tr>
                </tfoot>
              </table>
            </div>
            
            <div className="p-6 sm:p-8 bg-slate-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-8">
              <div className="flex flex-wrap items-center gap-8 sm:gap-12">
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">إجمالي السند</span>
                  <span className="text-3xl font-black text-white">
                    {totalAmount.toLocaleString()} 
                    <span className="text-sm text-slate-500 mr-2">{db.currencies?.find(c => c.id === currencyId)?.code || db.currencies?.find(c => c.isDefault)?.code || ''}</span>
                  </span>
                </div>
                {currencyId && db.currencies?.find(c => c.id === currencyId)?.code !== (db.currencies?.find(c => c.isDefault)?.code || 'SAR') && (
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">المقابل بـ ({db.currencies?.find(c => c.isDefault)?.code || 'SAR'})</span>
                    <span className="text-2xl font-black text-emerald-400">
                      {(totalAmount * exchangeRate).toLocaleString()} 
                      <span className="text-sm text-slate-500 mr-2">{db.currencies?.find(c => c.isDefault)?.code || 'SAR'}</span>
                    </span>
                  </div>
                )}
              </div>

              {/* Action Buttons - Side by Side */}
              <div className="flex items-center gap-4 w-full sm:w-auto">
                <button
                  onClick={handleSave}
                  className={`flex-1 sm:flex-none px-12 py-4 ${isCash ? 'bg-emerald-600 shadow-emerald-900/20' : 'bg-blue-600 shadow-blue-900/20'} text-white rounded-2xl font-black text-lg shadow-2xl hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3`}
                >
                  <Save size={20} />
                  حفظ السند
                </button>
                {initialDoc && onPrint && (
                  <button
                    onClick={() => onPrint(initialDoc)}
                    className="flex-1 sm:flex-none px-12 py-4 bg-white/10 text-white rounded-2xl font-black text-lg hover:bg-white/20 transition-all flex items-center justify-center gap-3"
                  >
                    <Printer size={20} />
                    طباعة
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Extra Info for Checks/Transfers */}
          {(docType.includes('check') || docType.includes('transfer')) && (
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
              <h3 className="text-lg font-black text-slate-800">معلومات إضافية</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-6 bg-slate-50 rounded-2xl border border-slate-100">
                {docType.includes('check') ? (
                  <>
                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-slate-500 mr-2">رقم الشيك</label>
                      <input
                        type="text"
                        value={checkNum}
                        onChange={(e) => setCheckNum(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none font-bold text-sm bg-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-slate-500 mr-2">تاريخ الاستحقاق</label>
                      <input
                        type="date"
                        value={checkDate}
                        onChange={(e) => setCheckDate(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none font-bold text-sm bg-white"
                      />
                    </div>
                  </>
                ) : (
                  <div className="col-span-2 space-y-2">
                    <label className="block text-xs font-bold text-slate-500 mr-2">رقم الحوالة / المرجع</label>
                    <input
                      type="text"
                      value={transferRef}
                      onChange={(e) => setTransferRef(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none font-bold text-sm bg-white"
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Main Description */}
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <label className="block text-sm font-bold text-slate-700 mb-4">البيان العام للسند</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full px-6 py-4 rounded-2xl border border-slate-200 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none font-medium text-slate-600 transition-all"
              placeholder="اكتب وصفاً عاماً للحركة المالية..."
            />
          </div>
        </div>
      </div>

      <AnimatePresence>
        {importState.show && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4" dir="rtl">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setImportState({ ...importState, show: false })}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-xl rounded-3xl shadow-2xl p-8"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h3 className="text-2xl font-black text-slate-900">ربط أعمدة الإكسل</h3>
                  <p className="text-slate-500 text-sm mt-1">طابق حقول المستند مع أعمدة ملف الإكسل</p>
                </div>
                <button onClick={() => setImportState({ ...importState, show: false })} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X size={24} className="text-slate-400" />
                </button>
              </div>

              <div className="space-y-4 mb-10 min-h-[300px]">
                {[
                  { key: 'accCode', label: 'كود الحساب', required: true },
                  { key: 'accType', label: 'نوع الحساب (gl, fund, bank, sub)', required: false },
                  { key: 'amount', label: 'المبلغ', required: true },
                  { key: 'description', label: 'البيان', required: false },
                  { key: 'ccCode', label: 'كود المركز', required: false },
                ].map(field => (
                  <div key={field.key} className="flex items-center justify-between gap-6">
                    <label className="text-sm font-black text-slate-700 min-w-[140px] flex items-center gap-2">
                       <div className="w-1.5 h-6 bg-blue-100 rounded-full" />
                      {field.label}
                      {field.required && <span className="text-red-500 mr-1">*</span>}
                    </label>
                    <select 
                      value={importState.mapping[field.key] || ''}
                      onChange={e => setImportState({
                        ...importState,
                        mapping: { ...importState.mapping, [field.key]: e.target.value }
                      })}
                      className="flex-1 px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all text-sm font-bold bg-slate-50/30"
                    >
                      <option value="">-- اختر العمود --</option>
                      {importState.headers.map(h => (
                        <option key={h} value={h}>{h}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => setImportState({ ...importState, show: false })}
                  className="flex-1 px-6 py-4 rounded-2xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-all text-lg"
                >
                  إلغاء
                </button>
                <button 
                  onClick={executeImport}
                  disabled={!importState.mapping.accCode || !importState.mapping.amount}
                  className="flex-1 px-6 py-4 rounded-2xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 text-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  بدء الاستيراد
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default CashBankForm;
