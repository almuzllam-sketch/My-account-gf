import React, { useState } from 'react';
import { 
  Tag, 
  Search, 
  Save, 
  Plus, 
  Trash2,
  Package,
  ArrowRightLeft
} from 'lucide-react';
import { motion } from 'motion/react';
import { DB, Item, Unit } from '../types';

interface PriceListProps {
  db: DB;
  onUpdateDB: (newDb: DB, collectionName?: string, docId?: string, data?: any, isDelete?: boolean) => void;
  showNotification: (message: string, type?: 'success' | 'error' | 'warning') => void;
}

export const PriceList: React.FC<PriceListProps> = ({ db, onUpdateDB, showNotification }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredItems = db.items.filter(i => 
    i.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    i.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const updatePrice = (itemId: string, unitName: string, price: number) => {
    const newItems = db.items.map(item => {
      if (item.id === itemId) {
        const prices = item.prices || [];
        const existingPriceIdx = prices.findIndex(p => p.unitName === unitName);
        
        let newPrices = [...prices];
        if (existingPriceIdx > -1) {
          newPrices[existingPriceIdx] = { unitName, price };
        } else {
          newPrices.push({ unitName, price });
        }
        
        const updatedItem = { ...item, prices: newPrices };
        return updatedItem;
      }
      return item;
    });
    
    const changedItem = newItems.find(i => i.id === itemId);
    onUpdateDB({ ...db, items: newItems }, 'items', itemId, changedItem);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="bg-blue-600 p-3 rounded-2xl shadow-lg shadow-blue-100">
            <Tag className="text-white" size={24} />
          </div>
          <div>
            <h1 className="text-xl sm:text-3xl font-bold text-slate-900">جدول تسعيرات الأصناف</h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">تحديد أسعار البيع لكل وحدة من وحدات الأصناف</p>
          </div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder="ابحث عن صنف بالاسم أو الكود..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pr-12 pl-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="p-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">الصنف</th>
                <th className="p-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">الوحدات والأسعار</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredItems.map(item => (
                <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-slate-100 p-2 rounded-lg text-slate-500">
                        <Package size={20} />
                      </div>
                      <div>
                        <div className="font-bold text-slate-800">{item.name}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{item.code}</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      {item.units.map(unit => {
                        const priceObj = item.prices?.find(p => p.unitName === unit.name);
                        return (
                          <div key={unit.name} className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-100">
                            <span className="text-xs font-bold text-slate-500 min-w-[60px]">{unit.name}</span>
                            <div className="relative flex-1">
                              <input 
                                type="number" 
                                value={priceObj?.price || 0}
                                onChange={e => updatePrice(item.id, unit.name, parseFloat(e.target.value) || 0)}
                                className="w-full px-3 py-1.5 rounded-lg border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 text-sm font-bold text-blue-600"
                                placeholder="السعر"
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </td>
                </tr>
              ))}
              {filteredItems.length === 0 && (
                <tr>
                  <td colSpan={2} className="p-12 text-center text-slate-400">
                    لا توجد أصناف مطابقة للبحث
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
