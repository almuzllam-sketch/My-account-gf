import React, { useMemo, useState } from 'react';
import { DB, DocItem } from '../types';
import { Search, Filter, FileText, Download } from 'lucide-react';
import { motion } from 'motion/react';

interface InventoryReportsProps {
  db: DB;
}

export const InventoryReports: React.FC<InventoryReportsProps> = ({ db }) => {
  const [search, setSearch] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'issue' | 'purchase'>('all');

  const aggregatedItems = useMemo(() => {
    const itemsMap: Record<string, { name: string, code: string, qty: number, unit: string, lastDate: string }> = {};

    (db.docs || []).forEach(doc => {
      // Filter by type
      if (typeFilter !== 'all' && doc.type !== typeFilter) return;
      
      // Filter by date if provided
      if (dateFrom && doc.date < dateFrom) return;
      if (dateTo && doc.date > dateTo) return;

      (doc.items || []).forEach(it => {
        const item = (db.items || []).find(i => i.id === it.itemId);
        if (!item) return;

        const key = `${it.itemId}-${it.unit}`;
        if (!itemsMap[key]) {
          itemsMap[key] = {
            name: item.name,
            code: item.code,
            qty: 0,
            unit: it.unit,
            lastDate: doc.date
          };
        }
        itemsMap[key].qty += it.qty;
        if (doc.date > itemsMap[key].lastDate) {
          itemsMap[key].lastDate = doc.date;
        }
      });
    });

    return Object.values(itemsMap).filter(item => 
      item.name.toLowerCase().includes(search.toLowerCase()) || 
      item.code.toLowerCase().includes(search.toLowerCase())
    ).sort((a, b) => b.qty - a.qty);
  }, [db, search, dateFrom, dateTo, typeFilter]);

  const exportToCSV = () => {
    const companyName = db.company?.name || 'شركة المثال المحدودة';
    const typeLabel = typeFilter === 'purchase' ? 'مشتريات' : typeFilter === 'issue' ? 'صرف' : 'مجمع';
    const reportTitle = `التقرير المخزني - ${typeLabel}`;
    
    const headers = ['كود الصنف', 'اسم الصنف', 'الوحدة', 'إجمالي الكمية', 'آخر تاريخ حركة'];
    const rows = aggregatedItems.map(i => [i.code, i.name, i.unit, i.qty, i.lastDate]);
    
    const csvContent = [
      `"${companyName}"`,
      `"${reportTitle}"`,
      `"تاريخ التصدير: ${new Date().toLocaleDateString('ar-SA')}"`,
      '',
      headers.join(','),
      ...rows.map(r => r.map(c => `"${c}"`).join(','))
    ].join('\n');
    const blob = new Blob(["\ufeff" + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `تقرير_مخزني_${typeLabel}_${new Date().toISOString().split('T')[0]}.csv`);
    link.click();
  };

  const exportSample = () => {
    const headers = ['كود الصنف', 'اسم الصنف', 'الوحدة', 'إجمالي الكمية', 'آخر تاريخ حركة'];
    const sampleRows = [
      ['ITEM-001', 'صنف تجريبي 1', 'حبة', '100', '2026-04-09'],
      ['ITEM-002', 'صنف تجريبي 2', 'كرتون', '50', '2026-04-10']
    ];
    const csvContent = [headers, ...sampleRows].map(e => e.join(",")).join("\n");
    const blob = new Blob(["\ufeff" + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `نموذج_تقرير_مخزني.csv`);
    link.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">التقارير المخزنية</h1>
          <p className="text-slate-500 mt-1">عرض إجمالي الكميات (صرف / شراء) لكل صنف</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={exportSample}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-6 py-2.5 rounded-xl font-bold transition-all flex items-center gap-2 border border-slate-200"
          >
            <Download size={18} />
            سحب مثال
          </button>
          <button 
            onClick={exportToCSV}
            className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2.5 rounded-xl font-bold shadow-lg shadow-emerald-100 transition-all flex items-center gap-2"
          >
            <Download size={18} />
            تصدير التقرير
          </button>
        </div>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex flex-wrap gap-4 items-center">
        <div className="flex-1 min-w-[240px] relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="بحث باسم الصنف أو الكود..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-10 pl-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          />
        </div>
        
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
          <button 
            onClick={() => setTypeFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${typeFilter === 'all' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            الكل
          </button>
          <button 
            onClick={() => setTypeFilter('issue')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${typeFilter === 'issue' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            صرف
          </button>
          <button 
            onClick={() => setTypeFilter('purchase')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${typeFilter === 'purchase' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            مشتريات
          </button>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-400">من:</span>
          <input 
            type="date" 
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm"
          />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-400">إلى:</span>
          <input 
            type="date" 
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className="px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm"
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse min-w-[600px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="p-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">كود الصنف</th>
                <th className="p-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">اسم الصنف</th>
                <th className="p-4 text-center text-xs font-bold text-slate-500 uppercase tracking-wider w-32">الوحدة</th>
                <th className="p-4 text-center text-xs font-bold text-slate-500 uppercase tracking-wider">إجمالي الكمية</th>
                <th className="p-4 text-center text-xs font-bold text-slate-500 uppercase tracking-wider">آخر صرف</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {aggregatedItems.map((item, idx) => (
                <motion.tr 
                  key={`${item.code}-${item.unit}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className="hover:bg-slate-50/50 transition-colors"
                >
                  <td className="p-4">
                    <span className="font-mono text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded">
                      {item.code}
                    </span>
                  </td>
                  <td className="p-4 text-sm font-bold text-slate-800">
                    {item.name}
                  </td>
                  <td className="p-4 text-center text-sm text-slate-500 w-32">
                    {item.unit}
                  </td>
                  <td className="p-4 text-center">
                    <span className="text-sm font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
                      {item.qty}
                    </span>
                  </td>
                  <td className="p-4 text-center text-xs text-slate-400">
                    {item.lastDate}
                  </td>
                </motion.tr>
              ))}
              {aggregatedItems.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-12 text-center text-slate-400">
                    <FileText size={48} className="mx-auto mb-4 opacity-10" />
                    <p>لا توجد بيانات لعرضها</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
