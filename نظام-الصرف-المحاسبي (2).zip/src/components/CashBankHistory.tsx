import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Calendar, 
  ArrowRight, 
  Printer, 
  Edit2, 
  Trash2, 
  ChevronRight, 
  ChevronLeft,
  CreditCard,
  Banknote,
  Repeat,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DB, CashBankDoc, CashBankDocType, User } from '../types';

interface CashBankHistoryProps {
  db: DB;
  user: User;
  onEdit: (doc: CashBankDoc) => void;
  onDelete: (id: string) => void;
  onPrint: (doc: CashBankDoc) => void;
  filter?: 'cash' | 'bank' | 'all';
}

const CashBankHistory: React.FC<CashBankHistoryProps> = ({ db, user, onEdit, onDelete, onPrint, filter = 'all' }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<CashBankDocType | 'all'>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const title = filter === 'cash' ? 'سجل الحركة النقدية' : filter === 'bank' ? 'سجل الحركة البنكية' : 'سجل الحركة النقدية والبنكية';
  const description = filter === 'cash' ? 'عرض وإدارة سندات الصرف والقبض النقدي' : filter === 'bank' ? 'عرض وإدارة الشيكات والحوالات البنكية' : 'عرض وإدارة كافة السندات المالية';

  const filteredDocs = useMemo(() => {
    let docs = db.cashBankDocs || [];
    
    if (filter === 'cash') {
      docs = docs.filter(d => d.type.startsWith('cash'));
    } else if (filter === 'bank') {
      docs = docs.filter(d => !d.type.startsWith('cash'));
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      docs = docs.filter(d => 
        d.docNum.toLowerCase().includes(q) || 
        d.ref.toLowerCase().includes(q) ||
        d.description.toLowerCase().includes(q)
      );
    }

    if (typeFilter !== 'all') {
      docs = docs.filter(d => d.type === typeFilter);
    }

    if (dateFrom) {
      docs = docs.filter(d => d.date >= dateFrom);
    }

    if (dateTo) {
      docs = docs.filter(d => d.date <= dateTo);
    }

    return [...docs].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [db.cashBankDocs, searchQuery, typeFilter, dateFrom, dateTo]);

  const getDocTypeInfo = (type: CashBankDocType) => {
    switch (type) {
      case 'cash-payment': return { label: 'صرف نقدي', icon: Banknote, color: 'text-red-600', bg: 'bg-red-50' };
      case 'cash-receipt': return { label: 'قبض نقدي', icon: Banknote, color: 'text-green-600', bg: 'bg-green-50' };
      case 'check-payment': return { label: 'صرف شيك', icon: CreditCard, color: 'text-red-600', bg: 'bg-red-50' };
      case 'check-receipt': return { label: 'قبض شيك', icon: CreditCard, color: 'text-green-600', bg: 'bg-green-50' };
      case 'transfer-payment': return { label: 'صرف حوالة', icon: Repeat, color: 'text-red-600', bg: 'bg-red-50' };
      case 'transfer-receipt': return { label: 'قبض حوالة', icon: Repeat, color: 'text-green-600', bg: 'bg-green-50' };
    }
  };

  const getAccountName = (id: string) => (db.accounts || []).find(a => a.id === id)?.name || 'غير معروف';
  const getAccountNames = (doc: CashBankDoc) => {
    if (!doc.items || doc.items.length === 0) return 'غير معروف';
    const firstAcc = getAccountName(doc.items[0].accId);
    if (doc.items.length === 1) return firstAcc;
    return `${firstAcc} (+${doc.items.length - 1})`;
  };

  const getFundBankName = (doc: CashBankDoc) => {
    if (doc.fundId) return (db.funds || []).find(f => f.id === doc.fundId)?.name || 'صندوق غير معروف';
    if (doc.bankId) return (db.banks || []).find(b => b.id === doc.bankId)?.name || 'بنك غير معروف';
    return '-';
  };

  const getCurrencyCode = (id?: string) => (db.currencies || []).find(c => c.id === id)?.code || 'SAR';

  return (
    <div className="p-4 sm:p-8 max-w-7xl mx-auto" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 mb-8">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-blue-600 rounded-2xl shadow-lg shadow-blue-200">
            <FileText className="text-white" size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-black text-slate-800">{title}</h1>
            <p className="text-slate-500 font-medium">{description}</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm mb-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative col-span-1 md:col-span-2">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input
              type="text"
              placeholder="بحث برقم السند، المرجع، أو البيان..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-12 pl-4 py-3 rounded-2xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-bold"
            />
          </div>
          
          <div className="relative">
            <Filter className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as any)}
              className="w-full pr-12 pl-4 py-3 rounded-2xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-bold appearance-none"
            >
              <option value="all">جميع الأنواع</option>
              {filter !== 'bank' && (
                <>
                  <option value="cash-payment">صرف نقدي</option>
                  <option value="cash-receipt">قبض نقدي</option>
                </>
              )}
              {filter !== 'cash' && (
                <>
                  <option value="check-payment">صرف شيك</option>
                  <option value="check-receipt">قبض شيك</option>
                  <option value="transfer-payment">صرف حوالة</option>
                  <option value="transfer-receipt">قبض حوالة</option>
                </>
              )}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="w-full pr-10 pl-2 py-3 rounded-2xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-bold text-xs"
              />
            </div>
            <span className="text-slate-300">إلى</span>
            <div className="relative flex-1">
              <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="w-full pr-10 pl-2 py-3 rounded-2xl border border-slate-100 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-bold text-xs"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="p-4 font-black text-slate-500 text-sm">التاريخ</th>
                <th className="p-4 font-black text-slate-500 text-sm">النوع</th>
                <th className="p-4 font-black text-slate-500 text-sm">رقم السند</th>
                <th className="p-4 font-black text-slate-500 text-sm">الصندوق / البنك</th>
                <th className="p-4 font-black text-slate-500 text-sm">الحساب المقابل</th>
                <th className="p-4 font-black text-slate-500 text-sm">المبلغ</th>
                <th className="p-4 font-black text-slate-500 text-sm">البيان</th>
                <th className="p-4 font-black text-slate-500 text-sm text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredDocs.map((doc) => {
                const typeInfo = getDocTypeInfo(doc.type);
                return (
                  <motion.tr 
                    key={doc.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="hover:bg-slate-50/50 transition-colors group"
                  >
                    <td className="p-4">
                      <div className="font-bold text-slate-700">{doc.date}</div>
                    </td>
                    <td className="p-4">
                      <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl font-bold text-xs ${typeInfo.bg} ${typeInfo.color}`}>
                        <typeInfo.icon size={14} />
                        {typeInfo.label}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="font-mono font-black text-blue-600">{doc.docNum}</div>
                      {doc.ref && <div className="text-[10px] text-slate-400">مرجع: {doc.ref}</div>}
                    </td>
                    <td className="p-4">
                      <div className="font-bold text-slate-600">{getFundBankName(doc)}</div>
                    </td>
                    <td className="p-4">
                      <div className="font-bold text-slate-800">{getAccountNames(doc)}</div>
                    </td>
                    <td className="p-4">
                      <div className="font-black text-slate-900">
                        {doc.amount.toLocaleString()} 
                        <span className="text-[10px] text-slate-400 mr-1">{getCurrencyCode(doc.currencyId)}</span>
                      </div>
                      {doc.currencyId && getCurrencyCode(doc.currencyId) !== 'SAR' && (
                        <div className="text-[10px] text-slate-400">
                          {(doc.amount * (doc.exchangeRate || 1)).toLocaleString()} SAR
                        </div>
                      )}
                    </td>
                    <td className="p-4">
                      <div className="text-sm text-slate-500 max-w-[200px] truncate">{doc.description}</div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => onPrint(doc)}
                          className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                        >
                          <Printer size={18} />
                        </button>
                        {(user.role === 'admin' || user.canEditCashBank) && (
                          <button 
                            onClick={() => onEdit(doc)}
                            className="p-2 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-all"
                          >
                            <Edit2 size={18} />
                          </button>
                        )}
                        {(user.role === 'admin' || user.canDeleteCashBank) && (
                          <button 
                            onClick={() => onDelete(doc.id)}
                            className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                          >
                            <Trash2 size={18} />
                          </button>
                        )}
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
              {filteredDocs.length === 0 && (
                <tr>
                  <td colSpan={8} className="p-12 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="p-4 bg-slate-50 rounded-full">
                        <Search size={32} className="text-slate-300" />
                      </div>
                      <div className="text-slate-400 font-bold">لم يتم العثور على أي سندات</div>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CashBankHistory;
