import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Calendar, 
  FileText, 
  Printer, 
  Edit2, 
  Trash2, 
  ChevronLeft,
  ArrowUpRight,
  ArrowDownLeft,
  Database,
  Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DB, User, JournalEntry } from '../types';

interface JournalHistoryProps {
  db: DB;
  user: User;
  onEdit: (entry: JournalEntry) => void;
  onDelete: (id: string) => void;
  onPrint: (entry: JournalEntry) => void;
  setConfirmModal: (modal: { title: string; message: string; onConfirm: () => void } | null) => void;
}

export const JournalHistory: React.FC<JournalHistoryProps> = ({ 
  db, 
  user, 
  onEdit, 
  onDelete, 
  onPrint,
  setConfirmModal 
}) => {
  const [search, setSearch] = useState('');
  const [dateFilter, setDateFilter] = useState('');

  const filteredEntries = useMemo(() => {
    let result = db.journalEntries || [];
    
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(e => 
        e.ref.toLowerCase().includes(q) || 
        e.description.toLowerCase().includes(q) ||
        (e.items || []).some(item => {
          let accName = '';
          let accCode = '';
          
          if (item.accType === 'fund') {
            const fund = (db.funds || []).find(f => f.id === item.accId);
            accName = fund?.name || '';
            accCode = fund?.code || '';
          } else if (item.accType === 'bank') {
            const bank = (db.banks || []).find(b => b.id === item.accId);
            accName = bank?.name || '';
            accCode = bank?.code || '';
          } else if (item.accType === 'customer-supplier') {
            const cs = (db.customersSuppliers || []).find(c => c.id === item.accId);
            accName = cs?.name || '';
            accCode = cs?.code || '';
          } else {
            const acc = (db.accounts || []).find(a => a.id === item.accId);
            accName = acc?.name || '';
            accCode = acc?.code || '';
          }
          
          return accName.toLowerCase().includes(q) || accCode.toLowerCase().includes(q);
        })
      );
    }

    if (dateFilter) {
      result = result.filter(e => e.date === dateFilter);
    }

    return result.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [db.journalEntries, db.accounts, search, dateFilter]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">سجل قيود اليومية</h1>
          <p className="text-slate-500 text-sm">عرض وإدارة كافة القيود المالية المحاسبية</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="بحث في القيود..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pr-10 pl-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none w-64 transition-all"
            />
          </div>
          <div className="relative">
            <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="date" 
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="pr-10 pl-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="p-4 text-right text-[10px] font-bold text-slate-400 w-32">التاريخ</th>
                <th className="p-4 text-right text-[10px] font-bold text-slate-400 w-32">رقم القيد</th>
                <th className="p-4 text-right text-[10px] font-bold text-slate-400">البيان</th>
                <th className="p-4 text-center text-[10px] font-bold text-slate-400 w-32">المبلغ</th>
                <th className="p-4 text-center text-[10px] font-bold text-slate-400 w-32">الحالة</th>
                <th className="p-4 w-28"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              <AnimatePresence>
                {filteredEntries.map((entry) => {
                  const totalAmount = (entry.items || []).reduce((sum, i) => sum + (i.debit || 0), 0);
                  return (
                    <motion.tr 
                      key={entry.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="group hover:bg-slate-50/50 transition-colors"
                    >
                      <td className="p-4">
                        <div className="flex flex-col">
                          <span className="text-sm font-bold text-slate-700">{entry.date}</span>
                          <span className="text-[10px] text-slate-400">{new Date(entry.createdAt).toLocaleTimeString('ar-SA')}</span>
                        </div>
                      </td>
                      <td className="p-4">
                        <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-lg text-xs font-bold">
                          {entry.ref}
                        </span>
                      </td>
                      <td className="p-4">
                        <p className="text-sm text-slate-600 line-clamp-1">{entry.description || 'بدون بيان'}</p>
                      </td>
                      <td className="p-4 text-center">
                        <span className="text-sm font-black text-slate-900">
                          {totalAmount.toLocaleString()}
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <span className="px-2 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-bold">
                          مرحل
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => onPrint(entry)}
                            className="p-2 hover:bg-slate-100 text-slate-400 hover:text-blue-600 rounded-lg transition-all"
                            title="طباعة"
                          >
                            <Printer size={16} />
                          </button>
                          {(user.role === 'admin' || user.canEditJournal) && (
                            <button 
                              onClick={() => onEdit(entry)}
                              className="p-2 hover:bg-slate-100 text-slate-400 hover:text-blue-600 rounded-lg transition-all"
                              title="تعديل"
                            >
                              <Edit2 size={16} />
                            </button>
                          )}
                          {(user.role === 'admin' || user.canDeleteJournal) && (
                            <button 
                              onClick={() => {
                                setConfirmModal({
                                  title: 'تأكيد الحذف',
                                  message: `هل أنت متأكد من حذف القيد رقم ${entry.ref}؟ لا يمكن التراجع عن هذه العملية.`,
                                  onConfirm: () => onDelete(entry.id)
                                });
                              }}
                              className="p-2 hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-lg transition-all"
                              title="حذف"
                            >
                              <Trash2 size={16} />
                            </button>
                          )}
                        </div>
                      </td>
                    </motion.tr>
                  );
                })}
              </AnimatePresence>
              {filteredEntries.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-20 text-center text-slate-400">
                    <Database size={48} className="mx-auto mb-4 opacity-10" />
                    <p className="font-bold">لا يوجد قيود يومية لعرضها</p>
                    <p className="text-xs mt-1">ابدأ بإضافة قيود جديدة من القائمة الجانبية</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
