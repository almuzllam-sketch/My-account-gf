import React from 'react';
import { motion } from 'motion/react';
import { 
  FileText, 
  Shield, 
  Zap, 
  BarChart3, 
  ChevronRight, 
  ArrowRight,
  CheckCircle2,
  Globe,
  Layout,
  Database
} from 'lucide-react';

interface LandingPageProps {
  onLogin: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onLogin }) => {
  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans selection:bg-blue-100 selection:text-blue-900 overflow-x-hidden" dir="rtl">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-white/80 backdrop-blur-xl border-b border-slate-100 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-xl shadow-lg shadow-blue-200">
              <FileText className="text-white" size={24} />
            </div>
            <span className="text-xl font-black tracking-tight text-slate-900">المحاسب الذكي</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm font-bold text-slate-500 hover:text-blue-600 transition-colors">المميزات</a>
            <a href="#reports" className="text-sm font-bold text-slate-500 hover:text-blue-600 transition-colors">التقارير</a>
            <a href="#security" className="text-sm font-bold text-slate-500 hover:text-blue-600 transition-colors">الأمان</a>
          </div>

          <button 
            onClick={onLogin}
            className="bg-slate-900 text-white px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-black transition-all shadow-lg shadow-slate-200 active:scale-95"
          >
            دخول النظام
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-50 rounded-full blur-[120px] opacity-60" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-50 rounded-full blur-[120px] opacity-60" />
        </div>

        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="text-right"
            >
              <div className="inline-flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-full mb-6 border border-blue-100">
                <Zap size={14} className="text-blue-600" />
                <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">الجيل القادم من المحاسبة</span>
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-black text-slate-900 leading-[1.1] mb-8">
                أدر حساباتك <br />
                <span className="text-blue-600">بذكاء وسهولة</span>
              </h1>
              
              <p className="text-lg text-slate-500 mb-10 leading-relaxed max-w-xl">
                نظام محاسبي متكامل لإدارة السندات، المخازن، والتقارير المالية بدقة عالية وتجربة مستخدم لا مثيل لها. مصمم ليلبي احتياجات الشركات العصرية.
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-4">
                <button 
                  onClick={onLogin}
                  className="w-full sm:w-auto bg-blue-600 text-white px-10 py-5 rounded-2xl font-black text-lg hover:bg-blue-700 transition-all shadow-2xl shadow-blue-200 flex items-center justify-center gap-3 active:scale-95 group"
                >
                  ابدأ الآن مجاناً
                  <ArrowRight size={20} className="group-hover:translate-x-[-4px] transition-transform" />
                </button>
                <button className="w-full sm:w-auto bg-white text-slate-600 px-10 py-5 rounded-2xl font-bold text-lg border border-slate-100 hover:bg-slate-50 transition-all flex items-center justify-center gap-2">
                  مشاهدة العرض
                </button>
              </div>

              <div className="mt-12 flex items-center gap-6">
                <div className="flex -space-x-3 space-x-reverse">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-slate-200" />
                  ))}
                </div>
                <p className="text-xs font-bold text-slate-400">انضم إلى أكثر من <span className="text-slate-900">500+</span> شركة تثق بنا</p>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="relative"
            >
              <div className="relative bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 p-4 overflow-hidden">
                <img 
                  src="https://picsum.photos/seed/accounting/1200/800" 
                  alt="Dashboard Preview" 
                  className="rounded-2xl w-full h-auto"
                  referrerPolicy="no-referrer"
                />
                
                {/* Floating Elements */}
                <motion.div 
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 4, repeat: Infinity }}
                  className="absolute top-10 right-[-20px] bg-white p-4 rounded-2xl shadow-xl border border-slate-50 flex items-center gap-4"
                >
                  <div className="bg-emerald-100 p-2 rounded-xl">
                    <BarChart3 className="text-emerald-600" size={20} />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-400">إجمالي المبيعات</p>
                    <p className="text-sm font-black text-slate-800">125,400 ر.ي</p>
                  </div>
                </motion.div>

                <motion.div 
                  animate={{ y: [0, 10, 0] }}
                  transition={{ duration: 5, repeat: Infinity }}
                  className="absolute bottom-10 left-[-20px] bg-white p-4 rounded-2xl shadow-xl border border-slate-50 flex items-center gap-4"
                >
                  <div className="bg-blue-100 p-2 rounded-xl">
                    <Shield className="text-blue-600" size={20} />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-400">حماية البيانات</p>
                    <p className="text-sm font-black text-slate-800">مشفرة بالكامل</p>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-20">
            <h2 className="text-3xl lg:text-4xl font-black text-slate-900 mb-6">كل ما تحتاجه لإدارة أعمالك</h2>
            <p className="text-slate-500 font-medium">نقدم لك مجموعة متكاملة من الأدوات المحاسبية المصممة بدقة لتناسب تطلعاتك</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Layout className="text-blue-600" />,
                title: "واجهة عصرية",
                desc: "تصميم بديهي وسهل الاستخدام يقلل من وقت التدريب ويزيد من الإنتاجية."
              },
              {
                icon: <Database className="text-indigo-600" />,
                title: "إدارة المخازن",
                desc: "تتبع دقيق لحركة الأصناف، الجرد الدوري، وتنبيهات النواقص."
              },
              {
                icon: <BarChart3 className="text-emerald-600" />,
                title: "تقارير HTML احترافية",
                desc: "إمكانية تصدير كافة التقارير والسجلات بصيغة HTML و CSV لمشاركتها أو طباعتها بسهولة."
              },
              {
                icon: <Shield className="text-rose-600" />,
                title: "أمان عالي",
                desc: "تشفير كامل للبيانات مع نظام صلاحيات دقيق لكل مستخدم."
              },
              {
                icon: <Globe className="text-amber-600" />,
                title: "وصول من أي مكان",
                desc: "نظام سحابي يتيح لك متابعة أعمالك من أي جهاز وفي أي وقت."
              },
              {
                icon: <Zap className="text-purple-600" />,
                title: "سرعة في الأداء",
                desc: "تقنيات حديثة تضمن لك سرعة فائقة في معالجة البيانات الضخمة."
              }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -10 }}
                className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-blue-50 transition-all"
              >
                <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center mb-6">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-black text-slate-900 mb-4">{feature.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 bg-blue-600 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:20px_20px]" />
        </div>
        
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 text-center">
            {[
              { val: "500+", label: "عميل سعيد" },
              { val: "1M+", label: "سند محاسبي" },
              { val: "99.9%", label: "وقت التشغيل" },
              { val: "24/7", label: "دعم فني" }
            ].map((stat, i) => (
              <div key={i} className="space-y-2">
                <p className="text-4xl lg:text-5xl font-black text-white font-mono tracking-tighter">{stat.val}</p>
                <p className="text-blue-100 text-xs font-bold uppercase tracking-widest">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="max-w-5xl mx-auto px-6">
          <div className="bg-slate-900 rounded-[3rem] p-12 lg:p-20 text-center relative overflow-hidden shadow-2xl shadow-slate-300">
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/20 rounded-full blur-[100px]" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-600/20 rounded-full blur-[100px]" />
            
            <h2 className="text-4xl lg:text-5xl font-black text-white mb-8 relative z-10">هل أنت مستعد لتطوير أعمالك؟</h2>
            <p className="text-slate-400 text-lg mb-12 max-w-2xl mx-auto relative z-10">
              انضم إلى مئات الشركات التي اختارت المحاسب الذكي لتنظيم حساباتها وزيادة أرباحها.
            </p>
            
            <button 
              onClick={onLogin}
              className="bg-white text-slate-900 px-12 py-5 rounded-2xl font-black text-xl hover:bg-blue-50 transition-all shadow-xl active:scale-95 relative z-10"
            >
              ابدأ تجربتك المجانية الآن
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-100 pt-20 pb-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-4 gap-12 mb-20">
            <div className="col-span-2">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-blue-600 p-2 rounded-xl">
                  <FileText className="text-white" size={24} />
                </div>
                <span className="text-xl font-black text-slate-900">المحاسب الذكي</span>
              </div>
              <p className="text-slate-500 max-w-sm leading-relaxed">
                نحن نسعى لتقديم أفضل الحلول التقنية للمحاسبة والإدارة المالية في المنطقة، مع التركيز على سهولة الاستخدام ودقة البيانات.
              </p>
            </div>
            
            <div>
              <h4 className="font-black text-slate-900 mb-6 uppercase text-xs tracking-widest">روابط سريعة</h4>
              <ul className="space-y-4">
                <li><a href="#" className="text-sm text-slate-500 hover:text-blue-600 font-bold">الرئيسية</a></li>
                <li><a href="#" className="text-sm text-slate-500 hover:text-blue-600 font-bold">المميزات</a></li>
                <li><a href="#" className="text-sm text-slate-500 hover:text-blue-600 font-bold">الأسعار</a></li>
                <li><a href="#" className="text-sm text-slate-500 hover:text-blue-600 font-bold">تواصل معنا</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-black text-slate-900 mb-6 uppercase text-xs tracking-widest">تواصل معنا</h4>
              <ul className="space-y-4">
                <li className="text-sm text-slate-500 font-bold">صنعاء، اليمن</li>
                <li className="text-sm text-slate-500 font-bold">support@smartacc.com</li>
                <li className="text-sm text-slate-500 font-bold">+967 777 000 000</li>
              </ul>
            </div>
          </div>
          
          <div className="pt-10 border-t border-slate-50 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex flex-col gap-1">
              <p className="text-xs font-bold text-slate-400">جميع الحقوق محفوظة © {new Date().getFullYear()} المحاسب الذكي</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest">تطوير ودعم فني:</span>
                <span className="text-[10px] font-bold text-slate-500">عبدالمجيد المزلم | 775600578 | Almuzllam@gmail.com</span>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <a href="#" className="text-xs font-bold text-slate-400 hover:text-blue-600">سياسة الخصوصية</a>
              <a href="#" className="text-xs font-bold text-slate-400 hover:text-blue-600">شروط الاستخدام</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
