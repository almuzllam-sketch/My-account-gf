import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Building, Lock, ArrowRight, Plus, Search, Building2, ShieldCheck, ChevronRight, Trash2 } from 'lucide-react';
import { useDatabase } from '../contexts/DatabaseContext';

export const CompanySelector: React.FC = () => {
  const { allCompanies, verifyCompanyAccess, user, logout, isSuperAdmin, setConfirmModal, showNotification, deleteCompany } = useDatabase();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [password, setPassword] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  const handleDeleteCompany = (companyId: string, companyName: string) => {
    setConfirmModal({
      title: "حذف الشركة",
      message: `هل أنت متأكد من حذف شركة "${companyName}"؟ لا يمكن التراجع عن هذه العملية وسيتم حذف كافة إعدادات الشركة.`,
      onConfirm: async () => {
        await deleteCompany(companyId);
        setConfirmModal(null);
      }
    });
  };

  const filteredCompanies = allCompanies.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    c.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSelect = async (companyId: string, hasPassword?: boolean) => {
    if (!hasPassword) {
      setIsVerifying(true);
      await verifyCompanyAccess(companyId);
      setIsVerifying(false);
    } else {
      setSelectedId(companyId);
    }
  };

  const handleVerify = async () => {
    if (!selectedId) return;
    setIsVerifying(true);
    const success = await verifyCompanyAccess(selectedId, password);
    setIsVerifying(false);
    if (!success) setPassword('');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 sm:p-6" dir="rtl">
      <div className="max-w-4xl w-full grid lg:grid-cols-2 gap-8 items-center">
        {/* Left Side: Branding & Info */}
        <div className="hidden lg:block space-y-8">
          <div className="flex items-center gap-4">
            <div className="bg-blue-600 p-3 rounded-2xl shadow-xl shadow-blue-100">
              <Building2 className="text-white" size={32} />
            </div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">نظام اختيار الشركات</h1>
          </div>
          
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-start gap-4">
              <div className="bg-blue-50 p-2 rounded-xl">
                <ShieldCheck className="text-blue-600" size={24} />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 mb-1">وصول آمن</h3>
                <p className="text-slate-500 text-sm leading-relaxed">تتم حماية بيانات كل شركة بشكل منفصل لضمان أعلى مستويات الخصوصية والأمان.</p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-start gap-4">
              <div className="bg-emerald-50 p-2 rounded-xl">
                <Building className="text-emerald-600" size={24} />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 mb-1">إدارة متعددة</h3>
                <p className="text-slate-500 text-sm leading-relaxed">يمكنك التنقل بين الشركات المختلفة التي تديرها بسهولة وكفاءة من مكان واحد.</p>
              </div>
            </div>
          </div>

          <div className="pt-8 flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-slate-200" />
            <div>
              <p className="text-sm font-bold text-slate-900">{user?.name}</p>
              <p className="text-xs text-slate-500">{user?.email}</p>
            </div>
            <button 
              onClick={logout}
              className="mr-auto text-xs font-black text-slate-400 hover:text-red-500 transition-colors uppercase tracking-widest"
            >
              تسجيل الخروج
            </button>
          </div>

          <div className="pt-10 border-t border-slate-100 mt-10">
            <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1">تطوير ودعم فني</p>
            <p className="text-sm font-bold text-slate-500">عبدالمجيد المزلم | 775600578</p>
            <p className="text-xs text-slate-400 font-mono">Almuzllam@gmail.com</p>
          </div>
        </div>

        {/* Right Side: Selection List / Password Input */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 p-8 lg:p-10"
        >
          <AnimatePresence mode="wait">
            {!selectedId ? (
              <motion.div
                key="list"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-black text-slate-900 mb-2">اختر الشركة</h2>
                  <p className="text-slate-400 font-medium">الرجاء اختيار الشركة التي ترغب في الدخول إليها</p>
                </div>

                <div className="relative">
                  <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input 
                    type="text" 
                    placeholder="ابحث عن شركة..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pr-12 pl-4 py-4 rounded-2xl border border-slate-100 bg-slate-50 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold"
                  />
                </div>

                <div className="space-y-3 max-h-[400px] overflow-y-auto no-scrollbar pr-1">
                  {filteredCompanies.map((company) => (
                    <button
                      key={company.id}
                      onClick={() => handleSelect(company.id, company.hasPassword)}
                      className="w-full flex items-center justify-between p-4 rounded-2xl border border-slate-50 bg-white hover:bg-blue-50 hover:border-blue-100 transition-all group"
                    >
                      <div className="flex items-center gap-4 text-right">
                        <div className="bg-slate-100 p-2 rounded-xl group-hover:bg-white transition-colors">
                          <Building size={20} className="text-slate-400 group-hover:text-blue-600" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-800 tracking-tight">{company.name}</p>
                          <p className="text-[10px] text-slate-400 font-mono">{company.id}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {isSuperAdmin && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteCompany(company.id, company.name);
                            }}
                            className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                            title="حذف الشركة"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                        {company.hasPassword && <Lock size={14} className="text-slate-300" />}
                        <ChevronRight size={18} className="text-slate-200 group-hover:text-blue-400 -rotate-180" />
                      </div>
                    </button>
                  ))}
                  {filteredCompanies.length === 0 && (
                    <div className="text-center py-12 text-slate-400">
                      <Plus size={48} className="mx-auto mb-4 opacity-10" />
                      <p className="font-bold">لا توجد شركات مطابقة</p>
                    </div>
                  )}
                </div>

                <button 
                  onClick={() => handleSelect(`comp_${Math.random().toString(36).substring(2, 9)}`, false)}
                  className="w-full py-4 rounded-2xl border-2 border-dashed border-slate-200 text-slate-400 font-black text-sm hover:border-blue-200 hover:text-blue-500 hover:bg-blue-50/30 transition-all flex items-center justify-center gap-3"
                >
                  <Plus size={18} />
                  إضافة شركة جديدة خارج النظام
                </button>
              </motion.div>
            ) : (
              <motion.div
                key="password"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="text-center">
                  <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Lock className="text-blue-600" size={32} />
                  </div>
                  <h2 className="text-2xl font-black text-slate-900 mb-2">تأكيد الوصول</h2>
                  <p className="text-slate-400 font-medium leading-relaxed">
                    هذه الشركة محمية بكلمة مرور. <br />
                    ادخل كلمة المرور للمتابعة إلى <span className="text-blue-600 font-bold">"{allCompanies.find(c => c.id === selectedId)?.name}"</span>
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest mr-2">كلمة المرور</label>
                    <input 
                      type="password" 
                      autoFocus
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
                      className="w-full px-6 py-4 rounded-2xl border border-slate-100 bg-slate-50 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold text-center tracking-widest"
                    />
                  </div>

                  <button 
                    onClick={handleVerify}
                    disabled={isVerifying || !password}
                    className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white py-5 rounded-2xl font-black text-lg shadow-xl shadow-blue-100 transition-all active:scale-95 flex items-center justify-center gap-3"
                  >
                    {isVerifying ? 'جاري التحقق...' : 'دخول النظام'}
                    <ArrowRight size={20} className="-rotate-180" />
                  </button>

                  <button 
                    onClick={() => {
                      setSelectedId(null);
                      setPassword('');
                    }}
                    className="w-full text-sm font-bold text-slate-400 hover:text-slate-600 transition-colors"
                  >
                    العودة لقائمة الشركات
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
};
