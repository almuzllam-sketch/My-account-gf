import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  Filter, 
  Printer, 
  Trash2, 
  Eye, 
  Download,
  FileText,
  Globe,
  ChevronRight,
  ChevronLeft,
  X,
  History as HistoryIcon,
  Calendar,
  Layers,
  MoreHorizontal
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DB, Doc, User } from '../types';

interface HistoryProps {
  db: DB;
  user: User;
  type: 'issue' | 'purchase' | 'sale' | 'all';
  onDelete: (id: string) => void;
  onPrint: (doc: Doc) => void;
  onEdit: (doc: Doc) => void;
  allCompanies?: { id: string; name: string }[];
  setConfirmModal: (modal: { title: string; message: string; onConfirm: () => void } | null) => void;
}

export const History: React.FC<HistoryProps> = ({ db, user, type, onDelete, onPrint, onEdit, allCompanies, setConfirmModal }) => {
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [dateFilter, setDateFilter] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 50);
    return () => clearTimeout(timer);
  }, [search]);

  const filteredDocs = useMemo(() => {
    const query = debouncedSearch.toLowerCase();
    return (db.docs || []).filter(doc => {
      // Filter by type
      if (type !== 'all' && doc.type !== type) return false;

      // Multi-user view restriction: users only see their own docs, admins see all
      if (user.role !== 'admin' && doc.createdBy !== user.id) return false;

      const acc = (db.accounts || []).find(a => a.id === doc.accId);
      const cc = (db.centers || []).find(c => c.id === doc.ccId);
      const matchesSearch = 
        !query ||
        doc.ref.toLowerCase().includes(query) ||
        doc.docNum.toLowerCase().includes(query) ||
        doc.description.toLowerCase().includes(query) ||
        acc?.name?.toLowerCase().includes(query) ||
        acc?.code?.toLowerCase().includes(query) ||
        cc?.name?.toLowerCase().includes(query) ||
        cc?.code?.toLowerCase().includes(query);
      const matchesDate = !dateFilter || doc.date === dateFilter;
      return matchesSearch && matchesDate;
    }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [db, debouncedSearch, dateFilter, type, user]);

  // Pagination
  const [page, setPage] = useState(1);
  const itemsPerPage = 10;
  const totalPages = Math.ceil(filteredDocs.length / itemsPerPage);
  const paginatedDocs = filteredDocs.slice((page - 1) * itemsPerPage, page * itemsPerPage);

  const downloadCSV = () => {
    const companyName = db.company?.name || 'شركة المثال المحدودة';
    const reportTitle = type === 'purchase' ? 'سجل المشتريات' : type === 'sale' ? 'سجل المبيعات' : type === 'issue' ? 'سجل السندات' : 'الحركة المخزنية';
    
    const headers = ['التاريخ', 'رقم السند', 'المرجع', 'الحساب', 'المركز', 'البيان', 'عدد الأصناف'];
    const rows = (filteredDocs || []).map(doc => {
      const acc = (db.accounts || []).find(a => a.id === doc.accId)?.name || '';
      const cc = (db.centers || []).find(c => c.id === doc.ccId)?.name || '';
      return [
        doc.date,
        doc.docNum,
        doc.ref,
        acc,
        cc,
        doc.description,
        (doc.items || []).length
      ];
    });

    const csvContent = [
      `"${companyName}"`,
      `"${reportTitle}"`,
      `"تاريخ التصدير: ${new Date().toLocaleDateString('ar-SA')}"`,
      '',
      headers.join(','),
      ...rows.map(r => r.map(c => `"${c}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const fileName = type === 'purchase' ? 'purchases' : type === 'sale' ? 'sales' : 'issues';
    link.setAttribute('download', `${fileName}_history.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadHTML = () => {
    const companyName = db.company?.name || 'شركة المثال المحدودة';
    const reportTitle = type === 'purchase' ? 'سجل المشتريات' : type === 'sale' ? 'سجل المبيعات' : type === 'issue' ? 'سجل السندات' : 'الحركة المخزنية';
    
    const rowsHtml = (filteredDocs || []).map(doc => {
      const acc = (db.accounts || []).find(a => a.id === doc.accId)?.name || '';
      const cc = (db.centers || []).find(c => c.id === doc.ccId)?.name || '';
      return `
        <tr>
          <td>${doc.date}</td>
          <td>${doc.docNum}</td>
          <td>${doc.ref}</td>
          <td>${acc}</td>
          <td>${cc}</td>
          <td>${doc.description || '---'}</td>
          <td>${(doc.items || []).length}</td>
          <td style="text-align:left; font-weight:bold;">${((doc.items || []).reduce((sum, item) => sum + (item.total || 0), 0)).toLocaleString('ar-SA')}</td>
        </tr>
      `;
    }).join('');

    const htmlContent = `
      <html dir="rtl">
        <head>
          <meta charset="UTF-8">
          <title>${reportTitle}</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; background: #f8fafc; color: #1e293b; }
            .header { text-align: center; margin-bottom: 40px; }
            .header h1 { margin: 0; color: #0f172a; font-size: 28px; }
            .header p { margin: 5px 0; color: #64748b; font-size: 14px; }
            table { width: 100%; border-collapse: collapse; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); }
            th { background: #f1f5f9; padding: 15px; text-align: right; font-size: 12px; color: #475569; text-transform: uppercase; border-bottom: 2px solid #e2e8f0; }
            td { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; }
            tr:last-child td { border-bottom: none; }
            tr:hover { background: #f8fafc; }
            .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #94a3b8; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>${companyName}</h1>
            <h2>${reportTitle}</h2>
            <p>تاريخ التقرير: ${new Date().toLocaleDateString('ar-SA')}</p>
          </div>
          <table>
            <thead>
              <tr>
                <th>التاريخ</th>
                <th>رقم السند</th>
                <th>المرجع</th>
                <th>الحساب</th>
                <th>المركز</th>
                <th>البيان</th>
                <th>الأصناف</th>
                <th>الإجمالي</th>
              </tr>
            </thead>
            <tbody>${rowsHtml}</tbody>
          </table>
          <div class="footer">
            <p>تم التصدير بواسطة نظام المحاسب الذكي © ${new Date().getFullYear()}</p>
          </div>
        </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const fileName = type === 'purchase' ? 'purchases' : type === 'sale' ? 'sales' : 'issues';
    link.setAttribute('download', `${fileName}_report.html`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadSample = () => {
    const headers = ['التاريخ', 'رقم السند', 'المرجع', 'الحساب', 'المركز', 'البيان', 'عدد الأصناف'];
    const sampleRows = [
      ['2026-04-09', '1001', 'REF-001', 'عميل افتراضي', 'مركز افتراضي', 'بيان تجريبي', '5'],
      ['2026-04-10', '1002', 'REF-002', 'مورد افتراضي', 'مركز افتراضي', 'بيان تجريبي آخر', '3']
    ];

    const csvContent = [
      headers.join(','),
      ...sampleRows.map(r => r.map(c => `"${c}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `sample_history.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Premium Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-900 flex items-center justify-center text-white shadow-xl shadow-slate-200">
            <HistoryIcon size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">
              {type === 'purchase' ? 'سجل المشتريات' : type === 'sale' ? 'سجل المبيعات' : type === 'issue' ? 'سجل السندات' : 'الحركة المخزنية'}
            </h1>
            <p className="text-slate-500 font-medium mt-0.5">
              {type === 'purchase' ? 'إدارة ومراجعة كافة فواتير المشتريات المسجلة' : type === 'sale' ? 'إدارة ومراجعة كافة فواتير المبيعات المسجلة' : type === 'issue' ? 'إدارة ومراجعة كافة سندات الصرف المسجلة' : 'مراجعة كافة حركات المخزون (صرف ومشتريات ومبيعات)'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={downloadCSV}
            className="flex items-center gap-2 px-6 py-3 bg-white text-slate-700 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-50 transition-all border border-slate-200 shadow-sm active:scale-95"
          >
            <Download size={18} />
            CSV
          </button>
          <button 
            onClick={downloadHTML}
            className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-700 transition-all shadow-xl shadow-blue-200 active:scale-95"
          >
            <Globe size={18} />
            HTML Report
          </button>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col lg:flex-row gap-6 items-center">
        <div className="w-full lg:flex-1 relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder="بحث برقم المرجع، اسم الحساب، أو البيان..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-12 pl-12 py-4 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-blue-500 outline-none transition-all font-bold text-slate-700 placeholder:text-slate-400"
          />
          {search && (
            <button 
              onClick={() => setSearch('')}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X size={20} />
            </button>
          )}
        </div>
        
        <div className="flex flex-wrap items-center gap-4 w-full lg:w-auto">
          <div className="relative flex-1 lg:flex-none">
            <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="date" 
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="w-full lg:w-48 pr-12 pl-4 py-4 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-blue-500 outline-none text-sm font-bold text-slate-700"
            />
          </div>
          
          <button 
            onClick={downloadSample}
            className="p-4 bg-slate-50 text-slate-400 rounded-2xl hover:bg-slate-100 hover:text-slate-600 transition-all"
            title="تنزيل نموذج للبيانات"
          >
            <Layers size={20} />
          </button>
          
          {(search || dateFilter) && (
            <button 
              onClick={() => { setSearch(''); setDateFilter(''); }}
              className="px-4 py-2 text-red-500 text-xs font-black uppercase tracking-widest hover:bg-red-50 rounded-xl transition-all"
            >
              تصفية الكل
            </button>
          )}
        </div>
      </div>

      {/* Table Container */}
      <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse min-w-[1000px]">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="p-6 text-right text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">التاريخ</th>
                {allCompanies && allCompanies.length > 0 && (
                  <th className="p-6 text-right text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">الشركة</th>
                )}
                <th className="p-6 text-right text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">النوع</th>
                <th className="p-6 text-right text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">رقم السند</th>
                <th className="p-6 text-right text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">المرجع</th>
                <th className="p-6 text-right text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">الحساب</th>
                <th className="p-6 text-right text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">البيان</th>
                <th className="p-6 text-center text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">الأصناف</th>
                <th className="p-6 text-left text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">الإجمالي</th>
                <th className="p-6 text-center text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              <AnimatePresence mode="popLayout">
                {(paginatedDocs || []).map((doc) => {
                  const acc = (db.accounts || []).find(a => a.id === doc.accId);
                  const cc = (db.centers || []).find(c => c.id === doc.ccId);
                  const isPurchase = doc.type === 'purchase';
                  const isSale = doc.type === 'sale';
                  
                  return (
                    <motion.tr 
                      key={doc.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="hover:bg-slate-50/50 transition-all group"
                    >
                      <td className="p-6 text-sm text-slate-600 font-bold">
                        {new Date(doc.date).toLocaleDateString('ar-SA')}
                      </td>
                      {allCompanies && allCompanies.length > 0 && (
                        <td className="p-6">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                            {(allCompanies || []).find(c => c.id === doc.companyId)?.name || '---'}
                          </span>
                        </td>
                      )}
                      <td className="p-6">
                        <span className={`text-[9px] px-2 py-1 rounded-lg font-black uppercase tracking-widest ${
                          isPurchase ? 'bg-purple-100 text-purple-700' : 
                          isSale ? 'bg-emerald-100 text-emerald-700' :
                          'bg-blue-100 text-blue-700'
                        }`}>
                          {isPurchase ? 'مشتريات' : isSale ? 'مبيعات' : 'صرف'}
                        </span>
                      </td>
                      <td className="p-6">
                        <span className="font-mono text-xs font-black bg-slate-100 text-slate-700 border border-slate-200 px-3 py-1.5 rounded-xl">
                          {doc.docNum}
                        </span>
                      </td>
                      <td className="p-6">
                        <span className="font-mono text-xs font-black bg-blue-50 text-blue-700 border border-blue-100 px-3 py-1.5 rounded-xl">
                          {doc.ref}
                        </span>
                      </td>
                      <td className="p-6">
                        <div className="flex flex-col">
                          <span className="text-sm font-black text-slate-800 group-hover:text-blue-600 transition-colors">{acc?.name || '---'}</span>
                          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">{cc?.name || '---'}</span>
                        </div>
                      </td>
                      <td className="p-6 text-xs text-slate-500 max-w-[150px] truncate font-medium">
                        {doc.description || '---'}
                      </td>
                      <td className="p-6 text-center">
                        <div className="flex flex-col items-center gap-1">
                          <span className="text-xs font-black bg-blue-50 text-blue-600 px-3 py-1 rounded-full">
                            {(doc.items || []).length}
                          </span>
                          {doc.printCount && doc.printCount > 0 && (
                            <span className="text-[9px] text-slate-400 font-black flex items-center gap-1 uppercase tracking-widest">
                              <Printer size={10} />
                              {doc.printCount} PRINTS
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="p-6 text-left">
                        <span className="text-sm font-black text-slate-900 font-mono">
                          {((doc.items || []).reduce((sum, item) => sum + (item.total || 0), 0)).toLocaleString('ar-SA', { minimumFractionDigits: 2 })}
                        </span>
                      </td>
                      <td className="p-6">
                        <div className="flex items-center justify-center gap-2">
                          {(user.role === 'admin' || (doc.type === 'purchase' ? user.canEditPurchase : doc.type === 'sale' ? user.canEditSale : user.canEditIssue)) && (
                            <button 
                              onClick={() => onEdit(doc)}
                              className="w-10 h-10 flex items-center justify-center bg-slate-50 text-slate-400 hover:bg-blue-600 hover:text-white rounded-xl transition-all shadow-sm"
                              title="عرض / تعديل"
                            >
                              <Eye size={18} />
                            </button>
                          )}
                          <button 
                            onClick={() => onPrint(doc)}
                            className="w-10 h-10 flex items-center justify-center bg-slate-50 text-slate-400 hover:bg-emerald-600 hover:text-white rounded-xl transition-all shadow-sm"
                            title="طباعة"
                          >
                            <Printer size={18} />
                          </button>
                          {(user.role === 'admin' || (doc.type === 'purchase' ? user.canDeletePurchase : doc.type === 'sale' ? user.canDeleteSale : user.canDeleteIssue)) && (
                            <button 
                              onClick={() => onDelete(doc.id)}
                              className="w-10 h-10 flex items-center justify-center bg-slate-50 text-slate-400 hover:bg-red-600 hover:text-white rounded-xl transition-all shadow-sm"
                              title="حذف"
                            >
                              <Trash2 size={18} />
                            </button>
                          )}
                        </div>
                      </td>
                    </motion.tr>
                  );
                })}
              </AnimatePresence>
              {filteredDocs.length === 0 && (
                <tr>
                  <td colSpan={10} className="p-24 text-center text-slate-300">
                    <FileText size={64} className="mx-auto mb-4 opacity-10" />
                    <p className="text-lg font-black">لا توجد نتائج تطابق بحثك</p>
                    <p className="text-sm font-bold mt-1">جرب تغيير معايير البحث أو تصفية التاريخ</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="p-8 bg-slate-50/30 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-6">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
              عرض <span className="text-slate-900">{(page - 1) * itemsPerPage + 1}</span> إلى <span className="text-slate-900">{Math.min(page * itemsPerPage, filteredDocs.length)}</span> من أصل <span className="text-slate-900">{filteredDocs.length}</span> سند
            </span>
            <div className="flex items-center gap-2">
              <button 
                disabled={page === 1}
                onClick={() => setPage(p => p - 1)}
                className="w-10 h-10 flex items-center justify-center bg-white border border-slate-200 text-slate-400 disabled:opacity-30 rounded-xl transition-all hover:bg-slate-50 active:scale-90"
              >
                <ChevronRight size={20} />
              </button>
              <div className="flex items-center gap-2">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => {
                  if (p === 1 || p === totalPages || (p >= page - 1 && p <= page + 1)) {
                    return (
                      <button
                        key={p}
                        onClick={() => setPage(p)}
                        className={`w-10 h-10 rounded-xl text-xs font-black transition-all border ${
                          page === p 
                            ? 'bg-slate-900 text-white border-slate-900 shadow-xl shadow-slate-200' 
                            : 'bg-white text-slate-400 border-slate-200 hover:border-slate-400 hover:text-slate-600'
                        }`}
                      >
                        {p}
                      </button>
                    );
                  }
                  if (p === 2 || p === totalPages - 1) {
                    return <span key={p} className="px-1 text-slate-300 font-black">...</span>;
                  }
                  return null;
                })}
              </div>
              <button 
                disabled={page === totalPages}
                onClick={() => setPage(p => p + 1)}
                className="w-10 h-10 flex items-center justify-center bg-white border border-slate-200 text-slate-400 disabled:opacity-30 rounded-xl transition-all hover:bg-slate-50 active:scale-90"
              >
                <ChevronLeft size={20} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
