import React from 'react';
import { 
  BarChart3, 
  History, 
  ShoppingBag, 
  FileText,
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import { motion } from 'motion/react';
import { ViewType, User } from '../types';

interface ReportScreenProps {
  user: User;
  onSelect: (view: ViewType) => void;
}

export const ReportScreen: React.FC<ReportScreenProps> = ({ user, onSelect }) => {
  const reports = [
    { id: 'inventory-movement', label: 'الحركة المخزنية', icon: History, color: 'bg-blue-500', description: 'مراجعة كافة حركات المخزون (صرف ومشتريات ومبيعات)' },
    { id: 'inventory-reports', label: 'التقارير المخزنية', icon: ShoppingBag, color: 'bg-emerald-500', description: 'عرض إجمالي الكميات لكل صنف' },
    { id: 'sale-history', label: 'سجل المبيعات', icon: TrendingUp, color: 'bg-purple-500', description: 'مراجعة كافة فواتير المبيعات المسجلة' },
    { id: 'account-statement', label: 'كشف حساب تفصيلي', icon: BarChart3, color: 'bg-amber-500', description: 'عرض كشف حساب تفصيلي للعملاء والموردين' },
  ];

  if (user.role !== 'admin' && !user.canViewReports) {
    return (
      <div className="p-20 text-center text-slate-400">
        <BarChart3 size={48} className="mx-auto mb-4 opacity-10" />
        <p className="font-bold text-xl">ليس لديك صلاحية لعرض التقارير</p>
      </div>
    );
  }

  return (
    <div className="space-y-12 p-6">
      <div className="flex items-center gap-6">
        <div className="w-16 h-16 rounded-3xl bg-emerald-600 flex items-center justify-center text-white shadow-2xl shadow-emerald-200">
          <BarChart3 size={32} />
        </div>
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">التقارير والتحليلات</h1>
          <p className="text-slate-500 font-medium mt-1">اختر التقرير الذي ترغب في استعراضه وتحليله</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {reports.map((report) => (
          <motion.button
            key={report.id}
            whileHover={{ y: -8, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelect(report.id as ViewType)}
            className="group relative bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:border-emerald-200 transition-all text-right flex flex-col items-start gap-6 overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-slate-50 rounded-full -mr-16 -mt-16 group-hover:bg-emerald-50 transition-colors" />
            
            <div className={`${report.color} p-5 rounded-[1.5rem] text-white shadow-xl group-hover:scale-110 transition-transform relative z-10`}>
              <report.icon size={32} />
            </div>
            <div className="relative z-10">
              <h3 className="text-2xl font-black text-slate-900 mb-3 tracking-tight">{report.label}</h3>
              <p className="text-slate-500 leading-relaxed font-medium">{report.description}</p>
            </div>
            <div className="mt-4 flex items-center gap-2 text-emerald-600 font-black text-xs uppercase tracking-widest relative z-10">
              <span>عرض التقرير</span>
              <ArrowRight size={18} className="group-hover:translate-x-[-4px] transition-transform" />
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
};
