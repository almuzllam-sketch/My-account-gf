import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Save, 
  DollarSign, 
  TrendingUp, 
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { uid } from '../lib/utils';
import { DB, Currency, User } from '../types';

interface CurrencyManagementProps {
  db: DB;
  user: User;
  onUpdateDB: (newDb: DB, collectionName?: string, docId?: string, data?: any, isDelete?: boolean) => void;
  showNotification: (msg: string, type?: 'success' | 'error' | 'warning') => void;
  setConfirmModal: (modal: { title: string; message: string; onConfirm: () => void } | null) => void;
}

export const CurrencyManagement: React.FC<CurrencyManagementProps> = ({ 
  db, 
  user, 
  onUpdateDB, 
  showNotification,
  setConfirmModal
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingCurrency, setEditingCurrency] = useState<Currency | null>(null);
  const [newCurrency, setNewCurrency] = useState<Partial<Currency>>({
    code: '',
    name: '',
    symbol: '',
    exchangeRate: 1,
    minRate: 0,
    maxRate: 0,
    isDefault: false
  });

  const currencies = db.currencies || [];

  const handleSave = () => {
    if (!newCurrency.code || !newCurrency.name || !newCurrency.exchangeRate) {
      showNotification('يرجى إكمال جميع الحقول المطلوبة', 'warning');
      return;
    }

    const currency: Currency = {
      id: editingCurrency?.id || uid(),
      companyId: user.companyId,
      code: newCurrency.code!,
      name: newCurrency.name!,
      symbol: newCurrency.symbol || '',
      exchangeRate: newCurrency.isDefault ? 1 : Number(newCurrency.exchangeRate),
      minRate: newCurrency.isDefault ? undefined : (newCurrency.minRate ? Number(newCurrency.minRate) : undefined),
      maxRate: newCurrency.isDefault ? undefined : (newCurrency.maxRate ? Number(newCurrency.maxRate) : undefined),
      isDefault: newCurrency.isDefault || false
    };

    // If this is default, unset others
    let updatedCurrencies = [...currencies];
    if (currency.isDefault) {
      updatedCurrencies = updatedCurrencies.map(c => ({ ...c, isDefault: false }));
    }

    const index = updatedCurrencies.findIndex(c => c.id === currency.id);
    if (index >= 0) {
      updatedCurrencies[index] = currency;
    } else {
      updatedCurrencies.push(currency);
    }

    onUpdateDB({ ...db, currencies: updatedCurrencies }, 'currencies', currency.id, currency);
    showNotification('تم حفظ العملة بنجاح');
    setIsAdding(false);
    setEditingCurrency(null);
    setNewCurrency({ code: '', name: '', symbol: '', exchangeRate: 1, minRate: 0, maxRate: 0, isDefault: false });
  };

  const handleDelete = (id: string) => {
    const currency = currencies.find(c => c.id === id);
    if (currency?.isDefault) {
      showNotification('لا يمكن حذف العملة الافتراضية', 'error');
      return;
    }

    setConfirmModal({
      title: 'حذف العملة',
      message: 'هل أنت متأكد من حذف هذه العملة؟',
      onConfirm: () => {
        const updated = currencies.filter(c => c.id !== id);
        onUpdateDB({ ...db, currencies: updated }, 'currencies', id, null, true);
        showNotification('تم حذف العملة');
      }
    });
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-blue-600 rounded-2xl shadow-lg shadow-blue-100">
            <DollarSign className="text-white" size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-black text-slate-800">العملات وأسعار الصرف</h1>
            <p className="text-slate-500 font-medium">إدارة العملات وتحديد العملة الافتراضية للنظام</p>
          </div>
        </div>
        <button 
          onClick={() => {
            setEditingCurrency(null);
            setNewCurrency({ code: '', name: '', symbol: '', exchangeRate: 1, isDefault: false });
            setIsAdding(true);
          }}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-bold shadow-lg shadow-blue-100 transition-all"
        >
          <Plus size={20} />
          إضافة عملة جديدة
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {currencies.map((currency) => (
          <motion.div 
            key={currency.id}
            whileHover={{ y: -5 }}
            className={`bg-white p-6 rounded-3xl border-2 transition-all ${currency.isDefault ? 'border-blue-500 shadow-blue-50' : 'border-slate-100 shadow-sm'}`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`p-3 rounded-2xl ${currency.isDefault ? 'bg-blue-50 text-blue-600' : 'bg-slate-50 text-slate-400'}`}>
                <DollarSign size={24} />
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => {
                    setEditingCurrency(currency);
                    setNewCurrency(currency);
                    setIsAdding(true);
                  }}
                  className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
                >
                  <TrendingUp size={18} />
                </button>
                <button 
                  onClick={() => handleDelete(currency.id)}
                  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black text-slate-800">{currency.name}</h3>
                <span className="text-xs font-bold px-2 py-0.5 bg-slate-100 text-slate-500 rounded-full">{currency.code}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">سعر الصرف:</span>
                <span className="font-black text-slate-800">{currency.exchangeRate}</span>
              </div>
              {(currency.minRate || currency.maxRate) && (
                <div className="flex items-center justify-between text-[10px] text-slate-400 border-t border-slate-50 pt-2">
                  <span>الحد: {currency.minRate || '-'} / {currency.maxRate || '-'}</span>
                </div>
              )}
              {currency.isDefault && (
                <div className="flex items-center gap-2 text-blue-600 font-bold text-xs mt-4">
                  <CheckCircle2 size={14} />
                  العملة الافتراضية
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAdding(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-lg rounded-3xl shadow-2xl p-8 overflow-hidden"
            >
              <h3 className="text-2xl font-black text-slate-800 mb-8">{editingCurrency ? 'تعديل عملة' : 'إضافة عملة جديدة'}</h3>
              
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 mr-2">كود العملة (مثل USD)</label>
                    <input 
                      type="text"
                      value={newCurrency.code}
                      onChange={e => setNewCurrency({...newCurrency, code: e.target.value.toUpperCase()})}
                      className="w-full px-4 py-3 rounded-2xl border border-slate-200 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold"
                      placeholder="USD"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 mr-2">الرمز (مثل $)</label>
                    <input 
                      type="text"
                      value={newCurrency.symbol}
                      onChange={e => setNewCurrency({...newCurrency, symbol: e.target.value})}
                      className="w-full px-4 py-3 rounded-2xl border border-slate-200 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold"
                      placeholder="$"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 mr-2">اسم العملة</label>
                  <input 
                    type="text"
                    value={newCurrency.name}
                    onChange={e => setNewCurrency({...newCurrency, name: e.target.value})}
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold"
                    placeholder="دولار أمريكي"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 mr-2">سعر الصرف (مقابل العملة الأساسية)</label>
                  <div className="relative">
                    <TrendingUp className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <input 
                      type="number"
                      step="0.000001"
                      value={newCurrency.isDefault ? 1 : newCurrency.exchangeRate}
                      disabled={newCurrency.isDefault}
                      onChange={e => setNewCurrency({...newCurrency, exchangeRate: parseFloat(e.target.value)})}
                      className={`w-full pr-12 pl-4 py-3 rounded-2xl border border-slate-200 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold ${newCurrency.isDefault ? 'bg-slate-50 text-slate-400' : ''}`}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 mr-2">الحد الأدنى للصرف</label>
                    <input 
                      type="number"
                      step="0.000001"
                      value={newCurrency.isDefault ? '' : (newCurrency.minRate || '')}
                      disabled={newCurrency.isDefault}
                      onChange={e => setNewCurrency({...newCurrency, minRate: parseFloat(e.target.value)})}
                      className={`w-full px-4 py-3 rounded-2xl border border-slate-200 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold ${newCurrency.isDefault ? 'bg-slate-50 text-slate-400' : ''}`}
                      placeholder={newCurrency.isDefault ? 'لا يوجد' : '0.00'}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 mr-2">الحد الأعلى للصرف</label>
                    <input 
                      type="number"
                      step="0.000001"
                      value={newCurrency.isDefault ? '' : (newCurrency.maxRate || '')}
                      disabled={newCurrency.isDefault}
                      onChange={e => setNewCurrency({...newCurrency, maxRate: parseFloat(e.target.value)})}
                      className={`w-full px-4 py-3 rounded-2xl border border-slate-200 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-bold ${newCurrency.isDefault ? 'bg-slate-50 text-slate-400' : ''}`}
                      placeholder={newCurrency.isDefault ? 'لا يوجد' : '0.00'}
                    />
                  </div>
                </div>

                <label className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl cursor-pointer hover:bg-slate-100 transition-all">
                  <input 
                    type="checkbox"
                    checked={newCurrency.isDefault}
                    onChange={e => setNewCurrency({...newCurrency, isDefault: e.target.checked})}
                    className="w-5 h-5 rounded-lg text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm font-bold text-slate-700">تعيين كعملة افتراضية للنظام</span>
                </label>

                <div className="flex gap-4 pt-4">
                  <button 
                    onClick={() => setIsAdding(false)}
                    className="flex-1 px-6 py-4 rounded-2xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-all"
                  >
                    إلغاء
                  </button>
                  <button 
                    onClick={handleSave}
                    className="flex-1 px-6 py-4 rounded-2xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 flex items-center justify-center gap-2"
                  >
                    <Save size={20} />
                    حفظ العملة
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
