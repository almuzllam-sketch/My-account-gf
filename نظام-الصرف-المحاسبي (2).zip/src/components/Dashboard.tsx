import React, { useMemo } from 'react';
import { 
  Users, 
  Package, 
  FileText, 
  TrendingUp, 
  ArrowUpRight, 
  Clock,
  ChevronLeft,
  ShoppingBag,
  PlusCircle,
  BarChart3,
  PieChart as PieChartIcon,
  Activity,
  ArrowDownRight,
  Database
} from 'lucide-react';
import { motion } from 'motion/react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from 'recharts';
import { DB, ViewType, Doc, User } from '../types';

interface DashboardProps {
  db: DB;
  user: User;
  onNewDoc: () => void;
  onEditDoc: (doc: Doc) => void;
  onHistory: () => void;
  onSettings: () => void;
  allCompanies?: { id: string; name: string }[];
}

export const Dashboard: React.FC<DashboardProps> = React.memo(({ db, user, onNewDoc, onEditDoc, onHistory, onSettings, allCompanies }) => {
  const [typeFilter, setTypeFilter] = React.useState<'all' | 'issue' | 'purchase' | 'sale'>('all');

  const stats = useMemo(() => {
    const totalSold = (db.docs || []).filter(d => d.type === 'issue' || d.type === 'sale').reduce((sum, doc) => sum + (doc.items || []).reduce((s, i) => s + (i.qty || 0), 0), 0);
    const totalPurchased = (db.docs || []).filter(d => d.type === 'purchase').reduce((sum, doc) => sum + (doc.items || []).reduce((s, i) => s + (i.qty || 0), 0), 0);
    return [
      { label: 'إجمالي السندات', value: (db.docs || []).filter(d => d.type === 'issue').length, icon: FileText, color: 'blue', trend: '+12%' },
      { label: 'فواتير المشتريات', value: (db.docs || []).filter(d => d.type === 'purchase').length, icon: ShoppingBag, color: 'purple', trend: '+5%' },
      { label: 'فواتير المبيعات', value: (db.docs || []).filter(d => d.type === 'sale').length, icon: TrendingUp, color: 'emerald', trend: '+18%' },
      { label: 'إجمالي الكميات', value: totalSold + totalPurchased, icon: ArrowUpRight, color: 'rose', trend: '+8%' },
    ];
  }, [db]);

  const chartData = useMemo(() => {
    // Generate last 7 days of data
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return d.toISOString().split('T')[0];
    });

    return days.map(day => {
      const dayDocs = (db.docs || []).filter(doc => doc.date === day);
      return {
        name: new Date(day).toLocaleDateString('ar-SA', { weekday: 'short' }),
        sales: dayDocs.filter(d => d.type === 'sale' || d.type === 'issue').length,
        purchases: dayDocs.filter(d => d.type === 'purchase').length,
      };
    });
  }, [db.docs]);

  const topAccountsData = useMemo(() => {
    const counts: Record<string, number> = {};
    (db.docs || []).forEach(doc => {
      const acc = (db.accounts || []).find(a => a.id === doc.accId);
      if (acc) {
        counts[acc.name] = (counts[acc.name] || 0) + 1;
      }
    });
    return Object.entries(counts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
  }, [db.docs, db.accounts]);

  const recentDocs = useMemo(() => {
    return [...(db.docs || [])]
      .filter(d => typeFilter === 'all' || d.type === typeFilter)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 8);
  }, [db.docs, typeFilter]);

  return (
    <div className="space-y-8 pb-12">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="relative">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-4"
          >
            <div className="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-xl shadow-blue-200">
              <Activity size={28} />
            </div>
            <div>
              <h1 className="text-3xl font-black text-slate-900 tracking-tight">مرحباً، {user.name}</h1>
              <p className="text-slate-500 font-medium mt-0.5">نظرة عامة على الأداء المالي والنشاط التجاري</p>
            </div>
          </motion.div>
        </div>
        <div className="flex items-center gap-3">
          {(user.role === 'admin' || user.canViewReports) && (
            <button 
              onClick={onHistory}
              className="px-6 py-3 rounded-2xl border border-slate-200 text-slate-600 font-black text-sm hover:bg-slate-50 transition-all active:scale-95"
            >
              السجلات العامة
            </button>
          )}
          {(user.role === 'admin' || user.canCreateIssue || user.canCreatePurchase || user.canCreateSale) && (
            <button 
              onClick={onNewDoc}
              className="bg-slate-900 hover:bg-slate-800 text-white px-8 py-3 rounded-2xl font-black text-sm shadow-2xl shadow-slate-200 transition-all flex items-center gap-2 active:scale-95"
            >
              <PlusCircle size={20} />
              إضافة عملية جديدة
            </button>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group relative overflow-hidden"
          >
            <div className={`absolute top-0 right-0 w-24 h-24 bg-${stat.color}-500/5 rounded-full -mr-12 -mt-12 group-hover:scale-150 transition-transform duration-700`}></div>
            
            <div className="relative z-10">
              <div className={`w-12 h-12 rounded-2xl bg-${stat.color}-50 flex items-center justify-center text-${stat.color}-600 mb-4 group-hover:scale-110 transition-transform`}>
                <stat.icon size={24} />
              </div>
              
              <div className="flex flex-col gap-1">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{stat.label}</p>
                <div className="flex items-end justify-between">
                  <h3 className="text-3xl font-black text-slate-900">{stat.value.toLocaleString()}</h3>
                  <div className={`flex items-center gap-1 text-[10px] font-black px-2 py-1 rounded-lg ${stat.trend.startsWith('+') ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                    {stat.trend.startsWith('+') ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                    {stat.trend}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Activity Chart */}
        <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="bg-blue-50 p-2 rounded-xl">
                <BarChart3 className="text-blue-600" size={20} />
              </div>
              <div>
                <h3 className="font-black text-slate-800">تحليل العمليات الأسبوعي</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">Sales vs Purchases</p>
              </div>
            </div>
            <div className="flex items-center gap-4 text-xs font-bold">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                <span className="text-slate-500">المبيعات</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-slate-200"></div>
                <span className="text-slate-500">المشتريات</span>
              </div>
            </div>
          </div>
          
          <div className="h-[300px] w-full min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%" minWidth={0} debounce={50}>
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 700 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 700 }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#fff', 
                    borderRadius: '16px', 
                    border: 'none', 
                    boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)',
                    padding: '12px'
                  }}
                  itemStyle={{ fontWeight: 800, fontSize: '12px' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="sales" 
                  stroke="#3b82f6" 
                  strokeWidth={4}
                  fillOpacity={1} 
                  fill="url(#colorSales)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="purchases" 
                  stroke="#e2e8f0" 
                  strokeWidth={4}
                  fill="transparent" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Accounts Chart */}
        <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
          <div className="flex items-center gap-3 mb-8">
            <div className="bg-emerald-50 p-2 rounded-xl">
              <PieChartIcon className="text-emerald-600" size={20} />
            </div>
            <div>
              <h3 className="font-black text-slate-800">أكثر الحسابات نشاطاً</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">Top Active Accounts</p>
            </div>
          </div>

          <div className="space-y-6">
            {topAccountsData.map((item, idx) => (
              <div key={item.name} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-bold text-slate-700">{item.name}</span>
                  <span className="text-xs font-black text-blue-600 bg-blue-50 px-2 py-0.5 rounded-lg">{item.value} عملية</span>
                </div>
                <div className="h-2 w-full bg-slate-50 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(item.value / topAccountsData[0].value) * 100}%` }}
                    transition={{ duration: 1, delay: idx * 0.1 }}
                    className={`h-full rounded-full ${
                      idx === 0 ? 'bg-blue-600' : 
                      idx === 1 ? 'bg-indigo-500' : 
                      idx === 2 ? 'bg-emerald-500' : 
                      idx === 3 ? 'bg-amber-500' : 'bg-slate-300'
                    }`}
                  />
                </div>
              </div>
            ))}
            {topAccountsData.length === 0 && (
              <div className="py-12 text-center text-slate-300">
                <Activity size={40} className="mx-auto mb-2 opacity-20" />
                <p className="text-sm font-bold">لا توجد بيانات كافية</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity Table */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-50/30">
            <div className="flex items-center gap-3">
              <div className="bg-slate-900 p-2 rounded-xl">
                <Clock className="text-white" size={18} />
              </div>
              <h3 className="font-black text-slate-800">أحدث العمليات المسجلة</h3>
            </div>
            
            <div className="flex items-center gap-1 bg-white p-1 rounded-2xl border border-slate-100 shadow-sm">
              <button 
                onClick={() => setTypeFilter('all')}
                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${typeFilter === 'all' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
              >
                الكل
              </button>
              <button 
                onClick={() => setTypeFilter('issue')}
                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${typeFilter === 'issue' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
              >
                صرف
              </button>
              <button 
                onClick={() => setTypeFilter('purchase')}
                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${typeFilter === 'purchase' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
              >
                مشتريات
              </button>
              <button 
                onClick={() => setTypeFilter('sale')}
                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${typeFilter === 'sale' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
              >
                مبيعات
              </button>
            </div>
          </div>

          <div className="divide-y divide-slate-50">
            {recentDocs.length > 0 ? (
              recentDocs.map((doc) => {
                const acc = (db.accounts || []).find(a => a.id === doc.accId);
                const isPurchase = doc.type === 'purchase';
                const isSale = doc.type === 'sale';
                return (
                  <div 
                    key={doc.id} 
                    onClick={() => onEditDoc(doc)}
                    className="p-5 hover:bg-slate-50 transition-all flex items-center justify-between cursor-pointer group"
                  >
                    <div className="flex items-center gap-5">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
                        isPurchase 
                          ? 'bg-purple-50 text-purple-600 group-hover:bg-purple-600 group-hover:text-white' 
                          : isSale
                          ? 'bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white'
                          : 'bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white'
                      }`}>
                        <FileText size={22} />
                      </div>
                      <div>
                        <div className="flex items-center gap-3">
                          <p className="font-black text-slate-800 group-hover:text-blue-600 transition-colors">{acc?.name || 'حساب غير معروف'}</p>
                          <span className={`text-[9px] font-black px-2 py-1 rounded-lg uppercase tracking-widest ${
                            isPurchase ? 'bg-purple-100 text-purple-700' : isSale ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'
                          }`}>
                            {isPurchase ? 'مشتريات' : isSale ? 'مبيعات' : 'سند صرف'}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-widest">
                          <span>REF: {doc.ref}</span>
                          <span className="w-1 h-1 rounded-full bg-slate-200"></span>
                          <span>{new Date(doc.date).toLocaleDateString('ar-SA')}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="text-left hidden sm:block">
                        <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-0.5">الكمية</p>
                        <p className="text-sm font-black text-slate-900">{(doc.items || []).length} أصناف</p>
                      </div>
                      <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-300 group-hover:bg-blue-50 group-hover:text-blue-600 transition-all">
                        <ChevronLeft size={20} />
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-20 text-center text-slate-300">
                <FileText size={64} className="mx-auto mb-4 opacity-10" />
                <p className="text-lg font-black">لا توجد عمليات مسجلة</p>
                <p className="text-sm font-bold mt-1">ابدأ بإضافة أول عملية من خلال الزر في الأعلى</p>
              </div>
            )}
          </div>
          
          {recentDocs.length > 0 && (
            <div className="p-6 bg-slate-50/50 border-t border-slate-50 text-center">
              <button 
                onClick={onHistory}
                className="text-blue-600 text-xs font-black uppercase tracking-[0.2em] hover:text-blue-700 transition-colors flex items-center justify-center gap-2 mx-auto"
              >
                عرض كافة السجلات التاريخية
                <ChevronLeft size={16} />
              </button>
            </div>
          )}
        </div>

        {/* Sidebar Cards */}
        <div className="space-y-8">
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-[2rem] p-8 text-white shadow-2xl shadow-slate-200 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-1000"></div>
            <div className="relative z-10">
              <div className="bg-white/10 w-12 h-12 rounded-2xl flex items-center justify-center mb-6 backdrop-blur-xl">
                <Activity className="text-blue-400" size={24} />
              </div>
              <h3 className="font-black text-xl mb-3">نظام النسخ الاحتياطي</h3>
              <p className="text-slate-400 text-sm leading-relaxed font-medium mb-8">
                بياناتك المحاسبية هي أثمن ما تملك. تأكد من تصدير نسخة احتياطية بشكل دوري لضمان استمرارية العمل.
              </p>
              <button 
                onClick={onSettings}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-2xl text-sm font-black transition-all shadow-xl shadow-blue-900/20 active:scale-95"
              >
                إدارة البيانات والنسخ
              </button>
            </div>
          </div>

          <div className="bg-white rounded-[2rem] border border-slate-100 p-8 shadow-sm">
            <div className="flex items-center gap-3 mb-8">
              <div className="bg-slate-100 p-2 rounded-xl">
                <Database className="text-slate-600" size={18} />
              </div>
              <h3 className="font-black text-slate-800">إحصائيات الدليل</h3>
            </div>
            <div className="space-y-6">
              {[
                { label: 'الحسابات المالية', count: (db.accounts || []).length, color: 'bg-blue-600', total: 100 },
                { label: 'مراكز التكلفة', count: (db.centers || []).length, color: 'bg-indigo-600', total: 50 },
                { label: 'دليل الأصناف', count: (db.items || []).length, color: 'bg-emerald-600', total: 200 },
              ].map(item => (
                <div key={item.label} className="space-y-2">
                  <div className="flex justify-between items-end">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.label}</span>
                    <span className="text-sm font-black text-slate-900">{item.count}</span>
                  </div>
                  <div className="h-2 w-full bg-slate-50 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(100, (item.count / item.total) * 100)}%` }}
                      transition={{ duration: 1.5, ease: "easeOut" }}
                      className={`h-full ${item.color} rounded-full`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
