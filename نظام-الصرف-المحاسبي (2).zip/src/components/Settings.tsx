import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { 
  Users, 
  Package, 
  TrendingUp, 
  Download, 
  Upload, 
  Trash2, 
  Plus,
  Save,
  Database,
  Shield,
  FileJson,
  FileSpreadsheet,
  Building,
  Settings as SettingsIcon,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  Edit2,
  Lock,
  Power,
  ChevronRight,
  Folder,
  FileText as FileIcon,
  Search,
  X,
  BarChart3,
  Calendar,
  Unlock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { doc, setDoc, writeBatch } from 'firebase/firestore';
import { db as firestore } from '../firebase';
import { uid } from '../lib/utils';
import { DB, Account, CostCenter, Item, CompanyInfo, FieldDefinition, Branch, Warehouse, Department, User, Unit, PricingDoc, PricingDocItem, FiscalYear } from '../types';

interface SettingsProps {
  db: DB;
  user: User;
  onUpdateDB: (newDb: DB, collectionName?: string, docId?: string, data?: any, isDelete?: boolean) => void;
  showNotification: (msg: string, type?: 'success' | 'error' | 'warning') => void;
  setConfirmModal: (modal: { title: string; message: string; onConfirm: () => void } | null) => void;
  initialTab?: 'accounts' | 'centers' | 'items' | 'company' | 'backup' | 'fields' | 'branches' | 'warehouses' | 'departments' | 'users' | 'data-mgmt' | 'pricing-docs' | 'all-companies' | 'system' | 'fiscal-years' | 'currencies';
  isSuperAdmin?: boolean;
  allCompanies?: { id: string; name: string }[];
}

interface DirectoryItem {
  id: string;
  code: string;
  name: string;
  parentId: string | null;
  level: number;
  isLeaf?: boolean;
  isPostable?: boolean;
  type?: string;
  branchId?: string;
  departmentId?: string;
  [key: string]: any;
}

interface DirectoryTreeProps {
  items: DirectoryItem[];
  onUpdate: (items: any[], item: any, isDelete?: boolean) => void;
  title: string;
  type: 'accounts' | 'items' | 'centers' | 'departments' | 'branches' | 'warehouses' | 'funds' | 'banks' | 'customers-suppliers';
  db: DB;
  showType?: boolean;
  showUnits?: boolean;
  companyId: string;
  showNotification: (msg: string, type?: 'success' | 'error' | 'warning') => void;
  setConfirmModal: (modal: { title: string; message: string; onConfirm: () => void } | null) => void;
  onUpdateDB: (newDb: DB, collectionName?: string, docId?: string, data?: any, isDelete?: boolean) => void;
}

const DirectoryTree: React.FC<DirectoryTreeProps> = ({ items, onUpdate, title, type, db, showType, showUnits, companyId, showNotification, setConfirmModal, onUpdateDB }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [editingItem, setEditingItem] = useState<DirectoryItem | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [importState, setImportState] = useState<{
    show: boolean;
    headers: string[];
    data: any[];
    mapping: Record<string, string>;
  }>({
    show: false,
    headers: [],
    data: [],
    mapping: {}
  });

  // Auto-expand on search
  useEffect(() => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchedIds = items
        .filter(item => (item.name || '').toLowerCase().includes(q) || (item.code || '').toLowerCase().includes(q))
        .map(item => item.parentId)
        .filter((id): id is string => id !== null);
      
      const parentsToExpand = new Set<string>();
      matchedIds.forEach(id => {
        let currentId: string | null = id;
        while (currentId) {
          parentsToExpand.add(currentId);
          const parent = items.find(i => i.id === currentId);
          currentId = parent?.parentId || null;
        }
      });
      
      setExpandedGroups(prev => new Set([...prev, ...parentsToExpand]));
    }
  }, [searchQuery, items]);
  const [newItem, setNewItem] = useState<Partial<DirectoryItem>>({
    code: '',
    name: '',
    parentId: null,
    level: 1,
    isLeaf: false,
    isPostable: false,
    type: 'other',
    accId: '',
    units: [{ name: 'حبة', factor: 1 }]
  });

  const hasChildren = (id: string) => items.some(i => i.parentId === id);

  const toggleGroup = (id: string) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(id)) newExpanded.delete(id);
    else newExpanded.add(id);
    setExpandedGroups(newExpanded);
  };

  const highlightText = (text: string, query: string) => {
    if (!text) return '';
    if (!query.trim()) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return (
      <span>
        {parts.map((part, i) => 
          part.toLowerCase() === query.toLowerCase() ? (
            <mark key={i} className="bg-yellow-200 text-slate-900 rounded px-0.5">{part}</mark>
          ) : part
        )}
      </span>
    );
  };

  const expandAll = () => {
    const allIds = new Set(items.filter(i => hasChildren(i.id)).map(i => i.id));
    setExpandedGroups(allIds);
  };

  const collapseAll = () => {
    setExpandedGroups(new Set());
  };

  const getChildren = (parentId: string | null) => {
    return items.filter(item => {
      const pId = item.parentId || null;
      return pId === parentId;
    });
  };

  const generateNextCode = (parentId: string | null) => {
    const siblings = items.filter(i => i.parentId === parentId);
    if (siblings.length === 0) {
      if (parentId) {
        const parent = items.find(i => i.id === parentId);
        return parent ? `${parent.code}01` : '1';
      }
      return '1';
    }
    const codes = siblings.map(i => parseInt(i.code)).filter(c => !isNaN(c));
    const maxCode = Math.max(...codes);
    return (maxCode + 1).toString();
  };

  const downloadTemplate = () => {
    let headers: any[][] = [];
    let sampleData: any[][] = [];

    if (type === 'accounts') {
      headers = [['Code', 'Name', 'ParentCode', 'IsGroup', 'Type', 'Currency']]; // Reverted: Removed ID column
      sampleData = [
        ['1', 'الأصول', '', '1', 'أخرى', 'YER'],
        ['11', 'الأصول المتداولة', '1', '1', 'أخرى', 'YER'],
        ['111', 'الصندوق', '11', '2', 'أخرى', 'YER'],
        ['2', 'الخصوم', '', '1', 'أخرى', 'YER'],
        ['21', 'الموردون', '2', '1', 'مورد', 'YER'],
        ['211', 'شركة التوريد العالمية', '21', '2', 'مورد', 'YER']
      ];
    } else if (type === 'items') {
      headers = [['Code', 'Name', 'GrpLeave', 'ParentCode', 'AltrvName', 'VendId', 'Other Details', 'Identification', 'Unit1Name', 'Unit1EngName', 'Unit1BarCode', 'Unit2Name', 'Unit2EngName', 'Conversion', 'Unit2BarCode']];
      sampleData = [
        ['100', 'مجموعة الألبان', '1', '', '', '0', '', '0', 'مجموعة', '', '', '', '', '0', ''],
        ['1001', 'حليب كامل الدسم', '2', '100', 'Full Fat Milk', '0', 'طازج', '0', 'كرتون', 'Carton', '111111', 'حبة', 'Piece', '12', '222222']
      ];
    } else {
      headers = [['الكود', 'الاسم', 'كود_الأب', 'نهائي']];
      sampleData = [
        ['1', 'المركز الرئيسي', '', 'لا'],
        ['11', 'قسم المبيعات', '1', 'نعم'],
        ['2', 'فرع جدة', '', 'نعم']
      ];
    }

    const ws = XLSX.utils.aoa_to_sheet([...headers, ...sampleData]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Template");
    XLSX.writeFile(wb, `${title}_template.xlsx`);
  };

  const isLinkedType = ['funds', 'banks', 'customers-suppliers'].includes(type);

  const handleSave = () => {
    if (!newItem.code || !newItem.name) return;
    if (isLinkedType && !newItem.isLeaf && !newItem.accId && !newItem.parentId) {
      // If it's a linked type and it's a leaf node, it must have an accId
    }
    
    // Calculate level based on parent
    let level = 1;
    if (newItem.parentId) {
      // البحث عن الأب باستخدام المعرف الفريد (Find parent using unique ID)
      const parent = items.find(i => i.id === newItem.parentId);
      if (parent) level = parent.level + 1;
    }

    // Rules for levels
    const maxLevel = type === 'accounts' ? (db.settings?.accountsMaxLevel || 5) : 
                     type === 'items' ? (db.settings?.itemsMaxLevel || 5) :
                     type === 'centers' ? (db.settings?.centersMaxLevel || 5) : 5;

    if (level > maxLevel) {
      alert(`لا يمكن تجاوز ${maxLevel} مستويات في هذا الدليل`);
      return;
    }

    const finalItem = {
      ...newItem,
      level,
      parentId: newItem.parentId || null,
      // Auto-set isLeaf/isPostable based on level
      isPostable: level === maxLevel ? true : (newItem.isPostable === true),
      isLeaf: level === maxLevel ? true : (newItem.isLeaf === true)
    };

    if (editingItem) {
      // تعديل باستخدام المعرف الفريد ID لضمان الدقة (Edit using unique ID)
      const item = { ...editingItem, ...finalItem, companyId };
      const updated = items.map(i => i.id === editingItem.id ? item : i);
      onUpdate(updated, item);
    } else {
      // توليد معرف فريد تلقائياً عند الإضافة (Auto-generate unique ID on create)
      const item = {
        id: uid(),
        companyId,
        ...finalItem
      };
      onUpdate([...items, item as any], item);
    }
    
    setEditingItem(null);
    setIsAdding(false);
    setNewItem({ code: '', name: '', parentId: null, level: 1, isLeaf: false, isPostable: false, type: 'other', units: [{ name: 'حبة', factor: 1 }] });
  };

  const handleDelete = (id: string) => {
    // استخدام المعرف id للحذف لضمان الدقة وتجنب تكرار الكود (Use ID for deletion for precision)
    const item = items.find(i => i.id === id);
    if (!item) return;

    // Rule: Cannot delete if children exist
    if (items.some(i => i.parentId === id)) {
      showNotification('لا يمكن حذف عنصر يحتوي على عناصر فرعية', 'warning');
      return;
    }

    // Rule: Cannot delete if used in transactions (simplified check)
    const isUsed = (db.docs || []).some(doc => 
      (doc.items || []).some(it => it.itemId === id) || 
      doc.accId === id || 
      doc.ccId === id ||
      doc.branchId === id ||
      doc.warehouseId === id ||
      doc.deptId === id
    );

    if (isUsed) {
      showNotification('لا يمكن حذف هذا العنصر لوجود حركات مرتبطة به', 'warning');
      return;
    }

    setConfirmModal({
      title: 'تأكيد الحذف',
      message: `هل أنت متأكد من رغبتك في حذف "${item.name}"؟ لا يمكن التراجع عن هذه العملية.`,
      onConfirm: () => {
        onUpdate(items.filter(i => i.id !== id), item, true);
        setConfirmModal(null);
      }
    });
  };

  const renderTree = (parentId: string | null, level: number = 0) => {
    const allMatchingIds = new Set<string>();
    
    if (searchQuery) {
      items.forEach(item => {
        if (item.name.includes(searchQuery) || item.code.includes(searchQuery)) {
          allMatchingIds.add(item.id);
          // Add all parents to ensure visibility
          let curr = item;
          while (curr.parentId) {
            const parent = items.find(i => i.id === curr.parentId);
            if (parent) {
              allMatchingIds.add(parent.id);
              curr = parent;
            } else break;
          }
        }
      });
    }

    const children = getChildren(parentId).filter(c => 
      !searchQuery || allMatchingIds.has(c.id)
    );

    if (children.length === 0 && parentId === null) {
      return (
        <div className="p-12 text-center text-slate-400">
          <Database size={48} className="mx-auto mb-4 opacity-10" />
          <p className="font-bold">لا يوجد بيانات لعرضها في {title}</p>
          <p className="text-xs mt-1">ابدأ بإضافة عناصر جديدة أو استيرادها من إكسل</p>
        </div>
      );
    }

    return children.map(item => (
      <React.Fragment key={item.id}>
        <div 
          className={`flex items-center justify-between p-3 hover:bg-slate-50 transition-colors border-b border-slate-50 ${level > 0 ? 'mr-4 border-r-2 border-slate-100' : ''}`}
          style={{ paddingRight: `${level * 1.5 + 1}rem` }}
        >
          <div className="flex items-center gap-3">
            {hasChildren(item.id) ? (
              <button onClick={() => toggleGroup(item.id)} className="text-slate-400 hover:text-blue-600">
                {(expandedGroups.has(item.id) || searchQuery) ? <ChevronDown size={18} /> : <ChevronLeft size={18} />}
              </button>
            ) : (
              <div className="w-[18px]" />
            )}
            {hasChildren(item.id) ? <Folder size={18} className="text-amber-500" /> : <FileIcon size={18} className="text-blue-500" />}
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-800">{highlightText(item.name, searchQuery)}</span>
                <span className="text-[10px] px-1.5 py-0.5 bg-slate-100 rounded text-slate-400">L{item.level}</span>
                {item.accId && (
                  <span className="text-[10px] bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded-full font-bold">
                    مربوط بـ: {(db.accounts || []).find(a => a.id === item.accId)?.name}
                  </span>
                )}
                {item.branchId && (
                  <span className="text-[10px] bg-emerald-50 text-emerald-600 px-1.5 py-0.5 rounded-full font-bold">
                    فرع: {(db.branches || []).find(b => b.id === item.branchId)?.name}
                  </span>
                )}
                {item.departmentId && (
                  <span className="text-[10px] bg-purple-50 text-purple-600 px-1.5 py-0.5 rounded-full font-bold">
                    قسم: {(db.departments || []).find(d => d.id === item.departmentId)?.name}
                  </span>
                )}
              </div>
              <span className="text-[10px] font-mono text-slate-400">{highlightText(item.code, searchQuery)}</span>
            </div>
            {item.type && (
              <span className="text-[10px] px-2 py-0.5 bg-slate-100 rounded-full text-slate-500 font-bold">
                {item.type === 'client' ? 'عميل' : 
                 item.type === 'supplier' ? 'مورد' : 
                 item.type === 'both' ? 'عميل ومورد' : 
                 item.type === 'cost' ? 'تكلفة' : 
                 item.type === 'revenue' ? 'ايراد' : 'أخرى'}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => {
                setEditingItem(item);
                setNewItem(item);
                setIsAdding(true);
              }}
              className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
            >
              <Edit2 size={16} />
            </button>
            <button 
              onClick={() => handleDelete(item.id)}
              className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>
        {(hasChildren(item.id)) && (expandedGroups.has(item.id) || searchQuery) && renderTree(item.id, level + 1)}
      </React.Fragment>
    ));
  };

  const importFromExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(ws) as any[];

        if (jsonData.length === 0) {
          showNotification('الملف فارغ أو غير صالح', 'error');
          return;
        }

        const headers = Object.keys(jsonData[0]);
        
        // Initial auto-mapping based on common names
        const initialMapping: Record<string, string> = {};
        const fieldOptions = [
          { key: 'id', aliases: ['id', 'المعرف', 'رقم الفريد'] },
          { key: 'code', aliases: ['code', 'رقم الصنف', 'الكود', 'كود'] },
          { key: 'name', aliases: ['name', 'اسم الصنف', 'الاسم', 'اسم'] },
          { key: 'parentCode', aliases: ['parentCode', 'رقم الأب', 'كود_الأب', 'الاب'] },
          { key: 'type', aliases: ['type', 'النوع', 'نوع'] },
          { key: 'isLeaf', aliases: ['isLeaf', 'GrpLeave', 'IsGroup', 'نهائي', 'صنف_نهائي'] },
          { key: 'units', aliases: ['units', 'الوحدات', 'وحدات'] },
          { key: 'branchCode', aliases: ['branchCode', 'كود_الفرع', 'الفرع'] },
          { key: 'currency', aliases: ['currency', 'العملة', 'عملة'] },
          // Item custom fields
          { key: 'altName', aliases: ['AltrvName', 'اسم انجليزي'] },
          { key: 'vendor', aliases: ['VendId', 'المورد'] },
          { key: 'details', aliases: ['Other Details', 'تفاصيل'] },
          { key: 'u1name', aliases: ['Unit1Name', 'وحدة1'] },
          { key: 'u1barcode', aliases: ['Unit1BarCode', 'باركود1'] },
          { key: 'u2name', aliases: ['Unit2Name', 'وحدة2'] },
          { key: 'u2factor', aliases: ['Conversion', 'تحويل'] },
          { key: 'u2barcode', aliases: ['Unit2BarCode', 'باركود2'] },
          { key: 'identification', aliases: ['Identification', 'معرف'] },
        ];

        fieldOptions.forEach(field => {
          const match = headers.find(h => field.aliases.some(alias => h.toLowerCase().includes(alias.toLowerCase())));
          if (match) initialMapping[field.key] = match;
        });

        setImportState({
          show: true,
          headers,
          data: jsonData,
          mapping: initialMapping
        });
      } catch (err) {
        console.error(err);
        showNotification('❌ فشل قراءة الملف.', 'error');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  const executeImport = () => {
    const { data, mapping } = importState;
    const currentList = items;
    const importedItems: any[] = [];
    const codeToIdMap: Record<string, string> = {};
    
    // First pass: create IDs or use existing ones (الأولوية للمعرف ID ثم الكود كاحتياطي)
    data.forEach(row => {
      const rowId = String(row[mapping.id] || '');
      const code = String(row[mapping.code] || '');
      
      if (rowId) {
        // استخدام ID الموجود في الملف إن وجد (Use ID from file if present)
        codeToIdMap[code] = rowId;
      } else if (code) {
        // البحث عن معرف موجود سابقاً لنفس الكود لضمان الربط (Find existing ID for this code)
        const existing = currentList.find(i => i.code === code);
        codeToIdMap[code] = existing ? existing.id : uid(); // توليد تلقائي إذا لم يوجد
      }
    });

    // Second pass: resolve parents and build objects
    data.forEach(row => {
      const code = String(row[mapping.code] || '');
      const name = String(row[mapping.name] || '');
      const rowId = String(row[mapping.id] || '');
      if (!code || !name) return;

      const parentCode = String(row[mapping.parentCode] || '');
      const existingParent = currentList.find(i => i.code === parentCode);
      const importedParentId = codeToIdMap[parentCode];
      
      const parentId = existingParent?.id || importedParentId || null;
      const parent = existingParent || importedItems.find(i => i.id === parentId);
      
      const currentLevel = parent ? parent.level + 1 : 1;
      const grpLeave = row[mapping.isLeaf];
      
      // Default isLeaf logic for other types
      let isLeaf = typeof grpLeave === 'boolean' ? grpLeave : (String(grpLeave).toLowerCase() === 'نعم' || String(grpLeave).toLowerCase() === 'true' || !!grpLeave);

      const base = {
        // الاعتماد على ID في التعديل والربط الداخلي (Reliance on ID for edit and linking)
        id: rowId || codeToIdMap[code] || uid(),
        companyId,
        code,
        name,
        parentId,
        level: currentLevel,
      };

      let finalItem: any = base;

      if (type === 'items') {
        const itemIsLeaf = String(grpLeave) === '2' || String(grpLeave).toLowerCase() === 'صنف';
        
        const units: any[] = [];
        if (itemIsLeaf) {
          const u1name = String(row[mapping.u1name] || row['Unit1Name'] || '');
          if (u1name) {
            units.push({ 
              name: u1name, factor: 1, 
              barcode: String(row[mapping.u1barcode] || row['Unit1BarCode'] || ''),
              engName: String(row['Unit1EngName'] || '')
            });
          }
          const u2name = String(row[mapping.u2name] || row['Unit2Name'] || '');
          if (u2name) {
            units.push({ 
              name: u2name, factor: parseFloat(row[mapping.u2factor] || row['Conversion']) || 1, 
              barcode: String(row[mapping.u2barcode] || row['Unit2BarCode'] || ''),
              engName: String(row['Unit2EngName'] || '')
            });
          }
          if (units.length === 0) units.push({ name: 'حبة', factor: 1 });
        }

        finalItem = { 
          ...base, 
          type: 'item', 
          units,
          isLeaf: itemIsLeaf,
          altName: String(row[mapping.altName] || row['AltrvName'] || ''),
          vendor: String(row[mapping.vendor] || row['VendId'] || ''),
          details: String(row[mapping.details] || row['Other Details'] || ''),
          identification: String(row[mapping.identification] || row['Identification'] || ''),
        };
      } else if (type === 'accounts') {
        // IsGroup: 1 Main (not postable), 2 Branch (postable)
        const accIsPostable = String(grpLeave) === '2' || String(grpLeave).toLowerCase() === 'فرعي';
        // Resolve currency
        const currencyName = String(row[mapping.currency] || '');
        const currency = (db.settings as any)?.currencies?.find((c: any) => c.id === currencyName || c.name === currencyName);

        finalItem = { 
          ...base, 
          isLeaf: accIsPostable,
          isPostable: accIsPostable, 
          type: row[mapping.type] || 'other',
          currencyId: currency ? currency.id : ((db.settings as any)?.baseCurrency || 'YER')
        };
      } else {
        finalItem = {
          ...base,
          isLeaf: isLeaf,
        } as any;
      }

      if (type === 'warehouses' || type === 'departments') {
        const branchCode = String(row[mapping.branchCode] || '');
        const branch = (db.branches || []).find(b => b.code === branchCode);
        finalItem.branchId = branch ? branch.id : null;
      }

      importedItems.push(finalItem);
    });

    if (importedItems.length > 0) {
      // التعديل باستخدام ID بدلاً من الكود للبحث عن السجل الأصلي (Update using ID instead of Code)
      const updatedList = [...items];
      importedItems.forEach(imported => {
        const idx = updatedList.findIndex(existing => existing.id === imported.id);
        if (idx !== -1) {
          updatedList[idx] = imported;
        } else {
          // إذا لم يوجد ID مسبق، قد نحاول البحث بالكود لمرة واحدة (Fallback for new imports without IDs)
          const codeIdx = updatedList.findIndex(existing => existing.code === imported.code && !existing.id.startsWith('imported_'));
          if (codeIdx !== -1) {
            updatedList[codeIdx] = imported;
          } else {
            updatedList.push(imported);
          }
        }
      });

      onUpdateDB({ ...db, [type]: updatedList }, type, undefined, importedItems, false);
      showNotification(`✅ تم استيراد/تحديث ${importedItems.length} سجل بنجاح`);
    }
    setImportState({ show: false, headers: [], data: [], mapping: {} });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <h2 className="text-2xl font-black text-slate-900 tracking-tight">{title}</h2>
        <div className="flex flex-wrap items-center gap-3">
          <button 
            onClick={expandAll}
            className="px-4 py-2 text-[10px] font-black uppercase tracking-widest bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition-colors"
          >
            توسيع الكل
          </button>
          <button 
            onClick={collapseAll}
            className="px-4 py-2 text-[10px] font-black uppercase tracking-widest bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition-colors"
          >
            طي الكل
          </button>
          <button 
            onClick={downloadTemplate}
            className="flex items-center gap-2 px-6 py-2.5 bg-white text-slate-700 rounded-2xl font-black text-[10px] uppercase tracking-widest border border-slate-200 hover:bg-slate-50 transition-all shadow-sm active:scale-95"
          >
            <Download size={16} />
            تحميل نموذج
          </button>
          <label className="flex items-center gap-2 px-6 py-2.5 bg-white text-slate-700 rounded-2xl font-black text-[10px] uppercase tracking-widest border border-slate-200 hover:bg-slate-50 cursor-pointer transition-all shadow-sm active:scale-95">
            <Upload size={16} />
            استيراد إكسل
            <input type="file" className="hidden" accept=".xlsx,.xls" onChange={importFromExcel} />
          </label>
          <button 
            onClick={() => {
              setEditingItem(null);
              setNewItem({ code: '', name: '', isLeaf: false, parentId: '', type: 'other', units: [{ name: 'حبة', factor: 1 }] });
              setIsAdding(true);
            }}
            className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-100 transition-all active:scale-95"
          >
            <Plus size={16} />
            إضافة جديد
          </button>
        </div>
      </div>

      <div className="relative group">
        <Search className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600 transition-colors" size={22} />
        <input 
          type="text" 
          placeholder="ابحث بالاسم أو الكود..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="w-full pr-14 pl-14 py-5 rounded-[1.5rem] border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all text-xl font-bold bg-slate-50/30 focus:bg-white"
        />
        {searchQuery && (
          <button 
            onClick={() => setSearchQuery('')}
            className="absolute left-5 top-1/2 -translate-y-1/2 p-2.5 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-600 transition-all"
          >
            <X size={20} />
          </button>
        )}
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-100 overflow-hidden shadow-sm">
        {renderTree(null)}
      </div>

      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAdding(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl p-8 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-bold text-slate-900">{editingItem ? 'تعديل عنصر' : 'إضافة عنصر جديد'}</h3>
                <button onClick={() => setIsAdding(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X size={20} className="text-slate-400" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500">الكود</label>
                  <input 
                    type="text" 
                    value={newItem.code || ''}
                    onChange={e => setNewItem({...newItem, code: e.target.value})}
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500">الاسم</label>
                  <input 
                    type="text" 
                    value={newItem.name || ''}
                    onChange={e => setNewItem({...newItem, name: e.target.value})}
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500">العنصر الأب</label>
                  <select 
                    value={newItem.parentId || ''}
                    onChange={e => {
                      const pId = e.target.value || null;
                      const nextCode = generateNextCode(pId);
                      setNewItem({...newItem, parentId: pId, code: nextCode});
                    }}
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold bg-white appearance-none"
                  >
                    <option value="">بدون أب (رئيسي)</option>
                    {items.filter(i => (!i.isLeaf && !i.isPostable) && i.id !== editingItem?.id).map(i => (
                      <option key={i.id} value={i.id}>{i.name} ({i.code})</option>
                    ))}
                  </select>
                </div>
                {showType && (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500">النوع</label>
                    <select 
                      value={newItem.type || 'other'}
                      onChange={e => setNewItem({...newItem, type: e.target.value})}
                      className="w-full px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold bg-white appearance-none"
                    >
                      <option value="other">أخرى</option>
                      <option value="client">عميل</option>
                      <option value="supplier">مورد</option>
                      <option value="both">عميل ومورد</option>
                      <option value="cost">تكلفة</option>
                      <option value="revenue">ايراد</option>
                    </select>
                  </div>
                )}

                {isLinkedType && (
                  <div className="space-y-1 col-span-2">
                    <label className="text-xs font-bold text-slate-500">اربط بحساب من دليل الحسابات</label>
                    <select 
                      value={newItem.accId || ''}
                      onChange={e => setNewItem({...newItem, accId: e.target.value})}
                      className="w-full px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold bg-white appearance-none"
                    >
                      <option value="">اختر الحساب...</option>
                      {(db.accounts || []).filter(a => a.isPostable).map(a => (
                        <option key={a.id} value={a.id}>{a.name} ({a.code})</option>
                      ))}
                    </select>
                  </div>
                )}

                {type === 'items' && (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500">نوع الصنف</label>
                    <select 
                      value={newItem.type || 'item'}
                      onChange={e => setNewItem({...newItem, type: e.target.value})}
                      className="w-full px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold bg-white appearance-none"
                    >
                      <option value="item">سلعة</option>
                      <option value="service">خدمة</option>
                    </select>
                  </div>
                )}

                {(type === 'warehouses' || type === 'departments') && (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500">الفرع المرتبط</label>
                    <select 
                      value={newItem.branchId || ''}
                      onChange={e => setNewItem({...newItem, branchId: e.target.value})}
                      className="w-full px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold bg-white appearance-none"
                    >
                      <option value="">اختر الفرع...</option>
                      {(db.branches || []).filter(b => b.isLeaf).map(b => (
                        <option key={b.id} value={b.id}>{b.name}</option>
                      ))}
                    </select>
                  </div>
                )}

                {type === 'centers' && (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500">القسم المرتبط</label>
                    <select 
                      value={newItem.departmentId || ''}
                      onChange={e => setNewItem({...newItem, departmentId: e.target.value})}
                      className="w-full px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold bg-white appearance-none"
                    >
                      <option value="">اختر القسم...</option>
                      {db.departments.filter(d => d.isLeaf).map(d => (
                        <option key={d.id} value={d.id}>{d.name}</option>
                      ))}
                    </select>
                  </div>
                )}

                {type === 'accounts' && (
                  <>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500">نوع الحساب</label>
                      <select 
                        value={newItem.isPostable ? '2' : '1'}
                        onChange={e => {
                          const isSub = e.target.value === '2';
                          setNewItem({...newItem, isPostable: isSub, isLeaf: isSub});
                        }}
                        className="w-full px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold bg-white appearance-none"
                      >
                        <option value="1">مجموعة رئيسي</option>
                        <option value="2">فرعي (قابل للحركة)</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500">العملة</label>
                      <select 
                        value={newItem.currencyId || db.settings?.baseCurrency || 'YER'}
                        onChange={e => setNewItem({...newItem, currencyId: e.target.value})}
                        className="w-full px-4 py-3 rounded-2xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-bold bg-white appearance-none"
                      >
                        {(db.settings?.currencies || []).map(c => (
                          <option key={c.id} value={c.id}>{c.name} ({c.symbol})</option>
                        ))}
                      </select>
                    </div>
                  </>
                )}

                {type !== 'accounts' && (
                  <div className="col-span-2 flex items-center gap-2">
                    <input 
                      type="checkbox" 
                      id="isLeaf"
                      checked={newItem.isLeaf}
                      onChange={e => setNewItem({...newItem, isLeaf: e.target.checked})}
                      className="w-4 h-4 text-blue-600 rounded"
                    />
                    <label htmlFor="isLeaf" className="text-sm font-bold text-slate-700">عنصر نهائي (يظهر في السندات)</label>
                  </div>
                )}
              </div>

              {showUnits && newItem.isLeaf && (
                <div className="mb-6 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-500">الوحدات</label>
                    <button 
                      onClick={() => setNewItem({...newItem, units: [...(newItem.units || []), { name: '', factor: 1 }]})}
                      className="text-[10px] font-bold text-blue-600 hover:underline"
                    >
                      + إضافة وحدة
                    </button>
                  </div>
                  <div className="max-h-32 overflow-y-auto space-y-2">
                    {newItem.units?.map((u, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <input 
                          type="text" 
                          placeholder="الوحدة"
                          value={u.name || ''}
                          onChange={e => {
                            const updated = [...(newItem.units || [])];
                            updated[idx].name = e.target.value;
                            setNewItem({...newItem, units: updated});
                          }}
                          className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 text-xs"
                        />
                        <input 
                          type="number" 
                          placeholder="المعامل"
                          value={u.factor ?? 1}
                          onChange={e => {
                            const updated = [...(newItem.units || [])];
                            updated[idx].factor = parseFloat(e.target.value) || 1;
                            setNewItem({...newItem, units: updated});
                          }}
                          className="w-20 px-3 py-1.5 rounded-lg border border-slate-200 text-xs text-center"
                        />
                        {idx > 0 && (
                          <button 
                            onClick={() => setNewItem({...newItem, units: newItem.units?.filter((_, i) => i !== idx)})}
                            className="text-slate-300 hover:text-red-500"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-4 mt-4">
                <button 
                  onClick={() => setIsAdding(false)}
                  className="flex-1 px-6 py-4 rounded-2xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-all text-lg"
                >
                  إلغاء
                </button>
                <button 
                  onClick={handleSave}
                  className="flex-1 px-6 py-4 rounded-2xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 text-lg"
                >
                  حفظ التغييرات
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {importState.show && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setImportState({ ...importState, show: false })}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-xl rounded-3xl shadow-2xl p-8"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-900">ربط أعمدة الإكسل - {title}</h3>
                <button onClick={() => setImportState({ ...importState, show: false })} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X size={20} className="text-slate-400" />
                </button>
              </div>

              <div className="space-y-4 mb-8">
                <p className="text-sm text-slate-500 mb-4">قم بمطابقة حقول النظام مع أعمدة ملف الإكسل الخاص بك:</p>
                
                {[
                  { key: 'code', label: 'الكود / الرقم', required: true },
                  { key: 'name', label: 'الاسم / البيان', required: true },
                  { key: 'parentCode', label: 'كود الأب / الرئيسي', required: false },
                  ...(type === 'accounts' || type === 'items' ? [{ key: 'type', label: 'النوع', required: false }] : []),
                  ...(type === 'items' ? [{ key: 'units', label: 'الوحدات (مثل: كرتون:12,حبة:1)', required: false }] : []),
                  ...(type === 'warehouses' || type === 'departments' ? [{ key: 'branchCode', label: 'كود الفرع', required: false }] : []),
                  { key: 'isLeaf', label: 'عنصر نهائي؟', required: false }
                ].map(field => (
                  <div key={field.key} className="flex items-center justify-between gap-4">
                    <label className="text-sm font-bold text-slate-700 min-w-[120px]">
                      {field.label}
                      {field.required && <span className="text-red-500 mr-1">*</span>}
                    </label>
                    <select 
                      value={importState.mapping[field.key] || ''}
                      onChange={e => setImportState({
                        ...importState,
                        mapping: { ...importState.mapping, [field.key]: e.target.value }
                      })}
                      className="flex-1 px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-sm font-medium bg-white"
                    >
                      <option value="">-- اختر العمود --</option>
                      {(importState.headers || []).map(h => (
                        <option key={h} value={h}>{h}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => setImportState({ ...importState, show: false })}
                  className="flex-1 px-6 py-3 rounded-2xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-all"
                >
                  إلغاء
                </button>
                <button 
                  onClick={executeImport}
                  disabled={!importState.mapping.code || !importState.mapping.name}
                  className="flex-1 px-6 py-3 rounded-2xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  بدء الاستيراد
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export const Settings: React.FC<SettingsProps> = ({ db, user, onUpdateDB, showNotification, setConfirmModal, initialTab, isSuperAdmin, allCompanies }) => {
  const [activeTab, setActiveTab] = useState<'accounts' | 'centers' | 'items' | 'company' | 'backup' | 'fields' | 'branches' | 'warehouses' | 'departments' | 'users' | 'data-mgmt' | 'pricing-docs' | 'all-companies' | 'system' | 'funds' | 'banks' | 'customers-suppliers' | 'currencies' | 'fiscal-years'>(initialTab as any || 'accounts');
  const [expFrom, setExpFrom] = useState(new Date().toISOString().split('T')[0]);
  const [expTo, setExpTo] = useState(new Date().toISOString().split('T')[0]);

  const [expType, setExpType] = useState<'all' | 'issue' | 'purchase'>('all');

  const [isAddingCompany, setIsAddingCompany] = useState(false);
  const [newCompanyName, setNewCompanyName] = useState('');
  const [editingCompanyId, setEditingCompanyId] = useState<string | null>(null);
  const [editingCompanyName, setEditingCompanyName] = useState('');

  const handleAddCompany = () => {
    if (!newCompanyName.trim()) return;
    const id = `comp_${uid()}`;
    const initialSettings = { 
      company: { name: newCompanyName.trim() },
      numberingStrategy: 'branch',
      printType: 'a4',
      editGracePeriod: 720,
      maxPrintCount: 3,
      allowNegativeStock: false,
      settings: {
        issue: { linkingLevel: 'header', mandatoryFields: [] },
        purchase: { linkingLevel: 'header', mandatoryFields: [] },
        sale: { linkingLevel: 'header', mandatoryFields: [] }
      }
    };
    onUpdateDB({ ...db }, 'settings', id, initialSettings);
    setNewCompanyName('');
    setIsAddingCompany(false);
    showNotification('تم إنشاء الشركة بنجاح');
  };

  const handleUpdateCompany = (id: string) => {
    if (!editingCompanyName.trim()) return;
    onUpdateDB({ ...db }, 'settings', id, { company: { name: editingCompanyName.trim() } });
    setEditingCompanyId(null);
    setEditingCompanyName('');
    showNotification('تم تحديث اسم الشركة');
  };

  const handleDeleteCompany = (id: string, name: string) => {
    if (id === user.companyId) {
      showNotification('لا يمكن حذف الشركة التي تعمل عليها حالياً', 'error');
      return;
    }
    setConfirmModal({
      title: "حذف شركة",
      message: `هل أنت متأكد من حذف شركة "${name}"؟ سيتم حذف كافة البيانات المتعلقة بها نهائياً.`,
      onConfirm: async () => {
        try {
          // In a real app we would delete all sub-collections too
          // For now we delete from settings, and the UI filters by companyId
          onUpdateDB({ ...db }, 'settings', id, {}, true);
          showNotification("تم حذف الشركة بنجاح");
          setConfirmModal(null);
        } catch (error) {
          console.error("Delete error:", error);
          showNotification("فشل حذف الشركة", "error");
        }
      }
    });
  };

  // Company Info
  const [company, setCompany] = useState<CompanyInfo>(db.company || { name: '', phone: '', address: '', taxNumber: '', logo: '' });
  const saveCompanyInfo = async () => {
    // 1. Separate the password and sensitive fields
    const { accessPassword, ...publicCompany } = company as any;
    
    // 2. Save public info to main settings document
    onUpdateDB({ ...db }, 'settings', user.companyId, { company: publicCompany });

    // 3. Save password to restricted sub-collection if changed
    if (accessPassword !== undefined) {
      try {
        const secretsRef = doc(firestore, 'settings', user.companyId, 'secrets', 'config');
        await setDoc(secretsRef, { password: accessPassword || null }, { merge: true });
      } catch (error) {
        console.error("Failed to save secure password:", error);
        showNotification('فشل حفظ كلمة المرور - يتطلب صلاحية مدير للنظام', 'error');
      }
    }
    
    showNotification('تم حفظ بيانات الشركة بنجاح');
  };

  // Custom Fields Management
  const [newField, setNewField] = useState<Partial<FieldDefinition>>({ name: '', type: 'text', required: false, options: [] });
  const addField = () => {
    if (!newField.name) return;
    const field: FieldDefinition = {
      id: Math.random().toString(36).substr(2, 9),
      companyId: user.companyId,
      name: newField.name!,
      type: newField.type as any || 'text',
      required: !!newField.required,
      options: newField.options || [],
      order: (db.fieldDefinitions?.length || 0) + 1,
      allowedDocTypes: newField.allowedDocTypes || ['issue', 'purchase']
    };
    onUpdateDB({ ...db, fieldDefinitions: [...(db.fieldDefinitions || []), field] }, 'fieldDefinitions', field.id, field);
    setNewField({ name: '', type: 'text', required: false, options: [] });
    showNotification('تم إضافة الحقل المخصص بنجاح');
  };

  const deleteField = (id: string) => {
    setConfirmModal({
      title: "حذف حقل مخصص",
      message: "هل أنت متأكد من حذف هذا الحقل؟ سيتم حذف بياناته من كافة السندات.",
      onConfirm: () => {
        const fieldToDelete = db.fieldDefinitions?.find(f => f.id === id);
        onUpdateDB({ ...db, fieldDefinitions: db.fieldDefinitions?.filter(f => f.id !== id) }, 'fieldDefinitions', id, fieldToDelete, true);
        showNotification("تم حذف الحقل بنجاح");
        setConfirmModal(null);
      }
    });
  };

  // Branch Management
  const [newBranch, setNewBranch] = useState({ code: '', name: '' });
  const addBranch = () => {
    if (!newBranch.code || !newBranch.name) return;
    const branch: Branch = { 
      id: Math.random().toString(36).substr(2, 9), 
      companyId: user.companyId,
      code: newBranch.code,
      name: newBranch.name,
      parentId: null,
      level: 1,
      isLeaf: true
    };
    onUpdateDB({ ...db, branches: [...(db.branches || []), branch] }, 'branches', branch.id, branch);
    setNewBranch({ code: '', name: '' });
  };

  // Warehouse Management
  const [newWarehouse, setNewWarehouse] = useState({ code: '', name: '', branchId: '' });
  const addWarehouse = () => {
    if (!newWarehouse.code || !newWarehouse.name || !newWarehouse.branchId) return;
    const warehouse: Warehouse = { 
      id: Math.random().toString(36).substr(2, 9), 
      companyId: user.companyId,
      branchId: newWarehouse.branchId,
      code: newWarehouse.code,
      name: newWarehouse.name,
      parentId: null,
      level: 1,
      isLeaf: true
    };
    onUpdateDB({ ...db, warehouses: [...(db.warehouses || []), warehouse] }, 'warehouses', warehouse.id, warehouse);
    setNewWarehouse({ code: '', name: '', branchId: '' });
  };

  // User Management
  const [newUser, setNewUser] = useState<Partial<User>>({ 
    name: '', 
    email: '',
    password: '', 
    role: 'user', 
    isActive: true, 
    companyId: user.companyId,
    allowedBranches: [], 
    allowedWarehouses: [], 
    allowedCenters: [], 
    allowedAccounts: [], 
    printType: 'a4', 
    editGracePeriod: 0, 
    maxPrintCount: 0,
    canCreatePurchase: true,
    canEditPurchase: true,
    canDeletePurchase: false,
    canCreateSale: true,
    canEditSale: true,
    canDeleteSale: false,
    canCreateIssue: true,
    canEditIssue: true,
    canDeleteIssue: false,
    canManagePricing: false,
    canManageAccounts: false,
    canManageItems: false,
    canManageBranches: false,
    canManageWarehouses: false,
    canManageDepartments: false,
    canManageCenters: false
  });
  const [editingUserId, setEditingUserId] = useState<string | null>(null);

  const saveUser = () => {
    if (!newUser.name || (!editingUserId && !newUser.password)) return;
    
    if (editingUserId) {
      // يتم التعديل باستخدام المعرف id (Edit using ID)
      const userToUpdate = { 
        ...db.users.find(u => u.id === editingUserId), 
        ...newUser,
        password: newUser.password || db.users.find(u => u.id === editingUserId)?.password // Keep old password if not changed
      } as User;
      const updatedUsers = (db.users || []).map(u => u.id === editingUserId ? userToUpdate : u);
      onUpdateDB({ ...db, users: updatedUsers }, 'users', editingUserId, userToUpdate);
      showNotification('تم تحديث بيانات المستخدم بنجاح');
    } else {
      // توليد معرف فريد عند الإضافة (Generate unique ID on create)
      const newUserObj: User = { 
        id: uid(), 
        companyId: newUser.companyId || user.companyId,
        name: newUser.name!, 
        email: newUser.email || '',
        password: newUser.password!, 
        role: newUser.role as any || 'user',
        isActive: true,
        allowedBranches: newUser.allowedBranches || [],
        allowedWarehouses: newUser.allowedWarehouses || [],
        allowedCenters: newUser.allowedCenters || [],
        allowedAccounts: newUser.allowedAccounts || [],
        canCreatePurchase: newUser.canCreatePurchase || false,
        canEditPurchase: newUser.canEditPurchase || false,
        canDeletePurchase: newUser.canDeletePurchase || false,
        canCreateSale: newUser.canCreateSale || false,
        canEditSale: newUser.canEditSale || false,
        canDeleteSale: newUser.canDeleteSale || false,
        canCreateIssue: newUser.canCreateIssue || false,
        canEditIssue: newUser.canEditIssue || false,
        canDeleteIssue: newUser.canDeleteIssue || false,
        canManagePricing: newUser.canManagePricing || false,
        canCreateJournal: newUser.canCreateJournal || false,
        canEditJournal: newUser.canEditJournal || false,
        canDeleteJournal: newUser.canDeleteJournal || false,
        canCreateCashBank: newUser.canCreateCashBank || false,
        canEditCashBank: newUser.canEditCashBank || false,
        canDeleteCashBank: newUser.canDeleteCashBank || false,
        canManageAccounts: newUser.canManageAccounts || false,
        canManageItems: newUser.canManageItems || false,
        canManageBranches: newUser.canManageBranches || false,
        canManageWarehouses: newUser.canManageWarehouses || false,
        canManageDepartments: newUser.canManageDepartments || false,
        canManageCenters: newUser.canManageCenters || false,
        canManageFunds: newUser.canManageFunds || false,
        canManageBanks: newUser.canManageBanks || false,
        canManageCustomersSuppliers: newUser.canManageCustomersSuppliers || false,
        canManageCurrencies: newUser.canManageCurrencies || false,
        canViewReports: newUser.canViewReports || false,
        printType: newUser.printType || 'a4',
        editGracePeriod: newUser.editGracePeriod || 0,
        maxPrintCount: newUser.maxPrintCount || 0
      };
      onUpdateDB({ ...db, users: [...(db.users || []), newUserObj] }, 'users', newUserObj.id, newUserObj);
      showNotification('تم إضافة المستخدم بنجاح');
    }
    setNewUser({ name: '', email: '', password: '', role: 'user', isActive: true, companyId: user.companyId, allowedBranches: [], allowedWarehouses: [], allowedCenters: [], allowedAccounts: [], printType: 'a4', editGracePeriod: 0, maxPrintCount: 0 });
    setEditingUserId(null);
  };

  const toggleUserStatus = (id: string) => {
    const userToUpdate = db.users.find(u => u.id === id);
    if (!userToUpdate) return;
    const updatedUser = { ...userToUpdate, isActive: !userToUpdate.isActive };
    const updatedUsers = (db.users || []).map(u => u.id === id ? updatedUser : u);
    onUpdateDB({ ...db, users: updatedUsers }, 'users', id, updatedUser);
    showNotification('تم تغيير حالة المستخدم');
  };

  const editUser = (user: User) => {
    setNewUser({ ...user, password: '' }); // Don't show password
    setEditingUserId(user.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const toggleUserPermission = (field: keyof User, value: string) => {
    setNewUser(prev => {
      const current = (prev[field] as string[]) || [];
      const updated = current.includes(value) 
        ? current.filter(v => v !== value) 
        : [...current, value];
      return { ...prev, [field]: updated };
    });
  };

  const moveField = (id: string, direction: 'up' | 'down') => {
    const fields = [...(db.fieldDefinitions || [])].sort((a, b) => a.order - b.order);
    const idx = fields.findIndex(f => f.id === id);
    if (direction === 'up' && idx > 0) {
      [fields[idx].order, fields[idx-1].order] = [fields[idx-1].order, fields[idx].order];
    } else if (direction === 'down' && idx < fields.length - 1) {
      [fields[idx].order, fields[idx+1].order] = [fields[idx+1].order, fields[idx].order];
    }
    onUpdateDB({ ...db, fieldDefinitions: fields }, 'fieldDefinitions', undefined, fields);
  };

  const deleteEntry = (type: 'accounts' | 'centers' | 'items' | 'branches' | 'warehouses' | 'departments' | 'users' | 'fiscalYears' | 'currencies' | 'pricingDocs', id: string) => {
    setConfirmModal({
      title: "تأكيد الحذف",
      message: "هل أنت متأكد من الحذف؟ قد يؤثر هذا على السندات المسجلة.",
      onConfirm: () => {
        const itemToDelete = (db as any)[type].find((x: any) => x.id === id);
        onUpdateDB({ ...db, [type]: (db as any)[type].filter((x: any) => x.id !== id) }, type, id, itemToDelete, true);
        showNotification("تم الحذف بنجاح");
        setConfirmModal(null);
      }
    });
  };

  const exportData = () => {
    const dataStr = JSON.stringify(db, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `accounting_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  };

  const seedSampleData = async () => {
    const targetCompanyId = user.companyId;
    if (!targetCompanyId) return;
    
    const sampleAccounts: Partial<Account>[] = [
      { code: '1', name: 'الأصول', parentId: null, level: 1, isPostable: false, type: 'other' },
      { code: '11', name: 'الأصول المتداولة', parentId: '1', level: 2, isPostable: false, type: 'other' },
      { code: '111', name: 'الصندوق الرئيسي', parentId: '11', level: 3, isPostable: true, type: 'other' },
      { code: '112', name: 'البنك', parentId: '11', level: 3, isPostable: true, type: 'other' },
      { code: '2', name: 'الخصوم', parentId: null, level: 1, isPostable: false, type: 'other' },
      { code: '21', name: 'الموردون', parentId: '2', level: 2, isPostable: false, type: 'supplier' },
      { code: '211', name: 'شركة التقنية الحديثة', parentId: '21', level: 3, isPostable: true, type: 'supplier' },
      { code: '3', name: 'المصروفات', parentId: null, level: 1, isPostable: false, type: 'other' },
      { code: '31', name: 'مشتريات بضاعة', parentId: '3', level: 2, isPostable: true, type: 'cost' }
    ];

    const sampleItems: Partial<Item>[] = [
      { 
        code: '101', name: 'لابتوب ديل XPS', parentId: null, level: 1, isLeaf: true, type: 'item',
        units: [{ name: 'حبة', factor: 1 }, { name: 'كرتون', factor: 10 }],
        defaultPurchaseUnit: 'كرتون', defaultSaleUnit: 'حبة'
      },
      { 
        code: '102', name: 'شاشة سامسونج 27', parentId: null, level: 1, isLeaf: true, type: 'item',
        units: [{ name: 'حبة', factor: 1 }],
        defaultPurchaseUnit: 'حبة', defaultSaleUnit: 'حبة'
      }
    ];

    const sampleCenters: Partial<CostCenter>[] = [
      { code: '1', name: 'الإدارة العامة', parentId: null, level: 1, isLeaf: true },
      { code: '2', name: 'فرع الرياض', parentId: null, level: 1, isLeaf: true }
    ];

    try {
      // Helper to map codes to generated IDs
      const accIdMap: Record<string, string> = {};
      
      // Seed Accounts
      for (const acc of sampleAccounts) {
        const id = uid();
        accIdMap[acc.code!] = id;
        const parentId = acc.parentId ? accIdMap[acc.parentId] : null;
        await setDoc(doc(firestore, 'accounts', id), { ...acc, id, parentId, companyId: targetCompanyId });
      }

      // Seed Items
      for (const item of sampleItems) {
        const id = uid();
        await setDoc(doc(firestore, 'items', id), { ...item, id, companyId: targetCompanyId });
      }

      // Seed Centers
      for (const center of sampleCenters) {
        const id = uid();
        await setDoc(doc(firestore, 'centers', id), { ...center, id, companyId: targetCompanyId });
      }

      showNotification('✅ تم استيراد البيانات التجريبية بنجاح');
    } catch (error) {
      showNotification('❌ فشل استيراد البيانات التجريبية', 'error');
    }
  };

  const runExport = () => {
    if (!expFrom || !expTo) {
      showNotification("يرجى تحديد الفترة", 'warning');
      return;
    }
    
    const filteredDocs = db.docs.filter(d => d.date >= expFrom && d.date <= expTo && (expType === 'all' || d.type === expType));
    if (filteredDocs.length === 0) {
      showNotification("لا توجد بيانات لهذه الفترة", 'warning');
      return;
    }

    // إضافة عمود "البيان" في الترويسة
    let csvContent = "\uFEFFالنطاق;رقم_الصنف;رقم_الوحدة;الكمية;السعر;التاريخ;الحساب;المرجع;البيان\n";

    filteredDocs.forEach(doc => {
      const acc = db.accounts.find(a => a.id === doc.accId) || { name: '' };
      const rangeName = `R_${doc.ref}`;
      
      // --- منطق استخراج البيان ---
      const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
      const dateObj = new Date(doc.date);
      const dayName = days[dateObj.getDay()];
      const formattedDate = doc.date.replace(/-/g, '/');

      let partName = "";
      const accountName = acc.name;
      if (accountName.includes("مبيعات")) {
        partName = accountName.split("مبيعات")[1].trim();
      } else if (accountName.includes("تكلفة")) {
        partName = accountName.split("تكلفة")[1].trim();
      } else {
        partName = accountName;
      }
      
      const specificName = partName.split(" ")[0];
      const bayan = `${specificName} ${dayName}_${formattedDate}`;
      // ---------------------------

      // صف العناوين (الحماية)
      csvContent += `${rangeName};رقم الصنف;رقم الوحدة;الكمية;0;${doc.date};${acc.name};${doc.ref};${bayan}\n`;

      doc.items.forEach(item => {
        const itemObj = db.items.find(i => i.id === item.itemId) || { code: '0' };
        let uIdx = (itemObj as any).units ? (itemObj as any).units.findIndex((u: any) => u.name === item.unit) + 1 : 1;
        if (uIdx <= 0) uIdx = 1;
        
        const row = [rangeName, itemObj.code, uIdx, item.qty, "0", doc.date, acc.name, doc.ref, bayan];
        csvContent += row.join(';') + "\n";
      });
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `سندات_مجمعة_${expFrom}.csv`);
    link.click();
    showNotification("تم تصدير البيانات بنجاح");
  };

  const copyVBACode = () => {
    const vbaCode = `Sub AutoCreateRanges()
    Dim lastRow As Long, i As Long, startRow As Long
    lastRow = Cells(Rows.Count, 1).End(xlUp).Row
    startRow = 2
    On Error Resume Next
    Dim nm As Name
    For Each nm In ThisWorkbook.Names: nm.Delete: Next nm
    For i = 2 To lastRow + 1
        If Cells(i, 1).Value <> Cells(startRow, 1).Value Then
            Range("B" & startRow & ":E" & i - 1).Name = Cells(startRow, 1).Value
            startRow = i
        End If
    Next i
    MsgBox "Success! All ranges have been created.", vbInformation, "System"
End Sub`;

    navigator.clipboard.writeText(vbaCode).then(() => {
      showNotification("✅ تم نسخ الكود بنجاح! اذهب إلى إكسل والصقه.");
    }).catch(() => {
      // Fallback
      const el = document.createElement('textarea');
      el.value = vbaCode;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      showNotification("✅ تم نسخ الكود بنجاح! اذهب إلى إكسل والصقه.");
    });
  };

  const importData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target?.result as string);
        if (imported.accounts && imported.items && imported.docs) {
          onUpdateDB(imported);
          showNotification('تم استيراد البيانات بنجاح');
        }
      } catch (err) {
        showNotification('خطأ في تنسيق الملف', 'error');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-20">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-900 flex items-center justify-center text-white shadow-xl shadow-slate-200">
            <SettingsIcon size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">إعدادات النظام</h1>
            <p className="text-slate-500 font-medium mt-0.5">إدارة الحسابات، الأصناف، الفروع، والمستخدمين</p>
          </div>
        </div>
        {isSuperAdmin && (
          <div className="px-4 py-2 bg-amber-50 border border-amber-100 rounded-2xl flex items-center gap-2 text-amber-700 shadow-sm self-start sm:self-auto">
            <Shield size={18} className="text-amber-500" />
            <span className="text-xs font-black uppercase tracking-widest">مدير عام النظام</span>
          </div>
        )}
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="flex overflow-x-auto no-scrollbar border-b border-slate-50 p-2 bg-slate-50/50">
          {[
            { id: 'company', label: 'الشركة', icon: Building },
            { id: 'fiscal-years', label: 'السنوات المالية', icon: Calendar },
            { id: 'accounts', label: 'الحسابات', icon: Database },
            { id: 'customers-suppliers', label: 'العملاء والموردين', icon: Users },
            { id: 'funds', label: 'الصناديق', icon: Database },
            { id: 'banks', label: 'البنوك', icon: Building },
            { id: 'items', label: 'الأصناف', icon: Package },
            { id: 'pricing-docs', label: 'قوائم الأسعار', icon: TrendingUp },
            { id: 'centers', label: 'مراكز التكلفة', icon: BarChart3 },
            { id: 'branches', label: 'الفروع', icon: Folder },
            { id: 'warehouses', label: 'المخازن', icon: Folder },
            { id: 'departments', label: 'الأقسام', icon: Folder },
            { id: 'fields', label: 'الحقول الإضافية', icon: FileJson },
            { id: 'users', label: 'المستخدمين', icon: Shield },
            { id: 'data-mgmt', label: 'إدارة البيانات', icon: FileSpreadsheet },
            { id: 'backup', label: 'النسخ الاحتياطي', icon: Download },
            ...(isSuperAdmin ? [{ id: 'all-companies', label: 'إدارة الشركات', icon: Building }] : []),
            ...(isSuperAdmin ? [{ id: 'system', label: 'إعدادات النظام', icon: SettingsIcon }] : [])
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest transition-all whitespace-nowrap ${
                activeTab === tab.id 
                  ? 'bg-white text-blue-600 shadow-sm border border-slate-100' 
                  : 'text-slate-400 hover:text-slate-600 hover:bg-white/50'
              }`}
            >
              <tab.icon size={16} />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
            {activeTab === 'accounts' && (
              <DirectoryTree 
                items={db.accounts}
                onUpdate={(accounts, item, isDelete) => {
                  onUpdateDB({ ...db, accounts }, 'accounts', item.id, item, isDelete);
                }}
                title="دليل الحسابات"
                type="accounts"
                db={db}
                showType
                companyId={user.companyId}
                showNotification={showNotification}
                setConfirmModal={setConfirmModal}
                onUpdateDB={onUpdateDB}
              />
            )}

            {activeTab === 'centers' && (
              <DirectoryTree 
                items={db.centers}
                onUpdate={(centers, item, isDelete) => {
                  onUpdateDB({ ...db, centers }, 'centers', item.id, item, isDelete);
                }}
                title="دليل مراكز التكلفة"
                type="centers"
                db={db}
                companyId={user.companyId}
                showNotification={showNotification}
                setConfirmModal={setConfirmModal}
                onUpdateDB={onUpdateDB}
              />
            )}

            {activeTab === 'items' && (
              <DirectoryTree 
                items={db.items}
                onUpdate={(items, item, isDelete) => {
                  onUpdateDB({ ...db, items }, 'items', item.id, item, isDelete);
                }}
                title="دليل الأصناف"
                type="items"
                db={db}
                showUnits
                companyId={user.companyId}
                showNotification={showNotification}
                setConfirmModal={setConfirmModal}
                onUpdateDB={onUpdateDB}
              />
            )}

            {activeTab === 'departments' && (
              <DirectoryTree 
                items={db.departments}
                onUpdate={(departments, item, isDelete) => {
                  onUpdateDB({ ...db, departments }, 'departments', item.id, item, isDelete);
                }}
                title="دليل الأقسام"
                type="departments"
                db={db}
                companyId={user.companyId}
                showNotification={showNotification}
                setConfirmModal={setConfirmModal}
                onUpdateDB={onUpdateDB}
              />
            )}

            {activeTab === 'branches' && (
              <DirectoryTree 
                items={db.branches}
                onUpdate={(branches, item, isDelete) => {
                  onUpdateDB({ ...db, branches }, 'branches', item.id, item, isDelete);
                }}
                title="دليل الفروع"
                type="branches"
                db={db}
                companyId={user.companyId}
                showNotification={showNotification}
                setConfirmModal={setConfirmModal}
                onUpdateDB={onUpdateDB}
              />
            )}

            {activeTab === 'warehouses' && (
              <DirectoryTree 
                items={db.warehouses}
                onUpdate={(warehouses, item, isDelete) => {
                  onUpdateDB({ ...db, warehouses }, 'warehouses', item.id, item, isDelete);
                }}
                title="دليل المخازن"
                type="warehouses"
                db={db}
                companyId={user.companyId}
                showNotification={showNotification}
                setConfirmModal={setConfirmModal}
                onUpdateDB={onUpdateDB}
              />
            )}

            {activeTab === 'funds' && (
              <DirectoryTree 
                title="دليل الصناديق" 
                type="funds"
                items={db.funds || []} 
                onUpdate={(updated, item, isDelete) => onUpdateDB({ ...db, funds: updated }, 'funds', item.id, item, isDelete)}
                db={db}
                companyId={user.companyId}
                showNotification={showNotification}
                setConfirmModal={setConfirmModal}
                onUpdateDB={onUpdateDB}
              />
            )}

            {activeTab === 'banks' && (
              <DirectoryTree 
                title="دليل البنوك" 
                type="banks"
                items={db.banks || []} 
                onUpdate={(updated, item, isDelete) => onUpdateDB({ ...db, banks: updated }, 'banks', item.id, item, isDelete)}
                db={db}
                companyId={user.companyId}
                showNotification={showNotification}
                setConfirmModal={setConfirmModal}
                onUpdateDB={onUpdateDB}
              />
            )}

            {activeTab === 'customers-suppliers' && (
              <DirectoryTree 
                title="دليل العملاء والموردين" 
                type="customers-suppliers"
                items={db.customersSuppliers || []} 
                onUpdate={(updated, item, isDelete) => onUpdateDB({ ...db, customersSuppliers: updated }, 'customers-suppliers', item.id, item, isDelete)}
                db={db}
                companyId={user.companyId}
                showNotification={showNotification}
                setConfirmModal={setConfirmModal}
                onUpdateDB={onUpdateDB}
              />
            )}

            {activeTab === 'pricing-docs' && (
              <div className="space-y-8">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-slate-800">مستندات تسعير الأصناف</h2>
                  <button 
                    onClick={() => {
                      const newDoc: PricingDoc = {
                        id: Math.random().toString(36).substr(2, 9),
                        companyId: user.companyId,
                        date: new Date().toISOString().split('T')[0],
                        type: 'retail',
                        description: '',
                        items: [],
                        createdAt: new Date().toISOString(),
                        createdBy: user.id
                      };
                      onUpdateDB({ ...db, pricingDocs: [...(db.pricingDocs || []), newDoc] }, 'pricingDocs', newDoc.id, newDoc);
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-bold text-xs shadow-lg shadow-blue-100 transition-all"
                  >
                    <Plus size={16} />
                    مستند تسعير جديد
                  </button>
                </div>

                <div className="space-y-4">
                  {(db.pricingDocs || []).map(doc => (
                    <div key={doc.id} className="bg-slate-50 p-6 rounded-2xl border border-slate-100 space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-500">التاريخ</label>
                          <input 
                            type="date" 
                            value={doc.date}
                            onChange={e => {
                              const updatedItem = { ...doc, date: e.target.value };
                              const updated = db.pricingDocs.map(d => d.id === doc.id ? updatedItem : d);
                              onUpdateDB({ ...db, pricingDocs: updated }, 'pricingDocs', doc.id, updatedItem);
                            }}
                            className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-500">نوع التسعيرة</label>
                          <select 
                            value={doc.type}
                            onChange={e => {
                              const updatedItem = { ...doc, type: e.target.value as any };
                              const updated = db.pricingDocs.map(d => d.id === doc.id ? updatedItem : d);
                              onUpdateDB({ ...db, pricingDocs: updated }, 'pricingDocs', doc.id, updatedItem);
                            }}
                            className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                          >
                            <option value="retail">تجزئة</option>
                            <option value="wholesale">جملة</option>
                            <option value="internal">فروع داخلية</option>
                            <option value="external">فروع خارجية</option>
                          </select>
                        </div>
                        <div className="flex items-end">
                          <button 
                            onClick={() => {
                              const updated = db.pricingDocs.filter(d => d.id !== doc.id);
                              onUpdateDB({ ...db, pricingDocs: updated }, 'pricingDocs', doc.id, doc, true);
                            }}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-xl transition-all"
                          >
                            <Trash2 size={20} />
                          </button>
                        </div>
                      </div>

                      <div className="bg-white rounded-xl border border-slate-100 overflow-hidden">
                        <table className="w-full text-xs">
                          <thead className="bg-slate-50">
                            <tr>
                              <th className="p-3 text-right">الصنف</th>
                              <th className="p-3 text-right">الوحدة</th>
                              <th className="p-3 text-right">السعر</th>
                              <th className="p-3 w-10"></th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-50">
                            {(doc.items || []).map((item, idx) => (
                              <tr key={idx}>
                                <td className="p-2">
                                  <select 
                                    value={item.itemId}
                                    onChange={e => {
                                      const updatedItems = [...doc.items];
                                      updatedItems[idx].itemId = e.target.value;
                                      const updatedDoc = { ...doc, items: updatedItems };
                                      const updatedDocs = db.pricingDocs.map(d => d.id === doc.id ? updatedDoc : d);
                                      onUpdateDB({ ...db, pricingDocs: updatedDocs }, 'pricingDocs', doc.id, updatedDoc);
                                    }}
                                    className="w-full p-1 border rounded"
                                  >
                                    <option value="">اختر صنف...</option>
                                    {db.items.filter(i => i.isLeaf).map(i => (
                                      <option key={i.id} value={i.id}>{i.name}</option>
                                    ))}
                                  </select>
                                </td>
                                <td className="p-2">
                                  <select 
                                    value={item.unit}
                                    onChange={e => {
                                      const updatedItems = [...(doc.items || [])];
                                      updatedItems[idx].unit = e.target.value;
                                      const updatedDoc = { ...doc, items: updatedItems };
                                      const updatedDocs = (db.pricingDocs || []).map(d => d.id === doc.id ? updatedDoc : d);
                                      onUpdateDB({ ...db, pricingDocs: updatedDocs }, 'pricingDocs', doc.id, updatedDoc);
                                    }}
                                    className="w-full p-1 border rounded"
                                  >
                                    <option value="">اختر وحدة...</option>
                                    {(db.items.find(i => i.id === item.itemId)?.units || []).map(u => (
                                      <option key={u.name} value={u.name}>{u.name}</option>
                                    ))}
                                  </select>
                                </td>
                                <td className="p-2">
                                  <input 
                                    type="number" 
                                    value={item.price}
                                    onChange={e => {
                                      const updatedItems = [...doc.items];
                                      updatedItems[idx].price = parseFloat(e.target.value) || 0;
                                      const updatedDoc = { ...doc, items: updatedItems };
                                      const updatedDocs = db.pricingDocs.map(d => d.id === doc.id ? updatedDoc : d);
                                      onUpdateDB({ ...db, pricingDocs: updatedDocs }, 'pricingDocs', doc.id, updatedDoc);
                                    }}
                                    className="w-full p-1 border rounded text-center"
                                  />
                                </td>
                                <td className="p-2">
                                  <button 
                                    onClick={() => {
                                      const updatedItems = doc.items.filter((_, i) => i !== idx);
                                      const updatedDoc = { ...doc, items: updatedItems };
                                      const updatedDocs = db.pricingDocs.map(d => d.id === doc.id ? updatedDoc : d);
                                      onUpdateDB({ ...db, pricingDocs: updatedDocs }, 'pricingDocs', doc.id, updatedDoc);
                                    }}
                                    className="text-red-300 hover:text-red-500"
                                  >
                                    <Trash2 size={14} />
                                  </button>
                                </td>
                              </tr>
                            ))}
                            <tr>
                              <td colSpan={4} className="p-2">
                                <button 
                                  onClick={() => {
                                    const newItem = { itemId: '', unit: '', price: 0 };
                                    const updatedItems = [...(doc.items || []), newItem];
                                    const updatedDocs = (db.pricingDocs || []).map(d => d.id === doc.id ? { ...d, items: updatedItems } : d);
                                    onUpdateDB({ ...db, pricingDocs: updatedDocs });
                                  }}
                                  className="w-full py-2 border-2 border-dashed border-slate-100 text-slate-400 hover:border-blue-200 hover:text-blue-500 rounded-xl transition-all text-[10px] font-bold"
                                >
                                  + إضافة صنف للقائمة
                                </button>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ))}
                  {(!db.pricingDocs || db.pricingDocs.length === 0) && (
                    <div className="text-center py-12 text-slate-400">
                      <TrendingUp size={48} className="mx-auto mb-4 opacity-10" />
                      <p>لا توجد مستندات تسعير مضافة</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'users' && (
              <div className="space-y-8">
                <div className="bg-slate-50 p-6 rounded-2xl space-y-6 border border-slate-100">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-slate-800">{editingUserId ? 'تعديل بيانات المستخدم' : 'إضافة مستخدم جديد'}</h3>
                    {editingUserId && (
                      <button 
                        onClick={() => { setEditingUserId(null); setNewUser({ name: '', password: '', role: 'user', isActive: true, allowedBranches: [], allowedWarehouses: [], allowedCenters: [], allowedAccounts: [], printType: 'a4', editGracePeriod: 0, maxPrintCount: 0 }); }}
                        className="text-xs text-red-500 font-bold hover:underline"
                      >
                        إلغاء التعديل
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">اسم المستخدم</label>
                      <input 
                        type="text" 
                        placeholder="اسم المستخدم"
                        value={newUser.name || ''}
                        onChange={e => setNewUser({...newUser, name: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">{editingUserId ? 'كلمة السر الجديدة (اتركها فارغة لعدم التغيير)' : 'كلمة السر'}</label>
                      <input 
                        type="password" 
                        placeholder="••••"
                        value={newUser.password || ''}
                        onChange={e => setNewUser({...newUser, password: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">البريد الإلكتروني (للدخول بواسطة Google)</label>
                      <input 
                        type="email" 
                        placeholder="example@gmail.com"
                        value={newUser.email || ''}
                        onChange={e => setNewUser({...newUser, email: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    {isSuperAdmin && (
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500">الشركة</label>
                        <select 
                          value={newUser.companyId || user.companyId}
                          onChange={e => setNewUser({...newUser, companyId: e.target.value})}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                        >
                          {allCompanies?.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>
                    )}
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">الدور</label>
                      <select 
                        value={newUser.role || 'user'}
                        onChange={e => setNewUser({...newUser, role: e.target.value as any})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value="user">مستخدم (صلاحيات محدودة)</option>
                        <option value="admin">مدير (صلاحيات كاملة)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">نوع المطبوع الافتراضي</label>
                      <select 
                        value={newUser.printType || 'a4'}
                        onChange={e => setNewUser({...newUser, printType: e.target.value as any})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value="a4">A4 (عادي)</option>
                        <option value="pos">POS (حراري)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">وقت سماح التعديل (بالدقائق)</label>
                      <input 
                        type="number" 
                        value={newUser.editGracePeriod || 0}
                        onChange={e => setNewUser({...newUser, editGracePeriod: parseInt(e.target.value) || 0})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">أقصى عدد مرات طباعة</label>
                      <input 
                        type="number" 
                        value={newUser.maxPrintCount || 0}
                        onChange={e => setNewUser({...newUser, maxPrintCount: parseInt(e.target.value) || 0})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  {newUser.role === 'user' && (
                    <div className="space-y-6 pt-4 border-t border-slate-200">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div className="space-y-3">
                          <label className="text-xs font-bold text-slate-500">الفروع المسموحة</label>
                          <div className="max-h-32 overflow-y-auto p-2 bg-white rounded-xl border border-slate-200 space-y-1">
                            {db.branches?.map(b => (
                              <label key={b.id} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-slate-50 p-1 rounded">
                                <input 
                                  type="checkbox" 
                                  checked={newUser.allowedBranches?.includes(b.id) || false}
                                  onChange={() => toggleUserPermission('allowedBranches', b.id)}
                                  className="w-4 h-4 text-blue-600 rounded"
                                />
                                {b.name}
                              </label>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-3">
                          <label className="text-xs font-bold text-slate-500">المخازن المسموحة</label>
                          <div className="max-h-32 overflow-y-auto p-2 bg-white rounded-xl border border-slate-200 space-y-1">
                            {db.warehouses?.map(w => (
                              <label key={w.id} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-slate-50 p-1 rounded">
                                <input 
                                  type="checkbox" 
                                  checked={newUser.allowedWarehouses?.includes(w.id) || false}
                                  onChange={() => toggleUserPermission('allowedWarehouses', w.id)}
                                  className="w-4 h-4 text-blue-600 rounded"
                                />
                                {w.name}
                              </label>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-3">
                          <label className="text-xs font-bold text-slate-500">المراكز المسموحة</label>
                          <div className="max-h-32 overflow-y-auto p-2 bg-white rounded-xl border border-slate-200 space-y-1">
                            {db.centers?.map(c => (
                              <label key={c.id} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-slate-50 p-1 rounded">
                                <input 
                                  type="checkbox" 
                                  checked={newUser.allowedCenters?.includes(c.id) || false}
                                  onChange={() => toggleUserPermission('allowedCenters', c.id)}
                                  className="w-4 h-4 text-blue-600 rounded"
                                />
                                {c.name}
                              </label>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-3">
                          <label className="text-xs font-bold text-slate-500">الحسابات المسموحة</label>
                          <div className="max-h-32 overflow-y-auto p-2 bg-white rounded-xl border border-slate-200 space-y-1">
                            {db.accounts?.map(a => (
                              <label key={a.id} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-slate-50 p-1 rounded">
                                <input 
                                  type="checkbox" 
                                  checked={newUser.allowedAccounts?.includes(a.id) || false}
                                  onChange={() => toggleUserPermission('allowedAccounts', a.id)}
                                  className="w-4 h-4 text-blue-600 rounded"
                                />
                                {a.name}
                              </label>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                        <div className="space-y-4">
                          <h4 className="text-sm font-bold text-slate-800 border-b pb-2">صلاحيات السندات</h4>
                          <div className="grid grid-cols-2 gap-3">
                            {[
                              { id: 'canCreatePurchase', label: 'إنشاء مشتريات' },
                              { id: 'canEditPurchase', label: 'تعديل مشتريات' },
                              { id: 'canDeletePurchase', label: 'حذف مشتريات' },
                              { id: 'canCreateSale', label: 'إنشاء مبيعات' },
                              { id: 'canEditSale', label: 'تعديل مبيعات' },
                              { id: 'canDeleteSale', label: 'حذف مبيعات' },
                              { id: 'canCreateIssue', label: 'إنشاء صرف' },
                              { id: 'canEditIssue', label: 'تعديل صرف' },
                              { id: 'canDeleteIssue', label: 'حذف صرف' },
                              { id: 'canManagePricing', label: 'إدارة التسعير' },
                              { id: 'canCreateJournal', label: 'إنشاء قيود' },
                              { id: 'canEditJournal', label: 'تعديل قيود' },
                              { id: 'canDeleteJournal', label: 'حذف قيود' },
                              { id: 'canCreateCashBank', label: 'إنشاء نقدية/بنوك' },
                              { id: 'canEditCashBank', label: 'تعديل نقدية/بنوك' },
                              { id: 'canDeleteCashBank', label: 'حذف نقدية/بنوك' },
                            ].map(p => (
                              <label key={p.id} className="flex items-center gap-2 text-xs cursor-pointer">
                                <input 
                                  type="checkbox" 
                                  checked={!!(newUser as any)[p.id]}
                                  onChange={e => setNewUser({...newUser, [p.id]: e.target.checked})}
                                  className="w-4 h-4 text-blue-600 rounded"
                                />
                                {p.label}
                              </label>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-4">
                          <h4 className="text-sm font-bold text-slate-800 border-b pb-2">صلاحيات الأدلة</h4>
                          <div className="grid grid-cols-2 gap-3">
                            {[
                              { id: 'canManageAccounts', label: 'إدارة الحسابات' },
                              { id: 'canManageItems', label: 'إدارة الأصناف' },
                              { id: 'canManageBranches', label: 'إدارة الفروع' },
                              { id: 'canManageWarehouses', label: 'إدارة المخازن' },
                              { id: 'canManageDepartments', label: 'إدارة الأقسام' },
                              { id: 'canManageCenters', label: 'إدارة المراكز' },
                              { id: 'canManageFunds', label: 'إدارة الصناديق' },
                              { id: 'canManageBanks', label: 'إدارة البنوك' },
                              { id: 'canManageCustomersSuppliers', label: 'إدارة العملاء/الموردين' },
                              { id: 'canManageCurrencies', label: 'إدارة العملات' },
                              { id: 'canManageFiscalYears', label: 'إدارة السنوات المالية' },
                              { id: 'canViewReports', label: 'عرض التقارير' },
                            ].map(p => (
                              <label key={p.id} className="flex items-center gap-2 text-xs cursor-pointer">
                                <input 
                                  type="checkbox" 
                                  checked={!!(newUser as any)[p.id]}
                                  onChange={e => setNewUser({...newUser, [p.id]: e.target.checked})}
                                  className="w-4 h-4 text-blue-600 rounded"
                                />
                                {p.label}
                              </label>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  <button 
                    onClick={saveUser}
                    className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 flex items-center justify-center gap-2"
                  >
                    {editingUserId ? <Save size={20} /> : <Plus size={20} />}
                    {editingUserId ? 'حفظ التغييرات' : 'إضافة المستخدم'}
                  </button>
                </div>

                <div className="border border-slate-100 rounded-2xl overflow-x-auto">
                  <table className="w-full text-sm min-w-[600px]">
                    <thead className="bg-slate-50">
                      <tr>
                        <th className="p-4 text-right font-bold text-slate-500">الاسم / الإيميل</th>
                        <th className="p-4 text-right font-bold text-slate-500">الشركة</th>
                        <th className="p-4 text-right font-bold text-slate-500">الدور</th>
                        <th className="p-4 text-right font-bold text-slate-500">الحالة</th>
                        <th className="p-4 text-right font-bold text-slate-500">إعدادات الطباعة/التعديل</th>
                        <th className="p-4 text-right font-bold text-slate-500">الصلاحيات</th>
                        <th className="p-4 w-24">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {db.users?.map(u => (
                        <tr key={u.id} className={`hover:bg-slate-50/50 transition-colors ${!u.isActive ? 'opacity-50' : ''}`}>
                          <td className="p-4">
                            <div className="flex flex-col">
                              <span className="font-bold text-slate-800">{u.name}</span>
                              <span className="text-[10px] text-slate-400">{u.email || 'لا يوجد إيميل'}</span>
                            </div>
                          </td>
                          <td className="p-4 text-xs text-slate-500">
                            {allCompanies?.find(c => c.id === u.companyId)?.name || u.companyId}
                          </td>
                          <td className="p-4">
                            <span className={`px-2 py-1 rounded text-[10px] font-bold ${u.role === 'admin' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'}`}>
                              {u.role === 'admin' ? 'مدير' : 'مستخدم'}
                            </span>
                          </td>
                          <td className="p-4">
                            <span className={`px-2 py-1 rounded text-[10px] font-bold ${u.isActive ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                              {u.isActive ? 'نشط' : 'موقوف'}
                            </span>
                          </td>
                          <td className="p-4">
                            <div className="flex flex-col gap-1 text-[10px]">
                              <span className="text-slate-500">نوع الطباعة: <b className="text-slate-700">{u.printType === 'pos' ? 'POS' : 'A4'}</b></span>
                              <span className="text-slate-500">سماح التعديل: <b className="text-slate-700">{u.editGracePeriod || 0} د</b></span>
                              <span className="text-slate-500">أقصى طباعة: <b className="text-slate-700">{u.maxPrintCount || 0}</b></span>
                            </div>
                          </td>
                          <td className="p-4">
                            {u.role === 'admin' ? (
                              <span className="text-xs text-slate-400 italic">كامل الصلاحيات</span>
                            ) : (
                              <div className="flex flex-wrap gap-1">
                                {u.allowedBranches?.length ? <span className="text-[9px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500">فروع: {u.allowedBranches.length}</span> : null}
                                {u.allowedWarehouses?.length ? <span className="text-[9px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500">مخازن: {u.allowedWarehouses.length}</span> : null}
                                {u.allowedCenters?.length ? <span className="text-[9px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500">مراكز: {u.allowedCenters.length}</span> : null}
                                {u.allowedAccounts?.length ? <span className="text-[9px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500">حسابات: {u.allowedAccounts.length}</span> : null}
                                {!u.allowedBranches?.length && !u.allowedWarehouses?.length && !u.allowedCenters?.length && !u.allowedAccounts?.length && (
                                  <span className="text-[9px] text-red-400">لا توجد صلاحيات محددة</span>
                                )}
                              </div>
                            )}
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-2">
                              <button 
                                onClick={() => editUser(u)}
                                className="p-1.5 text-blue-400 hover:bg-blue-50 rounded-lg transition-colors"
                                title="تعديل"
                              >
                                <Edit2 size={16} />
                              </button>
                              <button 
                                onClick={() => toggleUserStatus(u.id)}
                                className={`p-1.5 rounded-lg transition-colors ${u.isActive ? 'text-amber-400 hover:bg-amber-50' : 'text-emerald-400 hover:bg-emerald-50'}`}
                                title={u.isActive ? 'إيقاف' : 'تفعيل'}
                              >
                                <Power size={16} />
                              </button>
                              <button 
                                onClick={() => deleteEntry('users', u.id)}
                                className="p-1.5 text-slate-300 hover:text-red-500 transition-colors"
                                title="حذف"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'fields' && (
              <div className="space-y-8">
                <div className="bg-slate-50 p-6 rounded-2xl space-y-6 border border-slate-100">
                  <h3 className="font-bold text-slate-800">إضافة حقل مخصص جديد</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">اسم الحقل (مثال: رقم السيارة)</label>
                      <input 
                        type="text" 
                        value={newField.name || ''}
                        onChange={e => setNewField({...newField, name: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">نوع البيانات</label>
                      <select 
                        value={newField.type || 'text'}
                        onChange={e => setNewField({...newField, type: e.target.value as any})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value="text">نص</option>
                        <option value="number">رقم</option>
                        <option value="date">تاريخ</option>
                        <option value="select">قائمة خيارات</option>
                      </select>
                    </div>
                    {newField.type === 'select' && (
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500">الخيارات (مفصولة بفاصلة)</label>
                        <input 
                          type="text" 
                          placeholder="خيار 1, خيار 2"
                          value={newField.options?.join(', ') || ''}
                          onChange={e => setNewField({...newField, options: e.target.value.split(',').map(o => o.trim())})}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    )}
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">يظهر في سندات:</label>
                      <div className="flex items-center gap-4 pt-2">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={newField.allowedDocTypes?.includes('issue') ?? true}
                            onChange={e => {
                              const current = newField.allowedDocTypes || ['issue', 'purchase', 'sale'];
                              const updated = e.target.checked ? [...current, 'issue'] : current.filter(t => t !== 'issue');
                              setNewField({...newField, allowedDocTypes: updated as any});
                            }}
                            className="w-4 h-4 rounded text-blue-600"
                          />
                          <span className="text-xs font-bold">صرف</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={newField.allowedDocTypes?.includes('purchase') ?? true}
                            onChange={e => {
                              const current = newField.allowedDocTypes || ['issue', 'purchase', 'sale'];
                              const updated = e.target.checked ? [...current, 'purchase'] : current.filter(t => t !== 'purchase');
                              setNewField({...newField, allowedDocTypes: updated as any});
                            }}
                            className="w-4 h-4 rounded text-blue-600"
                          />
                          <span className="text-xs font-bold">مشتريات</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={newField.allowedDocTypes?.includes('sale') ?? true}
                            onChange={e => {
                              const current = newField.allowedDocTypes || ['issue', 'purchase', 'sale'];
                              const updated = e.target.checked ? [...current, 'sale'] : current.filter(t => t !== 'sale');
                              setNewField({...newField, allowedDocTypes: updated as any});
                            }}
                            className="w-4 h-4 rounded text-blue-600"
                          />
                          <span className="text-xs font-bold">مبيعات</span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={newField.required}
                        onChange={e => setNewField({...newField, required: e.target.checked})}
                        className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-sm font-bold text-slate-700">حقل مطلوب</span>
                    </label>
                  </div>
                  <button 
                    onClick={addField}
                    className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 flex items-center justify-center gap-2"
                  >
                    <Plus size={20} />
                    إضافة الحقل
                  </button>
                </div>

                <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse min-w-[600px]">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-100">
                          <th className="p-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">الترتيب</th>
                          <th className="p-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">اسم الحقل</th>
                          <th className="p-4 text-center text-xs font-bold text-slate-500 uppercase tracking-wider">النوع</th>
                          <th className="p-4 text-center text-xs font-bold text-slate-500 uppercase tracking-wider">مطلوب</th>
                          <th className="p-4 text-center text-xs font-bold text-slate-500 uppercase tracking-wider">إجراءات</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {(db.fieldDefinitions || []).sort((a, b) => a.order - b.order).map((field, idx) => (
                          <tr key={field.id} className="hover:bg-slate-50/50 transition-colors">
                            <td className="p-4">
                              <div className="flex items-center gap-1">
                                <button onClick={() => moveField(field.id, 'up')} className="p-1 hover:bg-slate-100 rounded text-slate-400"><ChevronUp size={14} /></button>
                                <button onClick={() => moveField(field.id, 'down')} className="p-1 hover:bg-slate-100 rounded text-slate-400"><ChevronDown size={14} /></button>
                                <span className="text-xs font-bold text-slate-400 mr-2">{field.order}</span>
                              </div>
                            </td>
                            <td className="p-4 text-sm font-bold text-slate-800">{field.name}</td>
                            <td className="p-4 text-center">
                              <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-1 rounded font-bold uppercase">
                                {field.type === 'text' ? 'نص' : field.type === 'number' ? 'رقم' : field.type === 'date' ? 'تاريخ' : 'قائمة'}
                              </span>
                            </td>
                            <td className="p-4 text-center">
                              {field.required ? (
                                <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-2 py-1 rounded">نعم</span>
                              ) : (
                                <span className="text-xs text-slate-400 font-bold bg-slate-50 px-2 py-1 rounded">لا</span>
                              )}
                            </td>
                            <td className="p-4 text-center">
                              <button 
                                onClick={() => deleteField(field.id)}
                                className="p-2 text-red-400 hover:bg-red-50 rounded-xl transition-colors"
                              >
                                <Trash2 size={18} />
                              </button>
                            </td>
                          </tr>
                        ))}
                        {(db.fieldDefinitions || []).length === 0 && (
                          <tr>
                            <td colSpan={5} className="p-12 text-center text-slate-400">
                              <SettingsIcon size={48} className="mx-auto mb-4 opacity-10" />
                              <p>لا توجد حقول مخصصة مضافة</p>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'system' && (
              <div className="space-y-8">
                <div className="bg-slate-50 p-6 rounded-2xl space-y-6 border border-slate-100">
                  <h3 className="font-bold text-slate-800">إعدادات الأدلة والمستويات</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">عدد مستويات دليل الحسابات</label>
                      <select 
                        value={db.settings?.accountsMaxLevel || 5}
                        onChange={e => onUpdateDB({ ...db, settings: { ...db.settings!, accountsMaxLevel: parseInt(e.target.value) } })}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value={5}>5 مستويات</option>
                        <option value={6}>6 مستويات</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">عدد مستويات دليل الأصناف</label>
                      <select 
                        value={db.settings?.itemsMaxLevel || 5}
                        onChange={e => onUpdateDB({ ...db, settings: { ...db.settings!, itemsMaxLevel: parseInt(e.target.value) } })}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value={5}>5 مستويات</option>
                        <option value={6}>6 مستويات</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">عدد مستويات مراكز التكلفة</label>
                      <select 
                        value={db.settings?.centersMaxLevel || 5}
                        onChange={e => onUpdateDB({ ...db, settings: { ...db.settings!, centersMaxLevel: parseInt(e.target.value) } })}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value={5}>5 مستويات</option>
                        <option value={6}>6 مستويات</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 p-6 rounded-2xl space-y-6 border border-slate-100">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-slate-800">إعدادات الطباعة والترقيم</h3>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">نوع الطباعة الافتراضي</label>
                      <select 
                        value={db.printType || 'a4'}
                        onChange={e => onUpdateDB({...db, printType: e.target.value as any})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value="a4">A4 (ورق عادي)</option>
                        <option value="pos">POS (حراري 80mm)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">وقت سماح التعديل (بالدقائق)</label>
                      <input 
                        type="number" 
                        value={db.editGracePeriod || 0}
                        onChange={e => onUpdateDB({...db, editGracePeriod: parseInt(e.target.value) || 0})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="0 تعني غير محدود"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">أقصى عدد مرات طباعة مسموح</label>
                      <input 
                        type="number" 
                        value={db.maxPrintCount || 0}
                        onChange={e => onUpdateDB({...db, maxPrintCount: parseInt(e.target.value) || 0})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="0 تعني غير محدود"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">استراتيجية الترقيم</label>
                      <select 
                        value={db.numberingStrategy}
                        onChange={e => onUpdateDB({...db, numberingStrategy: e.target.value as any})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value="branch">حسب الفرع</option>
                        <option value="branch-warehouse">حسب الفرع والمخزن</option>
                      </select>
                    </div>
                    <div className="flex items-center gap-3 pt-6">
                      <label className="flex items-center gap-3 cursor-pointer group">
                        <div className="relative">
                          <input 
                            type="checkbox" 
                            checked={db.allowNegativeStock}
                            onChange={e => onUpdateDB({...db, allowNegativeStock: e.target.checked})}
                            className="sr-only"
                          />
                          <div className={`w-12 h-6 rounded-full transition-colors ${db.allowNegativeStock ? 'bg-emerald-500' : 'bg-slate-300'}`}></div>
                          <div className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${db.allowNegativeStock ? 'translate-x-6' : ''}`}></div>
                        </div>
                        <span className="text-sm font-bold text-slate-700 group-hover:text-slate-900 transition-colors">السماح بالصرف بالسالب</span>
                      </label>
                    </div>
                  </div>
                </div>

                {/* Per-Type Settings */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {['issue', 'purchase', 'sale'].map((type) => {
                    const settings = db.settings?.[type as 'issue' | 'purchase' | 'sale'] || { linkingLevel: db.linkingLevel || 'header', mandatoryFields: db.mandatoryFields || [] };
                    return (
                      <div key={type} className="bg-slate-50 p-6 rounded-2xl space-y-6 border border-slate-100">
                        <h3 className="font-bold text-slate-800 flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${type === 'purchase' ? 'bg-purple-500' : type === 'sale' ? 'bg-emerald-500' : 'bg-blue-500'}`}></div>
                          إعدادات {type === 'purchase' ? 'فواتير المشتريات' : type === 'sale' ? 'فواتير المبيعات' : 'سندات الصرف'}
                        </h3>
                        
                        <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-500">مستوى ربط الحسابات</label>
                          <select 
                            value={settings.linkingLevel}
                            onChange={e => {
                              const newSettings = { ...db.settings } as any;
                              newSettings[type] = { ...settings, linkingLevel: e.target.value };
                              onUpdateDB({ ...db, settings: newSettings });
                            }}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                          >
                            <option value="header">رأس السند (حساب واحد)</option>
                            <option value="line">سطر السند (حساب لكل صنف)</option>
                          </select>
                        </div>

                        <div className="space-y-3">
                          <label className="text-xs font-bold text-slate-500">الحقول الإجبارية</label>
                          <div className="grid grid-cols-2 gap-2">
                            {[
                              { id: 'branchId', label: 'الفرع' },
                              { id: 'warehouseId', label: 'المخزن' },
                              { id: 'accId', label: 'الحساب' },
                              { id: 'ccId', label: 'مركز التكلفة' },
                              { id: 'deptId', label: 'القسم' },
                            ].map(field => (
                              <label key={field.id} className="flex items-center gap-2 p-2 bg-white rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-50 transition-colors">
                                <input 
                                  type="checkbox"
                                  checked={settings.mandatoryFields.includes(field.id)}
                                  onChange={e => {
                                    const fields = settings.mandatoryFields;
                                    const updated = e.target.checked 
                                      ? [...fields, field.id]
                                      : fields.filter(f => f !== field.id);
                                    
                                    const newSettings = { ...db.settings } as any;
                                    newSettings[type] = { ...settings, mandatoryFields: updated };
                                    onUpdateDB({ ...db, settings: newSettings });
                                  }}
                                  className="w-3.5 h-3.5 text-blue-600 rounded"
                                />
                                <span className="text-[11px] font-bold text-slate-700">{field.label}</span>
                              </label>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-3">
                          <label className="text-xs font-bold text-slate-500">إظهار/إخفاء الأعمدة</label>
                          <div className="grid grid-cols-2 gap-2">
                            {[
                              { id: 'price', label: 'السعر' },
                              { id: 'discount', label: 'الخصم' },
                              { id: 'expenses', label: 'المصروفات' },
                              { id: 'total', label: 'الإجمالي' },
                              { id: 'unit', label: 'الوحدة' },
                              { id: 'qty', label: 'الكمية' }
                            ].map(field => {
                              const config = settings.fieldConfig?.[field.id] || { visible: true, order: 0 };
                              return (
                                <label key={field.id} className="flex items-center gap-2 p-2 bg-white rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-50 transition-colors">
                                  <input 
                                    type="checkbox"
                                    checked={config.visible}
                                    onChange={e => {
                                      const currentConfig = settings.fieldConfig || {};
                                      const newSettings = { ...db.settings } as any;
                                      newSettings[type] = { 
                                        ...settings, 
                                        fieldConfig: { 
                                          ...currentConfig, 
                                          [field.id]: { ...config, visible: e.target.checked } 
                                        } 
                                      };
                                      onUpdateDB({ ...db, settings: newSettings });
                                    }}
                                    className="w-3.5 h-3.5 text-blue-600 rounded"
                                  />
                                  <span className="text-[11px] font-bold text-slate-700">{field.label}</span>
                                </label>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {activeTab === 'fiscal-years' as any && (
              <div className="space-y-8">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-slate-800">إدارة السنوات المالية</h2>
                  <button 
                    onClick={() => {
                      const newFY: FiscalYear = {
                        id: Math.random().toString(36).substr(2, 9),
                        companyId: user.companyId,
                        name: `سنة ${new Date().getFullYear()}`,
                        startDate: `${new Date().getFullYear()}-01-01`,
                        endDate: `${new Date().getFullYear()}-12-31`,
                        isActive: true,
                        isClosed: false
                      };
                      onUpdateDB({ ...db, fiscalYears: [...(db.fiscalYears || []), newFY] }, 'fiscalYears', newFY.id, newFY);
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-bold text-xs shadow-lg shadow-blue-100 transition-all"
                  >
                    <Plus size={16} />
                    إضافة سنة مالية جديدة
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {(db.fiscalYears || []).map(fy => (
                    <div key={fy.id} className="bg-slate-50 p-6 rounded-2xl border border-slate-100 grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">اسم السنة</label>
                        <input 
                          type="text" 
                          value={fy.name}
                          onChange={e => {
                            const updated = { ...fy, name: e.target.value };
                            onUpdateDB({ ...db, fiscalYears: db.fiscalYears?.map(f => f.id === fy.id ? updated : f) || [] }, 'fiscalYears', fy.id, updated);
                          }}
                          className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">من تاريخ</label>
                        <input 
                          type="date" 
                          value={fy.startDate}
                          onChange={e => {
                            const updated = { ...fy, startDate: e.target.value };
                            onUpdateDB({ ...db, fiscalYears: db.fiscalYears?.map(f => f.id === fy.id ? updated : f) || [] }, 'fiscalYears', fy.id, updated);
                          }}
                          className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500">إلى تاريخ</label>
                        <input 
                          type="date" 
                          value={fy.endDate}
                          onChange={e => {
                            const updated = { ...fy, endDate: e.target.value };
                            onUpdateDB({ ...db, fiscalYears: db.fiscalYears?.map(f => f.id === fy.id ? updated : f) || [] }, 'fiscalYears', fy.id, updated);
                          }}
                          className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => {
                            const updated = { ...fy, isActive: !fy.isActive };
                            onUpdateDB({ ...db, fiscalYears: db.fiscalYears?.map(f => f.id === fy.id ? updated : f) || [] }, 'fiscalYears', fy.id, updated);
                          }}
                          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${fy.isActive ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-500'}`}
                        >
                          {fy.isActive ? 'نشطة' : 'غير نشطة'}
                        </button>
                        <button 
                          onClick={() => {
                            const updated = { ...fy, isClosed: !fy.isClosed };
                            onUpdateDB({ ...db, fiscalYears: db.fiscalYears?.map(f => f.id === fy.id ? updated : f) || [] }, 'fiscalYears', fy.id, updated);
                          }}
                          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${fy.isClosed ? 'bg-red-600 text-white' : 'bg-slate-200 text-slate-500'}`}
                        >
                          {fy.isClosed ? 'مغلقة' : 'مفتوحة'}
                        </button>
                        <button 
                          onClick={() => deleteEntry('fiscalYears', fy.id)}
                          className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </div>
                  ))}
                  {(!db.fiscalYears || db.fiscalYears.length === 0) && (
                    <div className="text-center py-12 text-slate-400">
                      <Calendar size={48} className="mx-auto mb-4 opacity-10" />
                      <p>لم يتم تحديد سنوات مالية بعد</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'company' && (
              <div className="space-y-8">
                <div className="bg-slate-50 p-6 rounded-2xl space-y-6 border border-slate-100">
                  <h3 className="font-bold text-slate-800">بيانات المنشأة (للترويسة)</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">اسم الشركة/المحل</label>
                      <input 
                        type="text" 
                        value={company.name || ''}
                        onChange={e => setCompany({...company, name: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">رقم الهاتف</label>
                      <input 
                        type="text" 
                        value={company.phone || ''}
                        onChange={e => setCompany({...company, phone: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">العنوان</label>
                      <input 
                        type="text" 
                        value={company.address || ''}
                        onChange={e => setCompany({...company, address: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">الرقم الضريبي</label>
                      <input 
                        type="text" 
                        value={company.taxNumber || ''}
                        onChange={e => setCompany({...company, taxNumber: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="sm:col-span-2 space-y-2">
                      <label className="text-xs font-bold text-slate-500">رابط الشعار (URL)</label>
                      <input 
                        type="text" 
                        placeholder="https://example.com/logo.png"
                        value={company.logo || ''}
                        onChange={e => setCompany({...company, logo: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="sm:col-span-2 space-y-2">
                      <label className="text-xs font-bold text-slate-500">بيانات التذييل (Footer)</label>
                      <textarea 
                        value={company.footerText || ''}
                        onChange={e => setCompany({...company, footerText: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 min-h-[100px]"
                        placeholder="تظهر في أسفل المطبوعات..."
                      />
                    </div>
                    <div className="sm:col-span-2 space-y-2">
                      <label className="text-xs font-bold text-slate-500">كلمة مرور الدخول للشركة (اختياري)</label>
                      <input 
                        type="password" 
                        value={company.accessPassword || ''}
                        onChange={e => setCompany({...company, accessPassword: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="اتركه فارغاً للدخول بدون كلمة مرور"
                      />
                    </div>
                  </div>
                  <button 
                    onClick={saveCompanyInfo}
                    className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
                  >
                    حفظ بيانات الشركة
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'data-mgmt' && (
              <div className="space-y-8">
                <div className="bg-red-50 p-6 rounded-2xl border border-red-100 space-y-6">
                  <div className="flex items-center gap-3 text-red-600">
                    <Trash2 size={24} />
                    <h3 className="text-xl font-bold">إدارة وحذف البيانات (للمدراء فقط)</h3>
                  </div>
                  <p className="text-sm text-red-500 font-bold">تحذير: هذه العمليات نهائية ولا يمكن التراجع عنها. يرجى أخذ نسخة احتياطية قبل البدء.</p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <button 
                      onClick={() => {
                        setConfirmModal({
                          title: "حذف كافة الحركات",
                          message: "هل أنت متأكد من حذف كافة السندات والفواتير؟ سيتم تصفير النظام من العمليات المالية.",
                          onConfirm: async () => {
                            try {
                              const batch = writeBatch(firestore);
                              db.docs.forEach(d => batch.delete(doc(firestore, 'docs', d.id)));
                              (db.journalEntries || []).forEach(d => batch.delete(doc(firestore, 'journalEntries', d.id)));
                              (db.cashBankDocs || []).forEach(d => batch.delete(doc(firestore, 'cashBankDocs', d.id)));
                              await batch.commit();
                              onUpdateDB({ ...db, docs: [], journalEntries: [], cashBankDocs: [] }, 'docs');
                              showNotification("تم حذف كافة الحركات بنجاح");
                              setConfirmModal(null);
                            } catch (e: any) {
                              showNotification(e.message, 'error');
                            }
                          }
                        });
                      }}
                      className="p-4 bg-white border border-red-200 rounded-xl text-red-600 font-bold hover:bg-red-50 transition-all flex items-center justify-between"
                    >
                      <span>حذف كافة الحركات (السندات)</span>
                      <Trash2 size={18} />
                    </button>

                    <button 
                      onClick={() => {
                        setConfirmModal({
                          title: "حذف كافة الأدلة",
                          message: "هل أنت متأكد من حذف كافة الحسابات والأصناف والفروع؟ سيتم مسح هيكلية النظام بالكامل.",
                          onConfirm: async () => {
                            try {
                              const batch = writeBatch(firestore);
                              db.accounts.forEach(d => batch.delete(doc(firestore, 'accounts', d.id)));
                              db.items.forEach(d => batch.delete(doc(firestore, 'items', d.id)));
                              db.branches.forEach(d => batch.delete(doc(firestore, 'branches', d.id)));
                              db.warehouses.forEach(d => batch.delete(doc(firestore, 'warehouses', d.id)));
                              db.departments.forEach(d => batch.delete(doc(firestore, 'departments', d.id)));
                              db.centers.forEach(d => batch.delete(doc(firestore, 'centers', d.id)));
                              db.docs.forEach(d => batch.delete(doc(firestore, 'docs', d.id)));
                              await batch.commit();
                              onUpdateDB({ 
                                ...db, 
                                accounts: [], 
                                items: [], 
                                branches: [], 
                                warehouses: [], 
                                departments: [], 
                                centers: [],
                                docs: [] 
                              }, 'accounts');
                              showNotification("تم حذف كافة الأدلة والبيانات بنجاح");
                              setConfirmModal(null);
                            } catch (e: any) {
                              showNotification(e.message, 'error');
                            }
                          }
                        });
                      }}
                      className="p-4 bg-white border border-red-200 rounded-xl text-red-600 font-bold hover:bg-red-50 transition-all flex items-center justify-between"
                    >
                      <span>حذف كافة الأدلة والبيانات</span>
                      <Trash2 size={18} />
                    </button>

                    <button 
                      onClick={() => {
                        setConfirmModal({
                          title: "حذف دليل الحسابات",
                          message: "هل أنت متأكد من حذف دليل الحسابات؟",
                          onConfirm: async () => {
                            try {
                              const batch = writeBatch(firestore);
                              db.accounts.forEach(d => batch.delete(doc(firestore, 'accounts', d.id)));
                              await batch.commit();
                              onUpdateDB({ ...db, accounts: [] }, 'accounts');
                              showNotification("تم حذف دليل الحسابات");
                              setConfirmModal(null);
                            } catch (e: any) {
                              showNotification(e.message, 'error');
                            }
                          }
                        });
                      }}
                      className="p-4 bg-white border border-slate-200 rounded-xl text-slate-600 font-bold hover:bg-slate-50 transition-all flex items-center justify-between"
                    >
                      <span>حذف دليل الحسابات</span>
                      <Trash2 size={18} />
                    </button>

                    <button 
                      onClick={() => {
                        setConfirmModal({
                          title: "حذف دليل الأصناف",
                          message: "هل أنت متأكد من حذف دليل الأصناف؟",
                          onConfirm: async () => {
                            try {
                              const batch = writeBatch(firestore);
                              db.items.forEach(d => batch.delete(doc(firestore, 'items', d.id)));
                              await batch.commit();
                              onUpdateDB({ ...db, items: [] }, 'items');
                              showNotification("تم حذف دليل الأصناف");
                              setConfirmModal(null);
                            } catch (e: any) {
                              showNotification(e.message, 'error');
                            }
                          }
                        });
                      }}
                      className="p-4 bg-white border border-slate-200 rounded-xl text-slate-600 font-bold hover:bg-slate-50 transition-all flex items-center justify-between"
                    >
                      <span>حذف دليل الأصناف</span>
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'backup' && (
              <div className="space-y-12 py-8">
                {/* Advanced Export */}
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 space-y-6">
                  <div className="flex items-center gap-3 text-blue-600">
                    <FileSpreadsheet size={24} />
                    <h3 className="text-xl font-bold">تصدير مخصص (إكسل)</h3>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">من تاريخ</label>
                      <input 
                        type="date" 
                        value={expFrom}
                        onChange={e => setExpFrom(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">إلى تاريخ</label>
                      <input 
                        type="date" 
                        value={expTo}
                        onChange={e => setExpTo(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500">نوع السند</label>
                      <select 
                        value={expType}
                        onChange={e => setExpType(e.target.value as any)}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      >
                        <option value="all">الكل</option>
                        <option value="issue">سند صرف</option>
                        <option value="purchase">فاتورة مشتريات</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button 
                      onClick={seedSampleData}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-xl font-bold shadow-lg shadow-emerald-100 transition-all flex items-center justify-center gap-2"
                    >
                      <Database size={20} />
                      توليد بيانات تجريبية (أدلة)
                    </button>
                    <button 
                      onClick={runExport}
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold shadow-lg shadow-blue-100 transition-all flex items-center justify-center gap-2"
                    >
                      <Download size={20} />
                      تصدير السندات المجمعة
                    </button>
                    <button 
                      onClick={copyVBACode}
                      className="flex-1 bg-slate-800 hover:bg-slate-900 text-white py-4 rounded-xl font-bold shadow-lg shadow-slate-200 transition-all flex items-center justify-center gap-2"
                    >
                      <Plus size={20} />
                      نسخ كود الماكرو (VBA)
                    </button>
                  </div>
                </div>

                <div className="flex flex-col items-center text-center space-y-6">
                  <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center text-blue-600">
                    <Download size={40} />
                  </div>
                  <div className="max-w-md">
                    <h3 className="text-2xl font-bold text-slate-900">تصدير البيانات</h3>
                    <p className="text-slate-500 mt-2">قم بتحميل نسخة احتياطية كاملة من النظام لاستعادتها في أي وقت أو نقلها لجهاز آخر.</p>
                  </div>
                  <button 
                    onClick={exportData}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 rounded-2xl font-bold shadow-xl shadow-blue-100 transition-all flex items-center gap-3"
                  >
                    <FileJson size={24} />
                    تحميل ملف النسخة (JSON)
                  </button>
                </div>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
                  <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-4 text-slate-400 font-bold">أو</span></div>
                </div>

                <div className="flex flex-col items-center text-center space-y-6">
                  <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600">
                    <Upload size={40} />
                  </div>
                  <div className="max-w-md">
                    <h3 className="text-2xl font-bold text-slate-900">استيراد البيانات</h3>
                    <p className="text-slate-500 mt-2">اختر ملف نسخة احتياطية (JSON) لاستبدال البيانات الحالية ببيانات النسخة.</p>
                  </div>
                  <label className="bg-emerald-600 hover:bg-emerald-700 text-white px-10 py-4 rounded-2xl font-bold shadow-xl shadow-emerald-100 transition-all flex items-center gap-3 cursor-pointer">
                    <Database size={24} />
                    رفع ملف واستعادة البيانات
                    <input type="file" accept=".json" onChange={importData} className="hidden" />
                  </label>
                  <div className="flex items-center gap-2 text-amber-600 bg-amber-50 px-4 py-2 rounded-lg border border-amber-100">
                    <Shield size={16} />
                    <span className="text-xs font-bold">تنبيه: سيتم استبدال كافة البيانات الحالية بالبيانات المستوردة.</span>
                  </div>
                </div>
              </div>
            )}
            {activeTab === 'all-companies' && isSuperAdmin && (
              <div className="space-y-8">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-bold text-slate-800">إدارة الشركات</h2>
                    <p className="text-xs text-slate-500 mt-1">بصفتك مديراً عاماً، يمكنك إضافة وإدارة كافة الشركات في النظام</p>
                  </div>
                  {!isAddingCompany && (
                    <button 
                      onClick={() => setIsAddingCompany(true)}
                      className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-bold text-xs shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all"
                    >
                      <Plus size={16} />
                      إضافة شركة جديدة
                    </button>
                  )}
                </div>

                {isAddingCompany && (
                  <motion.div 
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-blue-50 p-6 rounded-2xl border border-blue-100 flex flex-col sm:flex-row gap-4 items-end"
                  >
                    <div className="flex-1 space-y-2 w-full">
                      <label className="text-xs font-bold text-blue-600">اسم الشركة الجديدة</label>
                      <input 
                        type="text"
                        value={newCompanyName}
                        onChange={e => setNewCompanyName(e.target.value)}
                        placeholder="أدخل اسم الشركة..."
                        className="w-full px-4 py-2 rounded-xl border border-blue-200 outline-none focus:ring-2 focus:ring-blue-500"
                        autoFocus
                      />
                    </div>
                    <div className="flex gap-2 w-full sm:w-auto">
                      <button 
                        onClick={handleAddCompany}
                        className="flex-1 sm:flex-none px-6 py-2 bg-blue-600 text-white rounded-xl font-bold text-sm"
                      >
                        حفظ
                      </button>
                      <button 
                        onClick={() => setIsAddingCompany(false)}
                        className="flex-1 sm:flex-none px-6 py-2 bg-white text-slate-500 border border-slate-200 rounded-xl font-bold text-sm"
                      >
                        إلغاء
                      </button>
                    </div>
                  </motion.div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {allCompanies?.map(c => (
                    <div key={c.id} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:border-blue-200 transition-all group">
                      {editingCompanyId === c.id ? (
                        <div className="space-y-4">
                          <input 
                            type="text"
                            value={editingCompanyName}
                            onChange={e => setEditingCompanyName(e.target.value)}
                            className="w-full px-3 py-2 rounded-lg border border-blue-200 outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                            autoFocus
                          />
                          <div className="flex gap-2">
                            <button 
                              onClick={() => handleUpdateCompany(c.id)}
                              className="flex-1 py-1.5 bg-blue-600 text-white rounded-lg font-bold text-xs"
                            >
                              حفظ
                            </button>
                            <button 
                              onClick={() => setEditingCompanyId(null)}
                              className="flex-1 py-1.5 bg-slate-100 text-slate-500 rounded-lg font-bold text-xs"
                            >
                              إلغاء
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <h4 className="font-bold text-slate-800 group-hover:text-blue-600 transition-colors">{c.name}</h4>
                            <p className="text-[10px] text-slate-400 font-mono mt-1">{c.id}</p>
                          </div>
                          <div className="flex items-center gap-1">
                            <button 
                              onClick={() => {
                                setEditingCompanyId(c.id);
                                setEditingCompanyName(c.name);
                              }}
                              className="p-2 text-slate-300 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-all"
                            >
                              <Edit2 size={16} />
                            </button>
                            <button 
                              onClick={() => handleDeleteCompany(c.id, c.name)}
                              className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
        
        {/* Developer Credits Footer */}
        <div className="mt-12 pt-8 border-t border-slate-100 flex flex-col items-center gap-2 text-center no-print">
          <p className="text-xs font-black text-slate-400 uppercase tracking-widest">تطوير ودعم فني</p>
          <p className="text-sm font-bold text-slate-800">عبدالمجيد المزلم</p>
          <p className="text-[10px] text-slate-500 font-mono">775600578 | Almuzllam@gmail.com</p>
        </div>

        </div>
      </div>
    </div>
  );
};
