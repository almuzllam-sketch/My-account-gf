import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Calendar, 
  FileText, 
  ArrowUpRight, 
  ArrowDownLeft,
  Filter,
  Download,
  Printer
} from 'lucide-react';
import { DB, Doc, Account, CostCenter } from '../types';

interface AccountStatementProps {
  db: DB;
}

export const AccountStatement: React.FC<AccountStatementProps> = ({ db }) => {
  const [targetType, setTargetType] = useState<'account' | 'center'>('account');
  const [targetId, setTargetId] = useState<string>('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const filteredDocs = useMemo(() => {
    return (db.docs || []).filter(doc => {
      const matchesTarget = targetType === 'account' 
        ? (doc.accId === targetId || (doc.items || []).some(it => it.accId === targetId))
        : (doc.ccId === targetId || (doc.items || []).some(it => it.ccId === targetId));
      
      const matchesDate = (!fromDate || doc.date >= fromDate) && (!toDate || doc.date <= toDate);
      
      return matchesTarget && matchesDate;
    }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [db.docs, targetType, targetId, fromDate, toDate]);

  const stats = useMemo(() => {
    let totalQtyIn = 0;
    let totalQtyOut = 0;
    
    filteredDocs.forEach(doc => {
      (doc.items || []).forEach(it => {
        const isTarget = targetType === 'account' 
          ? (doc.accId === targetId || it.accId === targetId)
          : (doc.ccId === targetId || it.ccId === targetId);
        
        if (isTarget) {
          if (doc.type === 'purchase') totalQtyIn += it.qty;
          else totalQtyOut += it.qty;
        }
      });
    });

    return { totalQtyIn, totalQtyOut, balance: totalQtyIn - totalQtyOut };
  }, [filteredDocs, targetType, targetId]);

  const exportToCSV = () => {
    if (!targetId) return;
    const targetName = targetType === 'account' 
      ? (db.accounts || []).find(a => a.id === targetId)?.name 
      : (db.centers || []).find(c => c.id === targetId)?.name;
    
    const companyName = db.company?.name || 'شركة المثال المحدودة';
    const reportTitle = `كشف حساب تفصيلي - ${targetName}`;
    
    const headers = ['التاريخ', 'نوع السند', 'المرجع', 'البيان', 'وارد', 'منصرف', 'الرصيد'];
    let runningBalance = 0;
    const rows = filteredDocs.map(doc => {
      const docQtyIn = doc.type === 'purchase' ? (doc.items || []).reduce((sum, it) => {
        const isTarget = targetType === 'account' 
          ? (doc.accId === targetId || it.accId === targetId)
          : (doc.ccId === targetId || it.ccId === targetId);
        return isTarget ? sum + it.qty : sum;
      }, 0) : 0;

      const docQtyOut = (doc.type === 'issue' || doc.type === 'sale') ? (doc.items || []).reduce((sum, it) => {
        const isTarget = targetType === 'account' 
          ? (doc.accId === targetId || it.accId === targetId)
          : (doc.ccId === targetId || it.ccId === targetId);
        return isTarget ? sum + it.qty : sum;
      }, 0) : 0;

      runningBalance += (docQtyIn - docQtyOut);
      return [
        doc.date,
        doc.type === 'purchase' ? 'مشتريات' : 'صرف',
        doc.ref,
        doc.description,
        docQtyIn,
        docQtyOut,
        runningBalance
      ];
    });

    const csvContent = [
      `"${companyName}"`,
      `"${reportTitle}"`,
      `"الفترة: من ${fromDate || 'البداية'} إلى ${toDate || 'اليوم'}"`,
      `"إجمالي الوارد: ${stats.totalQtyIn}"`,
      `"إجمالي المنصرف: ${stats.totalQtyOut}"`,
      `"الرصيد الحالي: ${stats.balance}"`,
      '',
      headers.join(','),
      ...rows.map(r => r.map(c => `"${c}"`).join(','))
    ].join('\n');

    const blob = new Blob(["\ufeff" + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `كشف_حساب_${targetName}_${new Date().toISOString().split('T')[0]}.csv`);
    link.click();
  };

  return (
    <div className="space-y-6 pb-20" dir="rtl">
      <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-purple-600 flex items-center justify-center text-white shadow-xl shadow-purple-200">
              <FileText size={28} />
            </div>
            <div>
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">كشف حساب تفصيلي</h2>
              <p className="text-slate-500 font-medium mt-0.5">استعراض وتحليل حركات الحسابات ومراكز التكلفة</p>
            </div>
          </div>
          {targetId && (
            <button 
              onClick={exportToCSV}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-emerald-100 transition-all flex items-center gap-2 active:scale-95"
            >
              <Download size={18} />
              تصدير CSV
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">نوع الكشف</label>
            <select 
              value={targetType}
              onChange={(e) => {
                setTargetType(e.target.value as any);
                setTargetId('');
              }}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 bg-slate-50/30 focus:bg-white font-bold transition-all"
            >
              <option value="account">حساب مالي</option>
              <option value="center">مركز تكلفة</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">اختيار {targetType === 'account' ? 'الحساب' : 'المركز'}</label>
            <select 
              value={targetId}
              onChange={(e) => setTargetId(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 bg-white font-bold transition-all"
            >
              <option value="">-- اختر --</option>
              {targetType === 'account' 
                ? (db.accounts || []).map(a => <option key={a.id} value={a.id}>{a.name}</option>)
                : (db.centers || []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)
              }
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">من تاريخ</label>
            <input 
              type="date" 
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 bg-white font-bold transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">إلى تاريخ</label>
            <input 
              type="date" 
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 bg-white font-bold transition-all"
            />
          </div>
        </div>
      </div>

      {targetId && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
              <div className="flex items-center gap-4">
                <div className="bg-green-50 p-3 rounded-xl text-green-600">
                  <ArrowDownLeft size={24} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase">إجمالي الوارد</p>
                  <p className="text-2xl font-black text-slate-800">{stats.totalQtyIn}</p>
                </div>
              </div>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
              <div className="flex items-center gap-4">
                <div className="bg-red-50 p-3 rounded-xl text-red-600">
                  <ArrowUpRight size={24} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase">إجمالي المنصرف</p>
                  <p className="text-2xl font-black text-slate-800">{stats.totalQtyOut}</p>
                </div>
              </div>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
              <div className="flex items-center gap-4">
                <div className="bg-blue-50 p-3 rounded-xl text-blue-600">
                  <Filter size={24} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase">الرصيد الحالي</p>
                  <p className="text-2xl font-black text-slate-800">{stats.balance}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100">
                    <th className="p-4 text-right text-xs font-bold text-slate-500">التاريخ</th>
                    <th className="p-4 text-right text-xs font-bold text-slate-500">نوع السند</th>
                    <th className="p-4 text-right text-xs font-bold text-slate-500">المرجع</th>
                    <th className="p-4 text-right text-xs font-bold text-slate-500">البيان</th>
                    <th className="p-4 text-center text-xs font-bold text-slate-500">وارد</th>
                    <th className="p-4 text-center text-xs font-bold text-slate-500">منصرف</th>
                    <th className="p-4 text-center text-xs font-bold text-slate-500">الرصيد</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredDocs.length > 0 ? (
                    (() => {
                      let runningBalance = 0;
                      return filteredDocs.map(doc => {
                        const docQtyIn = doc.type === 'purchase' ? (doc.items || []).reduce((sum, it) => {
                          const isTarget = targetType === 'account' 
                            ? (doc.accId === targetId || it.accId === targetId)
                            : (doc.ccId === targetId || it.ccId === targetId);
                          return isTarget ? sum + it.qty : sum;
                        }, 0) : 0;

                        const docQtyOut = (doc.type === 'issue' || doc.type === 'sale') ? (doc.items || []).reduce((sum, it) => {
                          const isTarget = targetType === 'account' 
                            ? (doc.accId === targetId || it.accId === targetId)
                            : (doc.ccId === targetId || it.ccId === targetId);
                          return isTarget ? sum + it.qty : sum;
                        }, 0) : 0;

                        runningBalance += (docQtyIn - docQtyOut);

                        return (
                          <tr key={doc.id} className="hover:bg-slate-50/50 transition-colors">
                            <td className="p-4 text-sm font-medium text-slate-600">{doc.date}</td>
                            <td className="p-4">
                              <span className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                                doc.type === 'purchase' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                              }`}>
                                {doc.type === 'purchase' ? 'مشتريات' : 'صرف'}
                              </span>
                            </td>
                            <td className="p-4 text-sm font-bold text-slate-900">{doc.ref}</td>
                            <td className="p-4 text-sm text-slate-500">{doc.description}</td>
                            <td className="p-4 text-center font-bold text-green-600">{docQtyIn || '-'}</td>
                            <td className="p-4 text-center font-bold text-red-600">{docQtyOut || '-'}</td>
                            <td className="p-4 text-center font-bold text-slate-900">{runningBalance}</td>
                          </tr>
                        );
                      });
                    })()
                  ) : (
                    <tr>
                      <td colSpan={7} className="p-12 text-center text-slate-400">
                        لا توجد حركات لهذا {targetType === 'account' ? 'الحساب' : 'المركز'} خلال الفترة المحددة
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
