import React from 'react';
import { 
  LayoutDashboard, 
  PlusCircle, 
  History, 
  Settings, 
  LogOut, 
  ChevronRight, 
  ChevronLeft,
  FileText,
  User as UserIcon,
  ShoppingBag,
  X,
  FileCog,
  BarChart3,
  ChevronDown,
  ChevronUp,
  Tag,
  Database,
  Building,
  Users,
  CreditCard,
  Banknote,
  Repeat,
  Calendar
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User, ViewType, DB } from '../types';

interface SidebarProps {
  activeView: ViewType;
  setActiveView: (view: ViewType) => void;
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
  isMobileOpen?: boolean;
  setIsMobileOpen?: (open: boolean) => void;
  user: User;
  onLogout: () => void;
  db: DB;
}

export const Sidebar: React.FC<SidebarProps> = React.memo(({ 
  activeView, 
  setActiveView, 
  isCollapsed, 
  setIsCollapsed,
  isMobileOpen,
  setIsMobileOpen,
  user,
  onLogout,
  db
}) => {
  const [expandedGroups, setExpandedGroups] = React.useState<string[]>(['inventory-docs', 'inventory-reports']);

  const toggleGroup = (groupId: string) => {
    setExpandedGroups(prev => 
      prev.includes(groupId) ? prev.filter(g => g !== groupId) : [...prev, groupId]
    );
  };

  const menuGroups = [
    {
      id: 'general',
      label: 'العامة',
      items: [
        { id: 'dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
        { id: 'main-guides', label: 'الأدلة الرئيسية', icon: FileCog, permission: (u: User) => u.canManageAccounts || u.canManageItems || u.canManageBranches || u.canManageWarehouses || u.canManageDepartments || u.canManageCenters || u.canManageFunds || u.canManageBanks || u.canManageCustomersSuppliers || u.canManageCurrencies },
      ]
    },
    {
      id: 'inventory-docs',
      label: 'الحركات المخزنية',
      items: [
        { id: 'new-doc', label: 'سند صرف مخزني', icon: PlusCircle, permission: 'canCreateIssue' },
        { id: 'new-purchase', label: 'فاتورة مشتريات', icon: PlusCircle, permission: 'canCreatePurchase' },
        { id: 'new-sale', label: 'فاتورة مبيعات', icon: PlusCircle, permission: 'canCreateSale' },
        { id: 'price-list', label: 'تسعيرات الأصناف', icon: Tag, permission: 'canManagePricing' },
      ]
    },
    {
      id: 'cash-docs',
      label: 'الحركة النقدية',
      items: [
        { id: 'cash-payment', label: 'صرف نقدي', icon: Banknote, permission: 'canCreateCashBank' },
        { id: 'cash-receipt', label: 'قبض نقدي', icon: Banknote, permission: 'canCreateCashBank' },
        { id: 'cash-history', label: 'سجل النقدية', icon: History, permission: 'canCreateCashBank' },
      ]
    },
    {
      id: 'bank-docs',
      label: 'الحركة البنكية',
      items: [
        { id: 'bank-payment', label: 'صرف بنكي', icon: CreditCard, permission: 'canCreateCashBank' },
        { id: 'bank-receipt', label: 'قبض بنكي', icon: CreditCard, permission: 'canCreateCashBank' },
        { id: 'bank-history', label: 'سجل البنك', icon: History, permission: 'canCreateCashBank' },
      ]
    },
    {
      id: 'financial-docs',
      label: 'القيود اليومية',
      items: [
        { id: 'new-journal', label: 'قيد يومية', icon: PlusCircle, permission: 'canCreateJournal' },
        { id: 'journal-history', label: 'سجل القيود', icon: History, permission: 'canCreateJournal' },
      ]
    },
    {
      id: 'guides',
      label: 'الأدلة الشجرية',
      items: [
        { id: 'accounts', label: 'دليل الحسابات', icon: Database, permission: 'canManageAccounts' },
        { id: 'items', label: 'دليل الأصناف', icon: Database, permission: 'canManageItems' },
        { id: 'centers', label: 'مراكز التكلفة', icon: Database, permission: 'canManageCenters' },
        { id: 'funds', label: 'دليل الصناديق', icon: Database, permission: 'canManageFunds' },
        { id: 'banks', label: 'دليل البنوك', icon: Database, permission: 'canManageBanks' },
        { id: 'customers-suppliers', label: 'العملاء والموردين', icon: Database, permission: 'canManageCustomersSuppliers' },
        { id: 'branches', label: 'دليل الفروع', icon: Database, permission: 'canManageBranches' },
        { id: 'warehouses', label: 'دليل المخازن', icon: Database, permission: 'canManageWarehouses' },
        { id: 'departments', label: 'دليل الأقسام', icon: Database, permission: 'canManageDepartments' },
        { id: 'currencies', label: 'العملات وأسعار الصرف', icon: Database, permission: 'canManageCurrencies' },
      ]
    },
    {
      id: 'inventory-reports',
      label: 'التقارير',
      items: [
        { id: 'all-reports', label: 'قائمة التقارير', icon: BarChart3, permission: 'canViewReports' },
        { id: 'inventory-movement', label: 'الحركة المخزنية', icon: History, permission: 'canViewReports' },
        { id: 'inventory-reports', label: 'التقارير المخزنية', icon: ShoppingBag, permission: 'canViewReports' },
        { id: 'sale-history', label: 'سجل المبيعات', icon: History, permission: 'canViewReports' },
        { id: 'account-statement', label: 'كشف حساب تفصيلي', icon: BarChart3, permission: 'canViewReports' },
      ]
    },
    {
      id: 'system',
      label: 'النظام',
      adminOnly: true,
      items: [
        { id: 'fiscal-years', label: 'السنوات المالية', icon: Calendar },
        { id: 'settings', label: 'الإعدادات', icon: Settings },
      ]
    }
  ];

  const filteredGroups = menuGroups.map(group => {
    if (group.adminOnly && user.role !== 'admin') return null;
    
    const filteredItems = group.items.filter(item => {
      if (user.role === 'admin') return true;
      if (!(item as any).permission) return true;
      if (typeof (item as any).permission === 'function') return (item as any).permission(user);
      return !!(user as any)[(item as any).permission];
    });

    if (filteredItems.length === 0) return null;
    return { ...group, items: filteredItems };
  }).filter((g): g is any => g !== null);

  return (
    <>
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isMobileOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsMobileOpen?.(false)}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] lg:hidden"
          />
        )}
      </AnimatePresence>

      <motion.aside 
        initial={false}
        animate={{ 
          width: isCollapsed ? 80 : 280,
          x: isMobileOpen ? 0 : (typeof window !== 'undefined' && window.innerWidth < 1024 ? 280 : 0)
        }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className={`bg-slate-950 text-slate-300 flex flex-col h-screen fixed lg:sticky top-0 right-0 z-[70] lg:z-50 border-l border-white/5 shadow-2xl lg:shadow-none ${
          !isMobileOpen ? 'pointer-events-none lg:pointer-events-auto' : ''
        }`}
      >
        {/* Logo Area */}
        <div className="p-6 flex items-center justify-between border-b border-white/5">
          {(!isCollapsed || isMobileOpen) && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center gap-3"
            >
              <div className="relative group">
                <div className="absolute -inset-1.5 bg-blue-600 rounded-xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                {db.company?.logo ? (
                  <img src={db.company.logo} className="relative w-10 h-10 rounded-xl object-contain bg-white p-1" alt="Logo" />
                ) : (
                  <div className="relative bg-blue-600 p-2 rounded-xl">
                    <FileText className="text-white" size={24} />
                  </div>
                )}
              </div>
              <div className="flex flex-col">
                <span className="font-black text-lg text-white tracking-tight truncate max-w-[140px]">
                  {db.company?.name || 'المحاسب'}
                </span>
                <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest truncate max-w-[140px]">
                  {db.fiscalYears?.find(fy => fy.isActive)?.name || 'السنة المالية'}
                </span>
              </div>
            </motion.div>
          )}
          <button 
            onClick={() => isMobileOpen ? setIsMobileOpen?.(false) : setIsCollapsed(!isCollapsed)}
            className="p-2 hover:bg-white/5 rounded-xl transition-all text-slate-500 hover:text-white"
          >
            {isMobileOpen ? <X size={20} /> : (isCollapsed ? <ChevronLeft size={20} /> : <ChevronRight size={20} />)}
          </button>
        </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-8 overflow-y-auto no-scrollbar">
        {filteredGroups.map((group) => {
          const isExpanded = expandedGroups.includes(group.id);
          
          return (
            <div key={group.id} className="space-y-3">
              {(!isCollapsed || isMobileOpen) && group.label && (
                <button 
                  onClick={() => toggleGroup(group.id)}
                  className="w-full flex items-center justify-between px-3 text-[10px] font-black text-slate-600 uppercase tracking-[0.2em] hover:text-slate-400 transition-colors group"
                >
                  <span className="group-hover:translate-x-1 transition-transform">{group.label}</span>
                  {isExpanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                </button>
              )}
              
              <AnimatePresence initial={false}>
                {(isExpanded || isCollapsed) && (
                  <motion.div 
                    initial={isCollapsed ? { opacity: 1, height: 'auto' } : { opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-1 overflow-hidden"
                  >
                    {group.items.map((item) => {
                      const isActive = activeView === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => setActiveView(item.id as ViewType)}
                          className={`w-full flex items-center gap-4 p-3 rounded-xl transition-all group relative ${
                            isActive 
                              ? 'text-white' 
                              : 'hover:bg-white/5 text-slate-500 hover:text-slate-100'
                          }`}
                        >
                          {isActive && (
                            <motion.div 
                              layoutId="active-bg"
                              className="absolute inset-0 bg-blue-600 rounded-xl shadow-[0_0_20px_rgba(37,99,235,0.3)]"
                              transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                            />
                          )}
                          <item.icon size={20} className={`relative z-10 ${isActive ? 'text-white' : 'group-hover:scale-110 transition-transform'}`} />
                          {(!isCollapsed || isMobileOpen) && (
                            <span className="relative z-10 font-bold text-sm whitespace-nowrap">{item.label}</span>
                          )}
                          {isActive && (!isCollapsed || isMobileOpen) && (
                            <motion.div 
                              layoutId="active-pill"
                              className="relative z-10 mr-auto w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_10px_#fff]"
                            />
                          )}
                        </button>
                      );
                    })}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </nav>

      {/* User Profile & Logout */}
      <div className="p-4 border-t border-white/5 bg-slate-950/50 backdrop-blur-xl">
        {(!isCollapsed || isMobileOpen) && (
          <div className="mb-4 px-3 py-4 bg-white/5 rounded-2xl flex flex-col gap-1 border border-white/5 no-print">
            <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">تطوير ودعم فني</span>
            <span className="text-xs font-bold text-slate-300">عبدالمجيد المزلم</span>
            <span className="text-[10px] text-slate-500 font-mono">775600578 | Almuzllam@gmail.com</span>
          </div>
        )}
        {(!isCollapsed || isMobileOpen) && (
          <div className="mb-4 px-3 py-3 bg-white/5 rounded-2xl flex items-center gap-3 border border-white/5">
            <div className="relative">
              <div className="absolute -inset-1 bg-blue-500 rounded-lg blur-sm opacity-20"></div>
              <div className="relative bg-slate-800 p-2 rounded-lg text-blue-400">
                <UserIcon size={20} />
              </div>
            </div>
            <div className="flex flex-col overflow-hidden">
              <span className="text-sm font-black text-white truncate">{user.name}</span>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{user.role === 'admin' ? 'مدير النظام' : 'محاسب'}</span>
            </div>
          </div>
        )}
        <button 
          onClick={onLogout}
          className={`w-full flex items-center gap-4 p-3 rounded-xl text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all ${
            (isCollapsed && !isMobileOpen) ? 'justify-center' : ''
          }`}
        >
          <LogOut size={22} />
          {(!isCollapsed || isMobileOpen) && <span className="font-bold">تسجيل الخروج</span>}
        </button>
      </div>
    </motion.aside>
    </>
  );
});
