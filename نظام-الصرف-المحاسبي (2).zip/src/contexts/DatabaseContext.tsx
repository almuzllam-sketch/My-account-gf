import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, ReactNode } from 'react';
import { 
  DB, Doc, User, JournalEntry, CashBankDoc, CashBankDocType 
} from '../types';
import { auth, db as firestore, handleFirestoreError, OperationType } from '../firebase';
import { 
  onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut 
} from 'firebase/auth';
import { 
  doc, setDoc, onSnapshot, collection, getDoc, getDocs, query, where, deleteDoc as deleteDocFirestore, writeBatch 
} from 'firebase/firestore';
import { cleanObject, uid } from '../lib/utils';

interface DatabaseContextType {
  db: DB;
  user: User | null;
  isAuthReady: boolean;
  selectedCompanyId: string | undefined;
  isCompanyAccessVerified: boolean;
  allCompanies: {id: string, name: string, hasPassword?: boolean}[];
  isSuperAdmin: boolean;
  setSelectedCompanyId: (id: string | undefined) => void;
  verifyCompanyAccess: (companyId: string, password?: string) => Promise<boolean>;
  login: () => Promise<void>;
  logout: () => void;
  handleUpdateDB: (newDb: DB, collectionName?: string, docId?: string, data?: any, isDelete?: boolean) => Promise<void>;
  saveDoc: (docData: Partial<Doc>) => void;
  deleteDoc: (id: string) => void;
  saveJournal: (entry: JournalEntry) => Promise<void>;
  deleteJournal: (id: string) => void;
  saveCashBankDoc: (docData: CashBankDoc) => Promise<void>;
  deleteCashBankDoc: (id: string) => void;
  getNextCashBankDocNum: (type: CashBankDocType) => string;
  deleteCompany: (id: string) => Promise<void>;
  showNotification: (message: string, type?: 'success' | 'error' | 'warning') => void;
  notification: { message: string; type: 'success' | 'error' | 'warning' } | null;
  confirmModal: { title: string; message: string; onConfirm: () => void } | null;
  setConfirmModal: (modal: { title: string; message: string; onConfirm: () => void } | null) => void;
}

const DatabaseContext = createContext<DatabaseContextType | undefined>(undefined);

export const DatabaseProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [db, setDb] = useState<DB>({ 
    accounts: [], 
    centers: [], 
    items: [], 
    docs: [], 
    branches: [], 
    warehouses: [], 
    departments: [], 
    pricingDocs: [],
    users: [],
    journalEntries: [],
    cashBankDocs: [],
    currencies: [],
    funds: [],
    banks: [],
    customersSuppliers: [],
    fieldDefinitions: [],
    numberingStrategy: 'branch'
  });

  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [selectedCompanyId, setSelectedCompanyId] = useState<string | undefined>(undefined);
  const [isCompanyAccessVerified, setIsCompanyAccessVerified] = useState(false);
  const [allCompanies, setAllCompanies] = useState<{id: string, name: string, hasPassword?: boolean}[]>([]);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' | 'warning' } | null>(null);
  const [confirmModal, setConfirmModal] = useState<{ title: string; message: string; onConfirm: () => void } | null>(null);

  const isSuperAdmin = useMemo(() => 
    user?.email?.toLowerCase() === 'almuzllam@gmail.com',
  [user?.email]);

  const showNotification = useCallback((message: string, type: 'success' | 'error' | 'warning' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  }, []);

  // Auth Effect
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        const userDoc = await getDoc(doc(firestore, 'users', firebaseUser.uid));
        let userData: User | null = null;

        if (userDoc.exists()) {
          userData = userDoc.data() as User;
        } else if (firebaseUser.email) {
          const q = query(collection(firestore, 'users'), where("email", "==", firebaseUser.email));
          const querySnapshot = await getDocs(q);
          if (!querySnapshot.empty) {
            const docSnap = querySnapshot.docs[0];
            userData = { ...(docSnap.data() as User), id: firebaseUser.uid };
            await setDoc(doc(firestore, 'users', firebaseUser.uid), userData);
            if (docSnap.id !== firebaseUser.uid) {
              await deleteDocFirestore(doc(firestore, 'users', docSnap.id));
            }
          }
        }

        if (userData) {
          if (!userData.companyId) {
            const companyId = `comp_${Math.random().toString(36).substring(2, 9)}`;
            const updatedUser: User = { ...userData, companyId, email: firebaseUser.email || userData.email || '' };
            
            const batch = writeBatch(firestore);
            batch.set(doc(firestore, 'users', firebaseUser.uid), updatedUser);
            batch.set(doc(firestore, 'settings', companyId), {
              company: { name: 'شركتي الجديدة', logo: '', phone: '', address: '', taxNumber: '', footerText: '' },
              numberingStrategy: 'branch',
              printType: 'a4',
              editGracePeriod: 720,
              maxPrintCount: 3,
              allowNegativeStock: false,
              settings: {
                issue: { linkingLevel: 'header', mandatoryFields: [] },
                purchase: { linkingLevel: 'header', mandatoryFields: [] },
                sale: { linkingLevel: 'header', mandatoryFields: [] }
              }
            });
            await batch.commit();

            setUser(updatedUser);
            if (!selectedCompanyId) setSelectedCompanyId(companyId);
          } else {
            const updatedUser: User = {
              ...userData,
              email: firebaseUser.email || userData.email || '',
              role: firebaseUser.email?.toLowerCase() === 'almuzllam@gmail.com' ? 'admin' : userData.role
            };
            if (updatedUser.email !== userData.email || updatedUser.role !== userData.role || updatedUser.id !== userData.id) {
              await setDoc(doc(firestore, 'users', firebaseUser.uid), updatedUser);
            }
            setUser(updatedUser);
            if (!selectedCompanyId) setSelectedCompanyId(userData.companyId);
          }
        } else {
          const companyId = `comp_${Math.random().toString(36).substring(2, 9)}`;
          const newUser: User = {
            id: firebaseUser.uid,
            companyId: companyId,
            name: firebaseUser.displayName || 'مستخدم جديد',
            email: firebaseUser.email || '',
            role: 'admin', // Every user is admin of their own company by default
            isActive: true
          };

          const batch = writeBatch(firestore);
          batch.set(doc(firestore, 'users', firebaseUser.uid), newUser);
          batch.set(doc(firestore, 'settings', companyId), {
            company: { name: 'شركتي الجديدة', logo: '', phone: '', address: '', taxNumber: '', footerText: '' },
            numberingStrategy: 'branch',
            printType: 'a4',
            editGracePeriod: 720,
            maxPrintCount: 3,
            allowNegativeStock: false,
            settings: {
              issue: { linkingLevel: 'header', mandatoryFields: [] },
              purchase: { linkingLevel: 'header', mandatoryFields: [] },
              sale: { linkingLevel: 'header', mandatoryFields: [] }
            }
          });
          await batch.commit();

          setUser(newUser);
          if (!selectedCompanyId) setSelectedCompanyId(newUser.companyId);
        }
      } else {
        setUser(null);
      }
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, [selectedCompanyId]);

  // Data Sync Effect
  useEffect(() => {
    // Load companies for everyone to see the selector
    const unsubscribeCompanies = onSnapshot(collection(firestore, 'settings'), (snapshot) => {
      const companies = snapshot.docs.map(d => {
        const data = d.data();
        return {
          id: d.id,
          name: data.company?.name || d.id,
          hasPassword: !!data.company?.accessPassword
        };
      });
      setAllCompanies(companies);
    });

    return () => unsubscribeCompanies();
  }, []);

  // Data Sync Effect for specific company
  useEffect(() => {
    if (!user || !selectedCompanyId || !isCompanyAccessVerified) return;

    const collections = ['accounts', 'items', 'centers', 'docs', 'branches', 'warehouses', 'departments', 'pricingDocs', 'fieldDefinitions', 'users', 'journalEntries', 'cashBankDocs', 'funds', 'banks', 'customersSuppliers', 'currencies', 'fiscalYears'];
    const unsubscribes = collections.map(col => {
      const colRef = collection(firestore, col);
      const q = selectedCompanyId === 'all' && isSuperAdmin
        ? query(colRef)
        : query(colRef, where("companyId", "==", selectedCompanyId));
        
      return onSnapshot(q, (snapshot) => {
        const data = snapshot.docs.map(d => ({ ...d.data(), id: d.id }));
        setDb(prev => ({ ...prev, [col]: data }));
      }, (error) => {
        if (error.code === 'permission-denied') {
          console.warn(`Permission Denied for collection ${col}. This may be expected during login transitions.`);
          // If we're super admin and getting denied, there's a problem with rules or token
          if (isSuperAdmin) {
            console.error(`CRITICAL: Super Admin permission denied on ${col}. Check firestore.rules and token email.`);
          }
        } else {
          handleFirestoreError(error, OperationType.LIST, col);
        }
      });
    });

    const settingsUnsub = selectedCompanyId !== 'all' 
      ? onSnapshot(doc(firestore, 'settings', selectedCompanyId), (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data();
            setDb(prev => ({ ...prev, ...data }));
          }
        }, (error) => {
          console.warn(`Settings sync error for ${selectedCompanyId}:`, error.message);
        })
      : () => {
          setDb(prev => ({ ...prev, company: { name: 'جميع الشركات', phone: '', address: '', taxNumber: '', logo: '' } }));
        };

    let companiesUnsub = () => {};
    // Already handled above globally for this specific requirement

    return () => {
      unsubscribes.forEach(unsub => unsub());
      settingsUnsub();
      companiesUnsub();
    };
  }, [user, selectedCompanyId, isSuperAdmin]);

  const saveToFirestore = useCallback(async (newDb: DB, collectionName?: string, docId?: string, data?: any) => {
    if (!user) return;
    let targetCompanyId = (collectionName === 'settings' && docId) ? docId : selectedCompanyId;
    if (targetCompanyId === 'all') targetCompanyId = user.companyId;
    if (!targetCompanyId) return;

    try {
      if (Array.isArray(data) && collectionName) {
        const batch = writeBatch(firestore);
        data.forEach(item => {
          const cleanedItem = cleanObject(item);
          const { id, ...docData } = cleanedItem;
          const ref = doc(firestore, collectionName, id || docId);
          batch.set(ref, { ...docData, companyId: targetCompanyId });
        });
        await batch.commit();
      } else {
        const cleanedData = data ? cleanObject(data) : null;
        if (collectionName && docId && cleanedData) {
          if (collectionName === 'settings') {
            await setDoc(doc(firestore, 'settings', docId), cleanedData, { merge: true });
          } else {
            const { id, ...docData } = cleanedData;
            await setDoc(doc(firestore, collectionName, docId), { ...docData, companyId: targetCompanyId });
          }
        } else {
          // Destructure everything that belongs to its own collection to prevent them from being saved in 'settings'
          const { 
            accounts, items, centers, docs, branches, warehouses, 
            departments, pricingDocs, fieldDefinitions, users, 
            currencies, journalEntries, cashBankDocs, funds, banks, 
            customersSuppliers, fiscalYears, ...settings 
          } = newDb;
          await setDoc(doc(firestore, 'settings', targetCompanyId), cleanObject(settings), { merge: true });
        }
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, collectionName || `settings/${targetCompanyId}`);
    }
  }, [user, selectedCompanyId]);

  const handleUpdateDB = useCallback(async (newDb: DB, collectionName?: string, docId?: string, data?: any, isDelete?: boolean) => {
    const targetCompanyId = (collectionName === 'settings' && docId) ? docId : selectedCompanyId;
    if (targetCompanyId === selectedCompanyId) setDb(newDb);

    if (isDelete && collectionName && docId) {
      await deleteDocFirestore(doc(firestore, collectionName, docId));
    } else if (collectionName && docId && data) {
      await saveToFirestore(newDb, collectionName, docId, data);
    } else {
      await saveToFirestore(newDb);
    }
  }, [selectedCompanyId, saveToFirestore]);

  const verifyCompanyAccess = useCallback(async (companyId: string, password?: string) => {
    if (!auth.currentUser) return false;
    
    if (isSuperAdmin) {
      setIsCompanyAccessVerified(true);
      setSelectedCompanyId(companyId);
      return true;
    }

    try {
      // Secure verification: Attempt to set the companyId on the user document
      // The Firestore rules will verify the 'providedPassword' against the company's secret
      const userRef = doc(firestore, 'users', auth.currentUser.uid);
      
      // Prepare the user data to be saved/updated
      const userData: any = {
        id: auth.currentUser.uid,
        name: auth.currentUser.displayName || 'User',
        email: auth.currentUser.email || '',
        role: 'user', // Default role for joining
        companyId: companyId,
        isActive: true,
        providedPassword: password || '' // Temporary field used only by rules
      };

      await setDoc(userRef, userData, { merge: true });
      
      // If we reach here, the password was correct (or not required)
      setIsCompanyAccessVerified(true);
      setSelectedCompanyId(companyId);
      return true;
    } catch (error: any) {
      console.error(error);
      if (error.message?.includes('permission-denied') || error.code === 'permission-denied') {
        showNotification('كلمة المرور غير صحيحة أو لا تملك صلاحية الوصول', 'error');
      } else {
        showNotification('فشل التحقق من الوصول', 'error');
      }
      return false;
    }
  }, [isSuperAdmin, showNotification]);

  const login = useCallback(async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      showNotification('فشل تسجيل الدخول', 'error');
    }
  }, [showNotification]);

  const logout = useCallback(() => {
    signOut(auth);
    setUser(null);
    setSelectedCompanyId(undefined);
  }, []);

  const saveDoc = useCallback(async (docData: Partial<Doc>) => {
    if (!user) return;
    if (docData.id && user.role !== 'admin') {
      const existing = (db.docs || []).find(d => d.id === docData.id);
      if (existing && ((new Date().getTime() - new Date(existing.createdAt).getTime()) / 3600000) > 12) {
        showNotification("⚠️ انتهت مهلة التعديل (12 ساعة).", 'warning');
        throw new Error("Edit grace period expired");
      }
    }

    const finalDoc: Doc = {
      id: docData.id || uid(),
      companyId: user.companyId,
      type: docData.type || 'issue',
      date: docData.date!,
      docNum: docData.docNum!,
      ref: docData.ref!,
      description: docData.description || '',
      accId: docData.accId!,
      ccId: docData.ccId!,
      branchId: docData.branchId,
      warehouseId: docData.warehouseId,
      deptId: docData.deptId,
      items: docData.items!,
      customValues: docData.customValues,
      priceType: docData.priceType,
      createdAt: docData.id ? (db.docs || []).find(d => d.id === docData.id)!.createdAt : new Date().toISOString(),
      createdBy: docData.id ? (db.docs || []).find(d => d.id === docData.id)!.createdBy : user.id,
      updatedAt: docData.id ? new Date().toISOString() : undefined,
      updatedBy: docData.id ? user.id : undefined,
      editCount: docData.id ? ((db.docs || []).find(d => d.id === docData.id)!.editCount || 0) + 1 : 0,
      printCount: docData.id ? (db.docs || []).find(d => d.id === docData.id)!.printCount : 0
    };

    let finalDocToSave: Doc | null = null;
    
    setDb(prev => {
      const newDocs = docData.id 
        ? (prev.docs || []).map(d => d.id === docData.id ? finalDoc : d)
        : [finalDoc, ...(prev.docs || [])];
      
      finalDocToSave = finalDoc;
      return { ...prev, docs: newDocs };
    });

    if (finalDocToSave) {
      await handleUpdateDB({ ...db, docs: docData.id ? (db.docs || []).map(d => d.id === docData.id ? finalDocToSave! : d) : [finalDocToSave!, ...(db.docs || [])] }, 'docs', finalDoc.id, finalDocToSave);
    }
    showNotification("✅ تم الحفظ بنجاح");
  }, [db, user, handleUpdateDB, showNotification]);

  const deleteDoc = useCallback((id: string) => {
    setConfirmModal({
      title: "حذف السند",
      message: "هل أنت متأكد من حذف هذا السند؟ لا يمكن التراجع عن هذه العملية.",
      onConfirm: async () => {
        try {
          await deleteDocFirestore(doc(firestore, 'docs', id));
          const newDocs = (db.docs || []).filter(d => d.id !== id);
          setDb({ ...db, docs: newDocs });
          showNotification("تم حذف السند بنجاح");
        } catch (error) {
          handleFirestoreError(error, OperationType.DELETE, `docs/${id}`);
        }
        setConfirmModal(null);
      }
    });
  }, [db.docs, showNotification]);

  const saveJournal = useCallback(async (entry: JournalEntry) => {
    if (!selectedCompanyId) return;
    try {
      const { id, ...data } = entry;
      await setDoc(doc(firestore, 'journalEntries', id), { ...data, companyId: selectedCompanyId });
      const exists = db.journalEntries?.find(e => e.id === entry.id);
      const newEntries = exists 
        ? db.journalEntries?.map(e => e.id === entry.id ? entry : e)
        : [...(db.journalEntries || []), entry];
      setDb({ ...db, journalEntries: newEntries });
      showNotification("تم حفظ القيد بنجاح");
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `journalEntries/${entry.id}`);
    }
  }, [db.journalEntries, selectedCompanyId, showNotification]);

  const deleteJournal = useCallback((id: string) => {
    setConfirmModal({
      title: "حذف القيد",
      message: "هل أنت متأكد من حذف هذا القيد؟ لا يمكن التراجع عن هذه العملية.",
      onConfirm: async () => {
        try {
          await deleteDocFirestore(doc(firestore, 'journalEntries', id));
          const newEntries = (db.journalEntries || []).filter(e => e.id !== id);
          setDb({ ...db, journalEntries: newEntries });
          showNotification("تم حذف القيد بنجاح");
        } catch (error) {
          handleFirestoreError(error, OperationType.DELETE, `journalEntries/${id}`);
        }
        setConfirmModal(null);
      }
    });
  }, [db.journalEntries, showNotification]);

  const saveCashBankDoc = useCallback(async (docData: CashBankDoc) => {
    if (!selectedCompanyId) return;
    try {
      const { id, ...data } = docData;
      await setDoc(doc(firestore, 'cashBankDocs', id), { ...data, companyId: selectedCompanyId });
      const exists = db.cashBankDocs?.find(d => d.id === docData.id);
      const newDocs = exists 
        ? db.cashBankDocs?.map(d => d.id === docData.id ? docData : d)
        : [...(db.cashBankDocs || []), docData];
      setDb({ ...db, cashBankDocs: newDocs });
      showNotification("تم حفظ السند بنجاح");
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `cashBankDocs/${docData.id}`);
    }
  }, [db.cashBankDocs, selectedCompanyId, showNotification]);

  const deleteCashBankDoc = useCallback((id: string) => {
    setConfirmModal({
      title: "حذف السند",
      message: "هل أنت متأكد من حذف هذا السند؟ لا يمكن التراجع عن هذه العملية.",
      onConfirm: async () => {
        try {
          await deleteDocFirestore(doc(firestore, 'cashBankDocs', id));
          const newDocs = (db.cashBankDocs || []).filter(d => d.id !== id);
          setDb({ ...db, cashBankDocs: newDocs });
          showNotification("تم حذف السند بنجاح");
        } catch (error) {
          handleFirestoreError(error, OperationType.DELETE, `cashBankDocs/${id}`);
        }
        setConfirmModal(null);
      }
    });
  }, [db.cashBankDocs, showNotification]);

  const getNextCashBankDocNum = useCallback((type: CashBankDocType) => {
    const docs = db.cashBankDocs || [];
    const typeDocs = docs.filter(d => d.type === type);
    if (typeDocs.length === 0) return '1';
    const nums = typeDocs.map(d => parseInt(d.docNum)).filter(n => !isNaN(n));
    if (nums.length === 0) return '1';
    return (Math.max(...nums) + 1).toString();
  }, [db.cashBankDocs]);

  const deleteCompany = useCallback(async (id: string) => {
    if (!isSuperAdmin) return;
    try {
      await deleteDocFirestore(doc(firestore, 'settings', id));
      showNotification("تم حذف الشركة بنجاح");
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `settings/${id}`);
    }
  }, [isSuperAdmin, showNotification]);

  return (
    <DatabaseContext.Provider value={{ 
      db, user, isAuthReady, selectedCompanyId, isCompanyAccessVerified, allCompanies, isSuperAdmin,
      setSelectedCompanyId, verifyCompanyAccess, login, logout, handleUpdateDB,
      saveDoc, deleteDoc, saveJournal, deleteJournal, saveCashBankDoc, deleteCashBankDoc,
      getNextCashBankDocNum, deleteCompany, showNotification, notification, confirmModal, setConfirmModal
    }}>
      {children}
    </DatabaseContext.Provider>
  );
};

export const useDatabase = () => {
  const context = useContext(DatabaseContext);
  if (context === undefined) throw new Error('useDatabase must be used within a DatabaseProvider');
  return context;
};
