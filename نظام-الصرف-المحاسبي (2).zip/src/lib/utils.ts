/**
 * Utility functions for the application
 */

// Generate a unique ID using timestamp and random string to ensure no duplicates
export const uid = () => Date.now().toString(36) + Math.random().toString(36).substr(2, 5);

export const getTodayDate = () => {
  const today = new Date();
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
};

export const cleanObject = (obj: any): any => {
  if (Array.isArray(obj)) {
    return obj.map(cleanObject);
  }
  if (obj !== null && typeof obj === 'object') {
    return Object.entries(obj).reduce((acc, [key, value]) => {
      if (value !== undefined) {
        acc[key] = cleanObject(value);
      }
      return acc;
    }, {} as any);
  }
  return obj;
};
