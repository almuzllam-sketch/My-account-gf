/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  Plus, 
  Save, 
  LogOut, 
  ChevronLeft, 
  ChevronRight, 
  Printer, 
  FileText, 
  Search,
  Download,
  X,
  CheckCircle2,
  Building,
  Settings as SettingsIcon,
  Menu
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Import New Components
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { History } from './components/History';
import { DocumentForm } from './components/DocumentForm';
import { Settings } from './components/Settings';
import { AccountStatement } from './components/AccountStatement';
import { InventoryReports } from './components/SoldItems';
import { PricingHistory } from './components/PricingHistory';
import { GuideScreen } from './components/GuideScreen';
import { ReportScreen } from './components/ReportScreen';
import { JournalForm } from './components/JournalForm';
import { JournalHistory } from './components/JournalHistory';
import CashBankForm from './components/CashBankForm';
import CashBankHistory from './components/CashBankHistory';
import { CurrencyManagement } from './components/CurrencyManagement';
import { GlobalUI } from './components/GlobalUI';
import { LandingPage } from './components/LandingPage';
import { CompanySelector } from './components/CompanySelector';
import { 
  Doc, 
  ViewType, 
} from './types';
import { useDatabase } from './contexts/DatabaseContext';
import { getTodayDate, uid } from './lib/utils';

interface Tab {
  id: string;
  title: string;
  view: ViewType;
  params?: any;
}

export default function App() {
  const { 
    db, user, isAuthReady, selectedCompanyId, isCompanyAccessVerified, allCompanies, isSuperAdmin,
    setSelectedCompanyId, verifyCompanyAccess, login, logout, handleUpdateDB,
    saveDoc, deleteDoc, saveJournal, deleteJournal, saveCashBankDoc, deleteCashBankDoc,
    getNextCashBankDocNum, showNotification, notification, confirmModal, setConfirmModal
  } = useDatabase();

  // Tab System
  const [tabs, setTabs] = useState<Tab[]>([
    { id: 'dashboard', title: 'لوحة التحكم', view: 'dashboard' }
  ]);
  const [activeTabId, setActiveTabId] = useState<string>('dashboard');

  const activeTab = useMemo(() => 
    tabs.find(t => t.id === activeTabId) || tabs[0], 
  [tabs, activeTabId]);

  const openTab = useCallback((view: ViewType, title: string, params?: any) => {
    // Permission Check
    if (user && user.role !== 'admin') {
      const permissionMap: Partial<Record<ViewType, any>> = {
        'new-doc': 'canCreateIssue',
        'new-purchase': 'canCreatePurchase',
        'new-sale': 'canCreateSale',
        'price-list': 'canManagePricing',
        'new-journal': 'canCreateJournal',
        'journal-history': 'canCreateJournal',
        'cash-payment': 'canCreateCashBank',
        'cash-receipt': 'canCreateCashBank',
        'bank-payment': 'canCreateCashBank',
        'bank-receipt': 'canCreateCashBank',
        'cash-history': 'canCreateCashBank',
        'bank-history': 'canCreateCashBank',
        'accounts': 'canManageAccounts',
        'items': 'canManageItems',
        'centers': 'canManageCenters',
        'funds': 'canManageFunds',
        'banks': 'canManageBanks',
        'customers-suppliers': 'canManageCustomersSuppliers',
        'branches': 'canManageBranches',
        'warehouses': 'canManageWarehouses',
        'departments': 'canManageDepartments',
        'currencies': 'canManageCurrencies',
        'all-reports': 'canViewReports',
        'inventory-movement': 'canViewReports',
        'inventory-reports': 'canViewReports',
        'sale-history': 'canViewReports',
        'account-statement': 'canViewReports'
      };
      
      const requiredPerm = permissionMap[view];
      if (requiredPerm && !user[requiredPerm as keyof typeof user]) {
        showNotification('ليس لديك صلاحية للوصول إلى هذه الشاشة', 'error');
        return;
      }
    }

    const singletonViews: ViewType[] = ['dashboard', 'history', 'sold-items', 'settings'];
    if (singletonViews.includes(view)) {
      const existing = tabs.find(t => t.view === view);
      if (existing) {
        setActiveTabId(existing.id);
        setIsMobileMenuOpen(false);
        return;
      }
    }

    const newTab: Tab = { id: uid(), title, view, params };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
    setIsMobileMenuOpen(false);
  }, [tabs, user, showNotification]);

  const closeTab = useCallback((id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) return;
    
    setTabs(prev => {
      const newTabs = prev.filter(t => t.id !== id);
      if (activeTabId === id) {
        setActiveTabId(newTabs[newTabs.length - 1].id);
      }
      return newTabs;
    });
  }, [tabs, activeTabId]);

  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [editingDoc, setEditingDoc] = useState<Doc | null>(null);
  const [currentDocIndex, setCurrentDocIndex] = useState<number>(-1);
  
  // Modals & Notifications
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [expFrom, setExpFrom] = useState(getTodayDate());
  const [expTo, setExpTo] = useState(getTodayDate());

  const handleLogout = useCallback(() => {
    setConfirmModal({
      title: "تسجيل الخروج",
      message: "هل أنت متأكد من رغبتك في تسجيل الخروج من النظام؟",
      onConfirm: () => {
        logout();
        setTabs([{ id: 'dashboard', title: 'لوحة التحكم', view: 'dashboard' }]);
        setActiveTabId('dashboard');
        setConfirmModal(null);
      }
    });
  }, [logout, setConfirmModal]);

  const onSaveDoc = useCallback((docData: Partial<Doc>) => {
    saveDoc(docData);
    setEditingDoc(null);
    setCurrentDocIndex(-1);
    
    // Close the current tab after saving
    closeTab(activeTabId, { stopPropagation: () => {} } as any);

    let historyView: ViewType = 'history';
    let historyTitle = 'سجل السندات';
    if (docData.type === 'purchase') {
      historyView = 'purchase-history';
      historyTitle = 'سجل المشتريات';
    } else if (docData.type === 'sale') {
      historyView = 'sale-history';
      historyTitle = 'سجل المبيعات';
    }
    
    openTab(historyView, historyTitle);
  }, [saveDoc, closeTab, activeTabId, openTab]);

  // Navigation Handlers
  const handleNewDoc = () => {
    setEditingDoc(null);
    setCurrentDocIndex(-1);
    openTab('new-doc', 'سند صرف جديد');
  };

  const handlePrevDoc = () => {
    if (currentDocIndex > 0) {
      const prevDoc = (db.docs || [])[currentDocIndex - 1];
      setEditingDoc(prevDoc);
      setCurrentDocIndex(currentDocIndex - 1);
    }
  };

  const handleNextDoc = () => {
    if (currentDocIndex < (db.docs || []).length - 1) {
      const nextDoc = (db.docs || [])[currentDocIndex + 1];
      setEditingDoc(nextDoc);
      setCurrentDocIndex(currentDocIndex + 1);
    }
  };

  const printDoc = (doc: Doc) => {
    const userMaxPrint = user.maxPrintCount || db.maxPrintCount;
    if (userMaxPrint && (doc.printCount || 0) >= userMaxPrint && user.role !== 'admin') {
      showNotification(`تنبيه: تم الوصول للحد الأقصى للطباعة (${userMaxPrint})`, 'error');
      return;
    }

    const acc = (db.accounts || []).find(a => a.id === doc.accId)?.name || '';
    const cc = (db.centers || []).find(c => c.id === doc.ccId)?.name || '';
    const branch = (db.branches || []).find(b => b.id === doc.branchId)?.name || '';
    const warehouse = (db.warehouses || []).find(w => w.id === doc.warehouseId)?.name || '';
    const company = db.company || { name: 'شركة المثال المحدودة', address: 'صنعاء - اليمن', logo: 'logo.png' };
    const printType = user.printType || db.printType || 'a4';
    
    const itemsHtml = (doc.items || []).map((it, idx) => {
      const itemObj = (db.items || []).find(i => i.id === it.itemId);
      return `
        <tr>
          <td style="border:1px solid #000; text-align:center; padding:8px;">${idx + 1}</td>
          <td style="border:1px solid #000; padding:8px;">${itemObj?.name || ''}</td>
          <td style="border:1px solid #000; text-align:center; padding:8px;">${it.unit}</td>
          <td style="border:1px solid #000; text-align:center; padding:8px;">${it.qty}</td>
        </tr>
      `;
    }).join('');

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const isPos = printType === 'pos';

    printWindow.document.write(`
      <html dir="rtl">
        <head>
          <title>طباعة سند - ${doc.ref}</title>
          <style>
            @media print {
              .no-print { display: none; }
              body { padding: 0; margin: 0; }
              @page { size: ${isPos ? '80mm auto' : 'A4'}; margin: 0; }
            }
            body { 
              font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
              padding: ${isPos ? '5mm' : '20px'}; 
              color: #000;
              width: ${isPos ? '70mm' : 'auto'};
              margin: ${isPos ? '0 auto' : '0'};
            }
            .header-container { text-align: center; border-bottom: 1px solid #000; padding-bottom: 10px; margin-bottom: 15px; }
            .company-info h2 { margin: 0; font-size: ${isPos ? '18px' : '24px'}; }
            .company-info p { margin: 2px 0; font-size: ${isPos ? '10px' : '14px'}; }
            .doc-title { text-align: center; font-size: ${isPos ? '16px' : '20px'}; font-weight: bold; margin: 10px 0; text-decoration: underline; }
            .info-grid { 
              display: grid; 
              grid-template-columns: ${isPos ? '1fr' : '1fr 1fr'}; 
              gap: 5px; 
              margin-bottom: 15px; 
              font-size: ${isPos ? '11px' : '14px'};
              border: ${isPos ? 'none' : '1px solid #eee'};
              padding: ${isPos ? '0' : '10px'};
            }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: ${isPos ? '10px' : '14px'}; }
            th { background: #f2f2f2; border: 1px solid #000; padding: 5px; }
            td { border: 1px solid #000; padding: 5px; }
            .footer-sig { 
              margin-top: 30px; 
              display: grid; 
              grid-template-columns: 1fr 1fr 1fr; 
              text-align: center; 
              gap: 10px; 
              font-size: ${isPos ? '9px' : '12px'};
            }
            .sig-box { border-top: 1px dashed #000; padding-top: 5px; }
            .footer-text { margin-top: 20px; font-size: ${isPos ? '9px' : '12px'}; text-align: center; border-top: 1px solid #eee; padding-top: 10px; }
          </style>
        </head>
        <body>
          <div class="header-container">
            ${company.logo ? `<img src="${company.logo}" style="height: ${isPos ? '40px' : '60px'}; margin-bottom: 10px;" onerror="this.style.display='none'" />` : ''}
            <div class="company-info">
              <h2>${company.name}</h2>
              <p>${company.address || ''}</p>
              ${company.phone ? `<p>هاتف: ${company.phone}</p>` : ''}
              ${company.taxNumber ? `<p>الرقم الضريبي: ${company.taxNumber}</p>` : ''}
            </div>
          </div>

          <div class="doc-title">${doc.type === 'purchase' ? 'فاتورة مشتريات' : 'سند صرف بضاعة'}</div>

          <div class="info-grid">
            <div><b>التاريخ:</b> ${doc.date}</div>
            <div><b>رقم السند:</b> ${doc.docNum}</div>
            <div><b>المرجع:</b> ${doc.ref}</div>
            <div><b>الفرع:</b> ${branch}</div>
            <div><b>المخزن:</b> ${warehouse}</div>
            <div><b>الحساب:</b> ${acc}</div>
            <div><b>المركز:</b> ${cc}</div>
            <div style="grid-column: 1 / -1;"><b>البيان:</b> ${doc.description || '---'}</div>
          </div>

          <table>
            <thead>
              <tr>
                <th style="width:30px;">م</th>
                <th>الصنف</th>
                <th style="width:60px;">الوحدة</th>
                <th style="width:50px;">الكمية</th>
              </tr>
            </thead>
            <tbody>${itemsHtml}</tbody>
          </table>

          <div class="footer-sig">
            <div class="sig-box">أمين المستودع</div>
            <div class="sig-box">المستلم</div>
            <div class="sig-box">يعتمد</div>
          </div>

          <div class="footer-text">
            ${company.footerText ? `<p style="white-space: pre-wrap;">${company.footerText}</p>` : '<p>تم الإصدار بواسطة النظام المحاسبي المطور.</p>'}
            <p style="font-size: 8px; color: #888; margin-top: 5px;">عدد مرات الطباعة: ${(doc.printCount || 0) + 1}</p>
          </div>
          
          <script>
            window.onload = () => {
              window.print();
              setTimeout(() => window.close(), 500);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const downloadBackup = () => {
    const dataStr = JSON.stringify(db, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_${getTodayDate()}.json`;
    link.click();
  };

  const runExport = () => {
    const filteredDocs = (db.docs || []).filter(d => d.date >= expFrom && d.date <= expTo);
    if (filteredDocs.length === 0) return alert("لا توجد بيانات لهذه الفترة");

    let csvContent = "\uFEFFالنطاق;رقم_الصنف;رقم_الوحدة;الكمية;السعر;التاريخ;الحساب;المرجع;البيان\n";
    const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

    filteredDocs.forEach(doc => {
      const acc = (db.accounts || []).find(a => a.id === doc.accId) || { name: '' };
      const rangeName = `R_${doc.ref}`;
      
      // --- منطق استخراج البيان ---
      const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
      const dateObj = new Date(doc.date);
      const dayName = days[dateObj.getDay()];
      const formattedDate = doc.date.replace(/-/g, '/');

      let partName = "";
      const accountName = acc.name;
      if (accountName.includes("مبيعات")) {
        partName = accountName.split("مبيعات")[1].trim();
      } else if (accountName.includes("تكلفة")) {
        partName = accountName.split("تكلفة")[1].trim();
      } else {
        partName = accountName;
      }
      
      const specificName = partName.split(" ")[0];
      const bayan = `${specificName} ${dayName}_${formattedDate}`;
      // ---------------------------

      csvContent += `${rangeName};رقم الصنف;رقم الوحدة;الكمية;0;${doc.date};${acc.name};${doc.ref};${bayan}\n`;

      (doc.items || []).forEach(item => {
        const itemObj = (db.items || []).find(i => i.id === item.itemId) || { code: '0' };
        let uIdx = (itemObj as any).units ? (itemObj as any).units.findIndex((u: any) => u.name === item.unit) + 1 : 1;
        if (uIdx <= 0) uIdx = 1;
        
        csvContent += `${rangeName};${itemObj.code};${uIdx};${item.qty};0;${doc.date};${acc.name};${doc.ref};${bayan}\n`;
      });
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `سندات_مجمعة_${expFrom}.csv`);
    link.click();
  };

  if (!isAuthReady) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4" dir="rtl">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-500 font-bold">جاري تحميل النظام...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LandingPage onLogin={login} />;
  }

  if (!isCompanyAccessVerified || !selectedCompanyId) {
    return <CompanySelector />;
  }

  return (
    <div className="flex min-h-screen bg-slate-50/50 text-slate-900 font-sans selection:bg-blue-100 selection:text-blue-900" dir="rtl">
      <Sidebar 
        activeView={activeTab.view} 
          setActiveView={(view) => {
            const labels: Record<string, string> = {
              'dashboard': 'لوحة التحكم',
              'main-guides': 'الأدلة الرئيسية',
              'new-doc': 'سند صرف مخزني',
              'new-purchase': 'فاتورة مشتريات',
              'new-sale': 'فاتورة مبيعات',
              'price-list': 'تسعيرات الأصناف',
              'inventory-movement': 'الحركة المخزنية',
              'inventory-reports': 'التقارير المخزنية',
              'history': 'سجل السندات',
              'settings': 'الإعدادات',
              'account-statement': 'كشف حساب تفصيلي',
              'accounts': 'دليل الحسابات',
              'items': 'دليل الأصناف',
              'centers': 'مراكز التكلفة',
              'branches': 'دليل الفروع',
              'warehouses': 'دليل المخازن',
              'departments': 'دليل الأقسام',
              'funds': 'دليل الصناديق',
              'banks': 'دليل البنوك',
              'customers-suppliers': 'العملاء والموردين',
              'new-journal': 'قيد يومية',
              'journal-history': 'سجل القيود',
              'cash-payment': 'صرف نقدي',
              'cash-receipt': 'قبض نقدي',
              'cash-history': 'سجل النقدية',
              'bank-payment': 'صرف بنكي',
              'bank-receipt': 'قبض بنكي',
              'bank-history': 'سجل البنك',
              'cash-bank-history': 'سجل الحركة النقدية/البنكية',
              'all-reports': 'قائمة التقارير',
              'currencies': 'العملات وأسعار الصرف',
              'fiscal-years': 'السنوات المالية'
            };
            openTab(view as ViewType, labels[view] || view);
          }}
        isCollapsed={isSidebarCollapsed}
        setIsCollapsed={setIsSidebarCollapsed}
        isMobileOpen={isMobileMenuOpen}
        setIsMobileOpen={setIsMobileMenuOpen}
        user={user}
        onLogout={handleLogout}
        db={db}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-40 px-4 sm:px-8 py-3 no-print">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-4 min-w-0">
              <button 
                onClick={() => setIsMobileMenuOpen(true)}
                className="lg:hidden p-2 hover:bg-slate-100 rounded-xl transition-colors text-slate-600"
              >
                <Menu size={24} />
              </button>
              
              {/* Tab Bar */}
              <div className="flex items-center gap-1 overflow-x-auto no-scrollbar scroll-smooth pb-1">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTabId(tab.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap border ${
                      activeTabId === tab.id
                        ? 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-200'
                        : 'bg-white text-slate-500 border-slate-100 hover:border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {tab.title}
                    {tabs.length > 1 && (
                      <X 
                        size={14} 
                        className={`hover:bg-black/10 rounded-full p-0.5 transition-colors ${activeTabId === tab.id ? 'text-blue-100' : 'text-slate-300'}`}
                        onClick={(e) => closeTab(tab.id, e)}
                      />
                    )}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2 sm:gap-4 shrink-0">
              {isSuperAdmin && allCompanies.length > 0 && (
                <div className="flex items-center gap-2 bg-slate-100 px-2 sm:px-3 py-1.5 rounded-xl border border-slate-200">
                  <Building size={16} className="text-slate-500 hidden sm:block" />
                  <select 
                    value={selectedCompanyId}
                    onChange={(e) => setSelectedCompanyId(e.target.value)}
                    className="bg-transparent text-[10px] sm:text-xs font-bold text-slate-700 outline-none cursor-pointer max-w-[80px] sm:max-w-none"
                  >
                    <option value="all">جميع الشركات</option>
                    {allCompanies.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
              )}
              {activeTab.view === 'new-doc' && (
                <div className="hidden sm:flex items-center gap-2 bg-slate-100 p-1 rounded-xl border border-slate-200">
                  <button 
                    onClick={handlePrevDoc}
                    className="p-2 hover:bg-white rounded-lg transition-all text-slate-600 disabled:opacity-30"
                    disabled={currentDocIndex <= 0}
                    title="السند السابق"
                  >
                    <ChevronRight size={18} />
                  </button>
                  <button 
                    onClick={handleNewDoc}
                    className="px-4 py-2 hover:bg-white rounded-lg transition-all text-blue-600 font-bold text-xs"
                  >
                    سند جديد
                  </button>
                  <button 
                    onClick={handleNextDoc}
                    className="p-2 hover:bg-white rounded-lg transition-all text-slate-600"
                    title="السند التالي"
                  >
                    <ChevronLeft size={18} />
                  </button>
                </div>
              )}
              <div className="flex items-center gap-3 pr-2 sm:pr-4 border-r border-slate-100">
                <div className="hidden sm:flex flex-col items-end">
                  <span className="text-sm font-bold text-slate-900">{user.name}</span>
                  <div className="flex items-center gap-1">
                    {isSuperAdmin && <span className="text-[8px] bg-amber-100 text-amber-600 px-1 rounded font-bold">مدير عام</span>}
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{user.role === 'admin' ? 'مدير' : 'محاسب'}</span>
                  </div>
                </div>
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 font-bold border border-blue-100 shadow-sm">
                  {user.name[0]}
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-8 overflow-y-auto">
          <div className="max-w-7xl mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTabId}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                {activeTab.view === 'dashboard' && (
                  <Dashboard 
                    db={db} 
                    user={user}
                    onNewDoc={() => openTab('new-doc', 'سند صرف جديد')} 
                    onEditDoc={(doc) => {
                      setEditingDoc(doc);
                      setCurrentDocIndex((db.docs || []).findIndex(d => d.id === doc.id));
                      openTab('new-doc', `تعديل: ${doc.ref}`, { docId: doc.id });
                    }}
                    onHistory={() => openTab('history', 'سجل السندات')}
                    onSettings={() => openTab('settings', 'الإعدادات')}
                    allCompanies={selectedCompanyId === 'all' ? allCompanies : undefined}
                  />
                )}
                {activeTab.view === 'new-doc' && (
                  <DocumentForm 
                    db={db} 
                    user={user}
                    type="issue"
                    onSave={onSaveDoc} 
                    onPrint={printDoc}
                    onNavigate={(dir) => {
                      if (dir === 'new') {
                        handleNewDoc();
                        return;
                      }
                      if (!editingDoc) return;
                      const currentIndex = (db.docs || []).findIndex(d => d.id === editingDoc.id);
                      let nextIndex = dir === 'prev' ? currentIndex - 1 : currentIndex + 1;
                      
                      if (nextIndex >= 0 && nextIndex < (db.docs || []).length) {
                        const nextDoc = (db.docs || [])[nextIndex];
                        setEditingDoc(nextDoc);
                      } else {
                        showNotification(dir === 'prev' ? 'لا يوجد سند سابق' : 'لا يوجد سند تالي', 'warning');
                      }
                    }}
                    onDelete={deleteDoc}
                    initialDoc={editingDoc}
                    onCancel={() => {
                      setEditingDoc(null);
                      closeTab(activeTabId, { stopPropagation: () => {} } as any);
                    }}
                    showNotification={showNotification}
                    setConfirmModal={setConfirmModal}
                  />
                )}
                {activeTab.view === 'new-purchase' && (
                  <DocumentForm 
                    db={db} 
                    user={user}
                    type="purchase"
                    onSave={onSaveDoc} 
                    onPrint={printDoc}
                    onNavigate={(dir) => {
                      if (dir === 'new') {
                        handleNewDoc();
                        return;
                      }
                      if (!editingDoc) return;
                      const currentIndex = (db.docs || []).findIndex(d => d.id === editingDoc.id);
                      let nextIndex = dir === 'prev' ? currentIndex - 1 : currentIndex + 1;
                      
                      if (nextIndex >= 0 && nextIndex < (db.docs || []).length) {
                        const nextDoc = (db.docs || [])[nextIndex];
                        setEditingDoc(nextDoc);
                      } else {
                        showNotification(dir === 'prev' ? 'لا يوجد سند سابق' : 'لا يوجد سند تالي', 'warning');
                      }
                    }}
                    onDelete={deleteDoc}
                    initialDoc={editingDoc}
                    onCancel={() => {
                      setEditingDoc(null);
                      closeTab(activeTabId, { stopPropagation: () => {} } as any);
                    }}
                    showNotification={showNotification}
                    setConfirmModal={setConfirmModal}
                  />
                )}
                {activeTab.view === 'new-sale' && (
                  <DocumentForm 
                    db={db} 
                    user={user}
                    type="sale"
                    onSave={onSaveDoc} 
                    onPrint={printDoc}
                    onNavigate={(dir) => {
                      if (dir === 'new') {
                        handleNewDoc();
                        return;
                      }
                      if (!editingDoc) return;
                      const currentIndex = (db.docs || []).findIndex(d => d.id === editingDoc.id);
                      let nextIndex = dir === 'prev' ? currentIndex - 1 : currentIndex + 1;
                      
                      if (nextIndex >= 0 && nextIndex < (db.docs || []).length) {
                        const nextDoc = (db.docs || [])[nextIndex];
                        setEditingDoc(nextDoc);
                      } else {
                        showNotification(dir === 'prev' ? 'لا يوجد سند سابق' : 'لا يوجد سند تالي', 'warning');
                      }
                    }}
                    onDelete={deleteDoc}
                    initialDoc={editingDoc}
                    onCancel={() => {
                      setEditingDoc(null);
                      closeTab(activeTabId, { stopPropagation: () => {} } as any);
                    }}
                    showNotification={showNotification}
                    setConfirmModal={setConfirmModal}
                  />
                )}
                {activeTab.view === 'history' && (
                  <History 
                    db={db} 
                    user={user}
                    type="issue"
                    onEdit={(doc) => {
                      // Check grace period
                      const gracePeriod = user.editGracePeriod || db.editGracePeriod;
                      if (user.role !== 'admin' && gracePeriod) {
                        const createdTime = new Date(doc.createdAt).getTime();
                        const now = Date.now();
                        const diffMinutes = (now - createdTime) / (1000 * 60);
                        if (diffMinutes > gracePeriod) {
                          showNotification(`عذراً، انتهى وقت سماح التعديل (${gracePeriod} دقيقة)`, 'error');
                          return;
                        }
                      }
                      setEditingDoc(doc);
                      setCurrentDocIndex(db.docs.findIndex(d => d.id === doc.id));
                      openTab('new-doc', `تعديل: ${doc.ref}`, { docId: doc.id });
                    }}
                    onDelete={deleteDoc}
                    onPrint={printDoc}
                    allCompanies={selectedCompanyId === 'all' ? allCompanies : undefined}
                    setConfirmModal={setConfirmModal}
                  />
                )}
                {activeTab.view === 'sale-history' && (
                  <History 
                    db={db} 
                    user={user}
                    type="sale"
                    onEdit={(doc) => {
                      // Check grace period
                      const gracePeriod = user.editGracePeriod || db.editGracePeriod;
                      if (user.role !== 'admin' && gracePeriod) {
                        const createdTime = new Date(doc.createdAt).getTime();
                        const now = Date.now();
                        const diffMinutes = (now - createdTime) / (1000 * 60);
                        if (diffMinutes > gracePeriod) {
                          showNotification(`عذراً، انتهى وقت سماح التعديل (${gracePeriod} دقيقة)`, 'error');
                          return;
                        }
                      }
                      setEditingDoc(doc);
                      setCurrentDocIndex((db.docs || []).findIndex(d => d.id === doc.id));
                      openTab('new-sale', `تعديل: ${doc.ref}`, { docId: doc.id });
                    }}
                    onDelete={deleteDoc}
                    onPrint={printDoc}
                    allCompanies={selectedCompanyId === 'all' ? allCompanies : undefined}
                    setConfirmModal={setConfirmModal}
                  />
                )}
                {activeTab.view === 'purchase-history' && (
                  <History 
                    db={db} 
                    user={user}
                    type="purchase"
                    onEdit={(doc) => {
                      // Check grace period
                      const gracePeriod = user.editGracePeriod || db.editGracePeriod;
                      if (user.role !== 'admin' && gracePeriod) {
                        const createdTime = new Date(doc.createdAt).getTime();
                        const now = Date.now();
                        const diffMinutes = (now - createdTime) / (1000 * 60);
                        if (diffMinutes > gracePeriod) {
                          showNotification(`عذراً، انتهى وقت سماح التعديل (${gracePeriod} دقيقة)`, 'error');
                          return;
                        }
                      }
                      setEditingDoc(doc);
                      setCurrentDocIndex((db.docs || []).findIndex(d => d.id === doc.id));
                      openTab('new-purchase', `تعديل: ${doc.ref}`, { docId: doc.id });
                    }}
                    onDelete={deleteDoc}
                    onPrint={printDoc}
                    allCompanies={selectedCompanyId === 'all' ? allCompanies : undefined}
                    setConfirmModal={setConfirmModal}
                  />
                )}
                {activeTab.view === 'new-journal' && (
                  <JournalForm 
                    db={db} 
                    user={user}
                    onSave={saveJournal} 
                    onPrint={printDoc as any}
                    onNavigate={(dir) => {
                      if (dir === 'new') {
                        setEditingDoc(null);
                        openTab('new-journal', 'قيد يومية جديد');
                        return;
                      }
                      if (!editingDoc) return;
                      const currentIndex = (db.journalEntries || []).findIndex(e => e.id === editingDoc.id);
                      let nextIndex = dir === 'prev' ? currentIndex - 1 : currentIndex + 1;
                      
                      if (nextIndex >= 0 && nextIndex < (db.journalEntries || []).length) {
                        const nextDoc = (db.journalEntries || [])[nextIndex];
                        setEditingDoc(nextDoc as any);
                      } else {
                        showNotification(dir === 'prev' ? 'لا يوجد قيد سابق' : 'لا يوجد قيد تالي', 'warning');
                      }
                    }}
                    onDelete={deleteJournal}
                    initialDoc={editingDoc as any}
                    onCancel={() => {
                      setEditingDoc(null);
                      closeTab(activeTabId, { stopPropagation: () => {} } as any);
                    }}
                    showNotification={showNotification}
                    setConfirmModal={setConfirmModal}
                  />
                )}
                {activeTab.view === 'journal-history' && (
                  <JournalHistory 
                    db={db} 
                    user={user}
                    onEdit={(entry) => {
                      setEditingDoc(entry as any);
                      openTab('new-journal', `تعديل قيد: ${entry.ref}`, { docId: entry.id });
                    }}
                    onDelete={deleteJournal}
                    onPrint={printDoc as any}
                    setConfirmModal={setConfirmModal}
                  />
                )}
                {(activeTab.view === 'new-cash-bank' || activeTab.view === 'cash-payment' || activeTab.view === 'cash-receipt' || activeTab.view === 'bank-payment' || activeTab.view === 'bank-receipt') && (
                  <CashBankForm 
                    db={db} 
                    user={user}
                    onSave={saveCashBankDoc}
                    onCancel={() => {
                      setEditingDoc(null);
                      closeTab(activeTabId, { stopPropagation: () => {} } as any);
                    }}
                    initialDoc={editingDoc ? editingDoc as any : {
                      type: activeTab.view === 'cash-payment' ? 'cash-payment' :
                            activeTab.view === 'cash-receipt' ? 'cash-receipt' :
                            activeTab.view === 'bank-payment' ? 'check-payment' :
                            activeTab.view === 'bank-receipt' ? 'check-receipt' : 'cash-payment'
                    }}
                    onDelete={async (id) => deleteCashBankDoc(id)}
                    getNextDocNum={getNextCashBankDocNum}
                    onNavigate={(dir) => {
                      if (dir === 'new') {
                        setEditingDoc(null);
                        return;
                      }
                      if (!editingDoc) return;
                      const currentIndex = (db.cashBankDocs || []).findIndex(d => d.id === editingDoc.id);
                      let nextIndex = dir === 'prev' ? currentIndex - 1 : currentIndex + 1;
                      if (nextIndex >= 0 && nextIndex < (db.cashBankDocs || []).length) {
                        setEditingDoc((db.cashBankDocs || [])[nextIndex] as any);
                      } else {
                        showNotification(dir === 'prev' ? 'لا يوجد سند سابق' : 'لا يوجد سند تالي', 'warning');
                      }
                    }}
                  />
                )}
                {(activeTab.view === 'cash-bank-history' || activeTab.view === 'cash-history' || activeTab.view === 'bank-history') && (
                  <CashBankHistory 
                    db={db}
                    user={user}
                    filter={activeTab.view === 'cash-history' ? 'cash' : activeTab.view === 'bank-history' ? 'bank' : 'all'}
                    onEdit={(doc) => {
                      setEditingDoc(doc as any);
                      const labels: Record<string, string> = {
                        'cash-payment': 'تعديل صرف نقدي',
                        'cash-receipt': 'تعديل قبض نقدي',
                        'check-payment': 'تعديل صرف بنكي',
                        'check-receipt': 'تعديل قبض بنكي',
                        'transfer-payment': 'تعديل صرف بنكي',
                        'transfer-receipt': 'تعديل قبض بنكي'
                      };
                      openTab('new-cash-bank', labels[doc.type] || `تعديل سند: ${doc.docNum}`, { docId: doc.id });
                    }}
                    onDelete={deleteCashBankDoc}
                    onPrint={(doc) => console.log('Print', doc)}
                  />
                )}
                {activeTab.view === 'main-guides' && (
                  <GuideScreen 
                    user={user}
                    onSelect={(v) => {
                    const labels: Record<string, string> = {
                      'accounts': 'دليل الحسابات',
                      'items': 'دليل الأصناف',
                      'centers': 'مراكز التكلفة',
                      'branches': 'دليل الفروع',
                      'warehouses': 'دليل المخازن',
                      'departments': 'دليل الأقسام',
                      'funds': 'دليل الصناديق',
                      'banks': 'دليل البنوك والصرافين',
                      'customers-suppliers': 'دليل العملاء والموردين'
                    };
                    openTab(v, labels[v] || v);
                  }} />
                )}
                {activeTab.view === 'currencies' && (
                  <CurrencyManagement 
                    db={db} 
                    user={user}
                    onUpdateDB={handleUpdateDB}
                    showNotification={showNotification}
                    setConfirmModal={setConfirmModal}
                  />
                )}
                {(['accounts', 'items', 'centers', 'branches', 'warehouses', 'departments', 'funds', 'banks', 'customers-suppliers'] as ViewType[]).includes(activeTab.view) && (
                  <div className="space-y-6">
                    <button 
                      onClick={() => openTab('main-guides', 'الأدلة الرئيسية')}
                      className="flex items-center gap-2 text-slate-500 hover:text-blue-600 transition-colors font-bold"
                    >
                      <ChevronRight size={20} />
                      <span>العودة للأدلة الرئيسية</span>
                    </button>
                    <Settings 
                      db={db} 
                      user={user}
                      onUpdateDB={handleUpdateDB} 
                      showNotification={showNotification}
                      setConfirmModal={setConfirmModal}
                      initialTab={activeTab.view as any}
                    />
                  </div>
                )}
                {activeTab.view === 'all-reports' && (
                  <ReportScreen 
                    user={user}
                    onSelect={(v) => {
                    const labels: Record<string, string> = {
                      'inventory-movement': 'الحركة المخزنية',
                      'inventory-reports': 'التقارير المخزنية',
                      'sale-history': 'سجل المبيعات',
                      'account-statement': 'كشف حساب تفصيلي'
                    };
                    openTab(v, labels[v] || v);
                  }} />
                )}
                {activeTab.view === 'inventory-movement' && (
                  <History 
                    db={db} 
                    user={user}
                    type="all"
                    setConfirmModal={setConfirmModal}
                    onEdit={(doc) => {
                      // Check grace period
                      const gracePeriod = user.editGracePeriod || db.editGracePeriod;
                      if (user.role !== 'admin' && gracePeriod) {
                        const createdTime = new Date(doc.createdAt).getTime();
                        const now = Date.now();
                        const diffMinutes = (now - createdTime) / (1000 * 60);
                        if (diffMinutes > gracePeriod) {
                          showNotification(`عذراً، انتهى وقت سماح التعديل (${gracePeriod} دقيقة)`, 'error');
                          return;
                        }
                      }
                      setEditingDoc(doc);
                      setCurrentDocIndex((db.docs || []).findIndex(d => d.id === doc.id));
                      let view: ViewType = 'new-doc';
                      if (doc.type === 'purchase') view = 'new-purchase';
                      if (doc.type === 'sale') view = 'new-sale';
                      openTab(view, `تعديل: ${doc.ref}`, { docId: doc.id });
                    }}
                    onDelete={deleteDoc}
                    onPrint={printDoc}
                  />
                )}
                {activeTab.view === 'inventory-reports' && <InventoryReports db={db} />}
                {activeTab.view === 'price-list' && (
                  <PricingHistory 
                    db={db} 
                    user={user}
                    onUpdateDB={handleUpdateDB}
                    showNotification={showNotification}
                  />
                )}
                {activeTab.view === 'settings' && (
                  <Settings 
                    db={db} 
                    user={user}
                    onUpdateDB={handleUpdateDB} 
                    showNotification={showNotification}
                    setConfirmModal={setConfirmModal}
                    isSuperAdmin={isSuperAdmin}
                    allCompanies={allCompanies}
                  />
                )}
                {activeTab.view === 'account-statement' && (
                  <AccountStatement db={db} />
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>

        <footer className="bg-white border-t border-slate-200 px-8 py-3 text-[10px] text-slate-400 flex justify-between items-center no-print">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>النظام متصل وقيد التشغيل</span>
            </div>
            <span className="font-bold text-slate-500">تطوير عبدالمجيد المزلم | Almuzllam@gmail.com | 775600578 | جميع الحقوق محفوظة</span>
          </div>
          <div className="flex items-center gap-4">
            <span>إجمالي السندات: {(db.docs || []).length}</span>
            <span>•</span>
            <span>{new Date().toLocaleDateString('ar-SA')}</span>
          </div>
        </footer>
      </div>

      {/* Global UI Components */}
      <GlobalUI />

      {/* Export Modal */}
      <AnimatePresence>
        {isExportModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsExportModalOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-2xl shadow-2xl p-8"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-bold text-slate-900">تصدير التقارير</h3>
                <button onClick={() => setIsExportModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">من تاريخ</label>
                    <input 
                      type="date" 
                      value={expFrom}
                      onChange={e => setExpFrom(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">إلى تاريخ</label>
                    <input 
                      type="date" 
                      value={expTo}
                      onChange={e => setExpTo(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                    />
                  </div>
                </div>

                <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 flex gap-3">
                  <div className="text-blue-600 mt-0.5"><CheckCircle2 size={18} /></div>
                  <p className="text-xs text-blue-700 leading-relaxed">
                    سيتم تجميع كافة السندات في الفترة المحددة وتصديرها كملف CSV متوافق مع أنظمة الإكسل المحاسبية.
                  </p>
                </div>

                <button 
                  onClick={() => { runExport(); setIsExportModalOpen(false); }}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold shadow-lg shadow-blue-100 transition-all active:scale-95 flex items-center justify-center gap-2"
                >
                  <Download size={20} />
                  تصدير ملف CSV
                </button>

                <button 
                  onClick={() => {
                    const vbaCode = `Sub AutoCreateRanges()
    Dim lastRow As Long, i As Long, startRow As Long
    lastRow = Cells(Rows.Count, 1).End(xlUp).Row
    startRow = 2
    On Error Resume Next
    Dim nm As Name
    For Each nm In ThisWorkbook.Names: nm.Delete: Next nm
    For i = 2 To lastRow + 1
        If Cells(i, 1).Value <> Cells(startRow, 1).Value Then
            Range("B" & startRow & ":E" & i - 1).Name = Cells(startRow, 1).Value
            startRow = i
        End If
    Next i
    MsgBox "Success! All ranges have been created.", vbInformation, "System"
End Sub`;
                    navigator.clipboard.writeText(vbaCode);
                    alert("✅ تم نسخ كود VBA للحافظة");
                  }}
                  className="w-full bg-slate-800 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2"
                >
                  <CheckCircle2 size={20} />
                  نسخ كود VBA للإكسل
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
