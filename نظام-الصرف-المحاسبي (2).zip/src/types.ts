export interface Unit {
  name: string;
  factor: number;
  barcode?: string;
  engName?: string;
}

export interface Item {
  id: string;
  companyId: string;
  code: string;
  name: string;
  type: 'item' | 'service';
  parentId: string | null;
  level: number;
  isLeaf: boolean;
  units: Unit[];
  altName?: string;
  vendor?: string;
  details?: string;
  identification?: string;
  prices?: { unitName: string; price: number }[];
  defaultPurchaseUnit?: string;
  defaultSaleUnit?: string;
  defaultIssueUnit?: string;
}

export interface Account {
  id: string;
  companyId: string;
  code: string;
  name: string;
  type?: 'client' | 'supplier' | 'both' | 'cost' | 'revenue' | 'other';
  parentId: string | null;
  level: number;
  isPostable: boolean;
  currencyId?: string;
}

export interface CostCenter {
  id: string;
  companyId: string;
  code: string;
  name: string;
  parentId: string | null;
  departmentId: string;
  level: number;
  isLeaf: boolean;
}

export interface Branch {
  id: string;
  companyId: string;
  code: string;
  name: string;
  parentId: string | null;
  level: number;
  isLeaf: boolean;
}

export interface Warehouse {
  id: string;
  companyId: string;
  code: string;
  name: string;
  parentId: string | null;
  branchId: string;
  accId?: string; // Linked inventory account
  level: number;
  isLeaf: boolean;
}

export interface Department {
  id: string;
  companyId: string;
  code: string;
  name: string;
  parentId: string | null;
  branchId: string;
  level: number;
  isLeaf: boolean;
}

export interface DocItem {
  id: string;
  itemId: string;
  unit: string;
  qty: number;
  price?: number;
  discount?: number;
  expenses?: number;
  total?: number;
  accId?: string;
  accType?: AccountCategory;
  ccId?: string;
}

export interface FieldDefinition {
  id: string;
  companyId: string;
  name: string;
  type: 'text' | 'number' | 'date' | 'select';
  options?: string[];
  required?: boolean;
  order: number;
  allowedDocTypes?: ('issue' | 'purchase' | 'sale')[];
}

export interface Doc {
  id: string;
  companyId: string;
  type: 'issue' | 'purchase' | 'sale';
  date: string;
  docNum: string;
  ref: string;
  description: string;
  accId: string;
  accType?: AccountCategory;
  ccId: string;
  branchId?: string;
  warehouseId?: string;
  deptId?: string;
  items: DocItem[];
  customValues?: Record<string, any>;
  priceType?: PriceType;
  createdAt: string;
  createdBy: string;
  updatedAt?: string;
  updatedBy?: string;
  editCount?: number;
  printCount?: number;
}

export interface FiscalYear {
  id: string;
  companyId: string;
  name: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  isClosed: boolean;
}

export interface CompanyInfo {
  name: string;
  logo?: string;
  phone?: string;
  address?: string;
  taxNumber?: string;
  footerText?: string;
  accessPassword?: string; // New: Password for company access
}

export interface DocTypeSettings {
  name?: string;
  linkingLevel: 'header' | 'line';
  mandatoryFields: string[];
  fieldConfig?: Record<string, { visible: boolean; order: number }>;
}

export type PriceType = 'retail' | 'wholesale' | 'internal' | 'external';

export interface PricingDocItem {
  itemId: string;
  unit: string;
  price: number;
}

export interface PricingDoc {
  id: string;
  companyId: string;
  date: string;
  type: PriceType;
  description: string;
  items: PricingDocItem[];
  createdAt: string;
  createdBy: string;
}

export interface JournalEntryItem {
  id: string;
  accId: string;
  accType?: AccountCategory;
  ccId?: string;
  currencyId?: string;
  exchangeRate?: number;
  foreignAmount?: number;
  debit: number;
  credit: number;
  description: string;
}

export interface JournalEntry {
  id: string;
  companyId: string;
  date: string;
  docNum: string;
  ref: string;
  description: string;
  items: JournalEntryItem[];
  createdAt: string;
  createdBy: string;
  updatedAt?: string;
  updatedBy?: string;
}

export interface Fund {
  id: string;
  companyId: string;
  code: string;
  name: string;
  parentId: string | null;
  accId: string; // Linked account in Chart of Accounts
  level: number;
  isLeaf: boolean;
}

export interface Bank {
  id: string;
  companyId: string;
  code: string;
  name: string;
  parentId: string | null;
  accId: string; // Linked account in Chart of Accounts
  level: number;
  isLeaf: boolean;
}

export interface CustomerSupplier {
  id: string;
  companyId: string;
  code: string;
  name: string;
  type: 'client' | 'supplier' | 'both';
  parentId: string | null;
  accId: string; // Linked account in Chart of Accounts
  level: number;
  isLeaf: boolean;
}

export type CashBankDocType = 
  | 'cash-payment' | 'cash-receipt' 
  | 'check-payment' | 'check-receipt' 
  | 'transfer-payment' | 'transfer-receipt';

export interface Currency {
  id: string;
  companyId: string;
  code: string;
  name: string;
  symbol: string;
  exchangeRate: number;
  minRate?: number;
  maxRate?: number;
  isDefault: boolean;
}

export type AccountCategory = 'gl' | 'customer-supplier' | 'fund' | 'bank' | 'warehouse' | 'all';

export interface CashBankDocItem {
  id: string;
  accId: string; // The GL account ID
  subId?: string; // The specific directory item ID (Fund ID, Bank ID, etc.)
  accType?: AccountCategory;
  ccId?: string;
  currencyId?: string;
  exchangeRate?: number;
  amount: number;
  description: string;
}

export interface CashBankDoc {
  id: string;
  companyId: string;
  branchId?: string;
  type: CashBankDocType;
  date: string;
  docNum: string;
  ref: string;
  description: string;
  fundId?: string; // For cash movements
  bankId?: string; // For bank movements
  currencyId?: string;
  exchangeRate?: number;
  collector?: string;
  maturityDate?: string;
  items: CashBankDocItem[];
  amount: number; // Total amount
  checkNum?: string; // For checks
  checkDate?: string; // For checks
  transferRef?: string; // For transfers
  createdAt: string;
  createdBy: string;
}

export interface DB {
  accounts: Account[];
  centers: CostCenter[];
  items: Item[];
  docs: Doc[];
  journalEntries?: JournalEntry[];
  cashBankDocs?: CashBankDoc[];
  currencies?: Currency[];
  funds?: Fund[];
  banks?: Bank[];
  customersSuppliers?: CustomerSupplier[];
  pricingDocs: PricingDoc[];
  branches: Branch[];
  warehouses: Warehouse[];
  departments: Department[];
  users: User[];
  fiscalYears?: FiscalYear[];
  fieldDefinitions?: FieldDefinition[];
  company?: CompanyInfo;
  numberingStrategy: 'branch' | 'branch-warehouse';
  printType?: 'a4' | 'pos';
  editGracePeriod?: number; // in minutes
  maxPrintCount?: number;
  allowNegativeStock?: boolean;
  linkingLevel?: 'header' | 'line';
  mandatoryFields?: string[];
  // Per-type settings
  settings?: {
    issue: DocTypeSettings;
    purchase: DocTypeSettings;
    sale: DocTypeSettings;
    accountsMaxLevel?: number;
    itemsMaxLevel?: number;
    centersMaxLevel?: number;
    currencies?: Currency[];
    baseCurrency?: string;
  };
}

export interface User {
  id: string;
  companyId: string;
  name: string;
  email?: string;
  role: 'admin' | 'user';
  password?: string;
  isActive: boolean;
  allowedBranches?: string[];
  allowedWarehouses?: string[];
  allowedCenters?: string[];
  allowedAccounts?: string[];
  // Document Permissions
  canCreatePurchase?: boolean;
  canEditPurchase?: boolean;
  canDeletePurchase?: boolean;
  canCreateSale?: boolean;
  canEditSale?: boolean;
  canDeleteSale?: boolean;
  canCreateIssue?: boolean;
  canEditIssue?: boolean;
  canDeleteIssue?: boolean;
  canManagePricing?: boolean;
  // Financial Permissions
  canCreateJournal?: boolean;
  canEditJournal?: boolean;
  canDeleteJournal?: boolean;
  canCreateCashBank?: boolean;
  canEditCashBank?: boolean;
  canDeleteCashBank?: boolean;
  // Master Data Permissions
  canManageAccounts?: boolean;
  canManageItems?: boolean;
  canManageBranches?: boolean;
  canManageWarehouses?: boolean;
  canManageDepartments?: boolean;
  canManageCenters?: boolean;
  canManageFunds?: boolean;
  canManageBanks?: boolean;
  canManageCustomersSuppliers?: boolean;
  canManageCurrencies?: boolean;
  canManageFiscalYears?: boolean;
  // Report Permissions
  canViewReports?: boolean;
  
  printType?: 'a4' | 'pos';
  editGracePeriod?: number;
  maxPrintCount?: number;
}

export type ViewType = 'dashboard' | 'new-doc' | 'history' | 'settings' | 'sold-items' | 'accounts' | 'items' | 'centers' | 'purchase-history' | 'new-purchase' | 'new-sale' | 'sale-history' | 'price-list' | 'inventory-movement' | 'inventory-reports' | 'pricing-docs' | 'main-guides' | 'branches' | 'warehouses' | 'departments' | 'all-reports' | 'new-journal' | 'journal-history' | 'new-cash-bank' | 'cash-bank-history' | 'cash-history' | 'bank-history' | 'cash-payment' | 'cash-receipt' | 'bank-payment' | 'bank-receipt' | 'funds' | 'banks' | 'customers-suppliers' | 'currencies' | 'account-statement' | 'fiscal-years';

export interface Tab {
  id: string;
  title: string;
  view: ViewType;
  params?: any;
}
