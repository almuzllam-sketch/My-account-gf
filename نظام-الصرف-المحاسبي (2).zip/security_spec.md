# Security Specification - Fiscal Years

## Data Invariants
1. A Fiscal Year must belong to a valid `companyId`.
2. A user can only access Fiscal Years belonging to their own company.
3. Only administrators or users with explicit permission can manage Fiscal Years.
4. Active status and closure status are protected states.

## The Dirty Dozen Payloads (Fiscal Years)
1. **Identity Spoofing**: Attempt to create a fiscal year for a different company.
2. **Unauthorized Read**: Attempt to list fiscal years for a company the user doesn't belong to.
3. **Ghost Field Injection**: Adding `isSystemAdmin: true` to a fiscal year document.
4. **Invalid ID**: Using a 2KB string as a document ID.
5. **Type Poisoning**: Sending `isActive: "yes"` instead of `true`.
6. **State Shortcut**: Re-opening a closed fiscal year without admin rights.
7. **Size Attack**: Sending a 1MB string in the `name` field.
8. **Immutability Breach**: Updating `companyId` after creation.
9. **Orphan Creation**: Creating a fiscal year without a company ID.
10. **Privilege Escalation**: Attempting to set `isActive: true` as a read-only user.
11. **Query Scraping**: Attempting to list all fiscal years in the system without filtering by company.
12. **Terminal State Lockdown**: Attempting to update a deleted or ARCHIVED fiscal year (if applicable).

## Implementation Plan
1. Add `isValidFiscalYear` helper.
2. Add `match /fiscalYears/{fyId}` block.
3. Ensure `isSameCompany` is enforced for list queries.
